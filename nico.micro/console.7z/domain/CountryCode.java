package com.advantagegroup.blue.console.domain;

/**
 * @author Ara Khalesi
 * April,2017
 */
import java.io.Serializable;
import java.sql.Timestamp;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonBackReference;
import org.hibernate.annotations.TypeDef;
import org.hibernate.annotations.TypeDefs;

import com.advantagegroup.blue.console.domain.enumeration.Trademark;
import com.advantagegroup.blue.console.domain.type.StringJsonUserType;
import com.advantagegroup.blue.console.domain.type.TrademarkType;



@Entity
@Table(name = "countrycode", schema = "blue")
@TypeDefs({ @TypeDef(name = "StringJson", typeClass = StringJsonUserType.class) })
public class CountryCode implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "countrycode_id")
    @GeneratedValue(generator = "countrycode_id_seq")
    @SequenceGenerator(name = "countrycode_id_seq", sequenceName = "countrycode_id_seq", schema = "blue", allocationSize = 1)
    private Long id;

    @Column(name = "country_code", unique = true, nullable = false)
    private String code;

    @Column(name = "country_description")
    private String description;

    @Column(name = "countryidentifier", nullable = false)
    private Boolean identifier;

    @Column(name = "country_name", nullable = false)
    private String name;

    @Column(name = "country_name_localization", nullable = false)
    private String nameLocalization;

    @Column(name = "is_retired", nullable = false)
    private Boolean isRetired;

    @OneToMany(mappedBy = "countryCode")
    @JsonBackReference
    private Set<Country> countries = new HashSet<>();

    @Column(name = "locales")
    private String locales;

    @Column(name = "trademark")
    @Convert(converter = TrademarkType.class)
    private Trademark trademark;

    @Column(name = "updated_timestamp", nullable = false)
    private Timestamp updatedDate;

    public CountryCode() {

    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public Boolean getIdentifier() {
        return identifier;
    }

    public void setIdentifier(Boolean identifier) {
        this.identifier = identifier;
    }

    public Boolean getIsRetired() {
        return isRetired;
    }

    public void setIsRetired(Boolean isRetired) {
        this.isRetired = isRetired;
    }

    public Set<Country> getCountries() {
        return countries;
    }

    public void setCountries(Set<Country> countries) {
        this.countries = countries;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getNameLocalization() {
        return nameLocalization;
    }

    public void setNameLocalization(String nameLocalization) {
        this.nameLocalization = nameLocalization;
    }

    public String getLocales() {
        return locales;
    }

    public void setLocales(String locales) {
        this.locales = locales;
    }

    public Trademark getTrademark() {
        return trademark;
    }

    public void setTrademark(Trademark trademark) {
        this.trademark = trademark;
    }

    public Timestamp getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(Timestamp updatedDate) {
        this.updatedDate = updatedDate;
    }

    @PrePersist
    void onCreate() {
        defaults();
        calculated();
    }

    @PreUpdate
    void onUpdate() {
        calculated();
    }

    private void defaults() {
        // nothing to do
    }

    private void calculated() {
        this.setUpdatedDate(new Timestamp(System.currentTimeMillis()));
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((code == null) ? 0 : code.hashCode());
        result = prime * result + ((countries == null) ? 0 : countries.hashCode());
        result = prime * result + ((description == null) ? 0 : description.hashCode());
        result = prime * result + ((id == null) ? 0 : id.hashCode());
        result = prime * result + ((identifier == null) ? 0 : identifier.hashCode());
        result = prime * result + ((isRetired == null) ? 0 : isRetired.hashCode());
        result = prime * result + ((locales == null) ? 0 : locales.hashCode());
        result = prime * result + ((name == null) ? 0 : name.hashCode());
        result = prime * result + ((nameLocalization == null) ? 0 : nameLocalization.hashCode());
        result = prime * result + ((trademark == null) ? 0 : trademark.hashCode());
        result = prime * result + ((updatedDate == null) ? 0 : updatedDate.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        CountryCode other = (CountryCode) obj;
        if (code == null) {
            if (other.code != null)
                return false;
        } else if (!code.equals(other.code))
            return false;
        if (countries == null) {
            if (other.countries != null)
                return false;
        } else if (!countries.equals(other.countries))
            return false;
        if (description == null) {
            if (other.description != null)
                return false;
        } else if (!description.equals(other.description))
            return false;
        if (id == null) {
            if (other.id != null)
                return false;
        } else if (!id.equals(other.id))
            return false;
        if (identifier == null) {
            if (other.identifier != null)
                return false;
        } else if (!identifier.equals(other.identifier))
            return false;
        if (isRetired == null) {
            if (other.isRetired != null)
                return false;
        } else if (!isRetired.equals(other.isRetired))
            return false;
        if (locales == null) {
            if (other.locales != null)
                return false;
        } else if (!locales.equals(other.locales))
            return false;
        if (name == null) {
            if (other.name != null)
                return false;
        } else if (!name.equals(other.name))
            return false;
        if (nameLocalization == null) {
            if (other.nameLocalization != null)
                return false;
        } else if (!nameLocalization.equals(other.nameLocalization))
            return false;
        if (trademark != other.trademark)
            return false;
        if (updatedDate == null) {
            if (other.updatedDate != null)
                return false;
        } else if (!updatedDate.equals(other.updatedDate))
            return false;
        return true;
    }
}
