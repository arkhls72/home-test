package com.advantagegroup.blue.console.domain.comparator;

import com.advantagegroup.blue.console.domain.Survey;

import java.util.Comparator;
import java.util.HashMap;

public class SurveyComparator {

    static private Comparator<Survey> byId = new Comparator<Survey>() {
        @Override
        public int compare(Survey o1, Survey o2) {
            return o1.getId().compareTo(o2.getId());
        }
    };

    static private Comparator<Survey> byCode = new Comparator<Survey>() {
        @Override
        public int compare(Survey o1, Survey o2) {
            return o1.getCode().compareTo(o2.getCode());
        }
    };

    static private Comparator<Survey> byName = new Comparator<Survey>() {
        @Override
        public int compare(Survey o1, Survey o2) {
            return o1.getName().compareTo(o2.getName());
        }
    };

    static private Comparator<Survey> byDescription = new Comparator<Survey>() {
        @Override
        public int compare(Survey o1, Survey o2) {
            return o1.getDescription().compareTo(o2.getDescription());
        }
    };

    static private Comparator<Survey> byFieldStart = new Comparator<Survey>() {
        @Override
        public int compare(Survey o1, Survey o2) {
            return o1.getFieldStart().compareTo(o2.getFieldStart());
        }
    };

    static private Comparator<Survey> byFieldClose = new Comparator<Survey>() {
        @Override
        public int compare(Survey o1, Survey o2) {
            return o1.getFieldClose().compareTo(o2.getFieldClose());
        }
    };

    static private Comparator<Survey> byApprovalStatus = new Comparator<Survey>() {
        @Override
        public int compare(Survey o1, Survey o2) {
            return o1.getApprovalStatus().name().compareTo(o2.getApprovalStatus().name());
        }
    };

    static private Comparator<Survey> byNumberOfResponses = new Comparator<Survey>() {
        @Override
        public int compare(Survey o1, Survey o2) {
            return o1.getNumberOfResponses().compareTo(o2.getNumberOfResponses());
        }
    };

    static private HashMap<String, Comparator<Survey>> comparator = new HashMap<String, Comparator<Survey>>() {{
        put("code", byCode);
        put("name", byName);
        put("description", byDescription);
        put("fieldStart", byFieldStart);
        put("fieldClose", byFieldClose);
        put("approvalStatus", byApprovalStatus);
        put("numberOfResponses", byNumberOfResponses);
    }};

    static public Comparator<Survey> get(String fieldName, boolean ascending) {
        Comparator<Survey> comp = comparator.getOrDefault(fieldName, byId);
        if (ascending) {
            return comp;
        }
        return comp.reversed();
    }
}
