package com.advantagegroup.blue.console.domain.comparator;

import com.advantagegroup.blue.console.domain.ManufacturerRollup;

import java.util.Comparator;
import java.util.HashMap;

public class ManufacturerRollupComparator {

    static private Comparator<ManufacturerRollup> byId = new Comparator<ManufacturerRollup>() {
        @Override
        public int compare(ManufacturerRollup o1, ManufacturerRollup o2) {
            return o1.getId().compareTo(o2.getId());
        }
    };

    static private Comparator<ManufacturerRollup> byCode = new Comparator<ManufacturerRollup>() {
        @Override
        public int compare(ManufacturerRollup o1, ManufacturerRollup o2) { return o1.getManufacturerCode().getCode().compareTo(o2.getManufacturerCode().getCode()); }
    };

    static private Comparator<ManufacturerRollup> byNamePath = new Comparator<ManufacturerRollup>() {
        @Override
        public int compare(ManufacturerRollup o1, ManufacturerRollup o2) {
            return o1.getNamePath().compareTo(o2.getNamePath());
        }
    };

    static private Comparator<ManufacturerRollup> byEffectiveDate = new Comparator<ManufacturerRollup>() {
        @Override
        public int compare(ManufacturerRollup o1, ManufacturerRollup o2) {
            return o1.getEffectiveDate().compareTo(o2.getEffectiveDate());
        }
    };

    static private Comparator<ManufacturerRollup> byExpiryDate = new Comparator<ManufacturerRollup>() {
        @Override
        public int compare(ManufacturerRollup o1, ManufacturerRollup o2) {
            if (o1.getExpiryDate() == null && o2.getExpiryDate() != null) {
                return -1;
            }
            if (o1.getExpiryDate() != null && o2.getExpiryDate() == null) {
                return 1;
            }
            if (o1.getExpiryDate() == null && o2.getExpiryDate() == null) {
                return 0;
            }
            return o1.getExpiryDate().compareTo(o2.getExpiryDate());
        }
    };

    static private Comparator<ManufacturerRollup> byDescription = new Comparator<ManufacturerRollup>() {
        @Override
        public int compare(ManufacturerRollup o1, ManufacturerRollup o2) {
            if (o1.getDescription() == null && o2.getDescription() != null) {
                return -1;
            }
            if (o1.getDescription() != null && o2.getDescription() == null) {
                return 1;
            }
            if (o1.getDescription() == null && o2.getDescription() == null) {
                return 0;
            }
            return o1.getDescription().compareTo(o2.getDescription());
        }
    };

    static private HashMap<String, Comparator<ManufacturerRollup>> comprator = new HashMap<String, Comparator<ManufacturerRollup>>() {{
        put("manufacturerCode", byCode);
        put("namePath", byNamePath);
        put("effectiveDate", byEffectiveDate);
        put("expiryDate", byExpiryDate);
        put("description", byDescription);
    }};

    static public Comparator<ManufacturerRollup> get(String fieldName, boolean ascending) {
        Comparator<ManufacturerRollup> comp = comprator.getOrDefault(fieldName, byId);
        if (ascending) {
            return comp;
        }
        return comp.reversed();
    }
}
