package com.advantagegroup.blue.console.domain.comparator;

import com.advantagegroup.blue.console.domain.SurveyFlat;
import java.util.Comparator;
import java.util.HashMap;

public class SurveyFlatComparator {

    static private Comparator<SurveyFlat> byId = new Comparator<SurveyFlat>() {
        @Override
        public int compare(SurveyFlat o1, SurveyFlat o2) {
            return o1.getId().compareTo(o2.getId());
        }
    };

    static private Comparator<SurveyFlat> byCode = new Comparator<SurveyFlat>() {
        @Override
        public int compare(SurveyFlat o1, SurveyFlat o2) {
            return o1.getCode().compareTo(o2.getCode());
        }
    };

    static private Comparator<SurveyFlat> byName = new Comparator<SurveyFlat>() {
        @Override
        public int compare(SurveyFlat o1, SurveyFlat o2) {
            return o1.getName().compareTo(o2.getName());
        }
    };

    static private Comparator<SurveyFlat> byDescription = new Comparator<SurveyFlat>() {
        @Override
        public int compare(SurveyFlat o1, SurveyFlat o2) {
            return o1.getDescription().compareTo(o2.getDescription());
        }
    };

    static private Comparator<SurveyFlat> byFieldStart = new Comparator<SurveyFlat>() {
        @Override
        public int compare(SurveyFlat o1, SurveyFlat o2) {
            return o1.getFieldStart().compareTo(o2.getFieldStart());
        }
    };

    static private Comparator<SurveyFlat> byFieldClose = new Comparator<SurveyFlat>() {
        @Override
        public int compare(SurveyFlat o1, SurveyFlat o2) {
            return o1.getFieldClose().compareTo(o2.getFieldClose());
        }
    };

    static private Comparator<SurveyFlat> byApprovalStatus = new Comparator<SurveyFlat>() {
        @Override
        public int compare(SurveyFlat o1, SurveyFlat o2) {
            return o1.getApprovalStatus().name().compareTo(o2.getApprovalStatus().name());
        }
    };

    static private Comparator<SurveyFlat> byNumberOfResponses = new Comparator<SurveyFlat>() {
        @Override
        public int compare(SurveyFlat o1, SurveyFlat o2) {
            return o1.getNumberOfResponses().compareTo(o2.getNumberOfResponses());
        }
    };

    static private HashMap<String, Comparator<SurveyFlat>> comparator = new HashMap<String, Comparator<SurveyFlat>>() {{
        put("code", byCode);
        put("name", byName);
        put("description", byDescription);
        put("fieldStart", byFieldStart);
        put("fieldClose", byFieldClose);
        put("approvalStatus", byApprovalStatus);
        put("numberOfResponses", byNumberOfResponses);
    }};

    static public Comparator<SurveyFlat> get(String fieldName, boolean ascending) {
        Comparator<SurveyFlat> comp = comparator.getOrDefault(fieldName, byId);
        if (ascending) {
            return comp;
        }
        return comp.reversed();
    }
}
