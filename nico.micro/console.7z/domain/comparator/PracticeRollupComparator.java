package com.advantagegroup.blue.console.domain.comparator;

import com.advantagegroup.blue.console.domain.PracticeRollup;

import java.util.Comparator;
import java.util.HashMap;

public class PracticeRollupComparator {

    static private Comparator<PracticeRollup> byId = new Comparator<PracticeRollup>() {
        @Override
        public int compare(PracticeRollup o1, PracticeRollup o2) {
            return o1.getId().compareTo(o2.getId());
        }
    };

    static private Comparator<PracticeRollup> byCode = new Comparator<PracticeRollup>() {
        @Override
        public int compare(PracticeRollup o1, PracticeRollup o2) { return o1.getCodePath().compareTo(o2.getCodePath()); }
    };

    static private Comparator<PracticeRollup> byName = new Comparator<PracticeRollup>() {
        @Override
        public int compare(PracticeRollup o1, PracticeRollup o2) { return o1.getName().compareTo(o2.getName()); }
    };

    static private Comparator<PracticeRollup> byText = new Comparator<PracticeRollup>() {
        @Override
        public int compare(PracticeRollup o1, PracticeRollup o2) { return o1.getText().compareTo(o2.getText()); }
    };

    static private HashMap<String, Comparator<PracticeRollup>> comprator = new HashMap<String, Comparator<PracticeRollup>>() {{
        put("code", byCode);
        put("name", byName);
        put("text", byText);
    }};

    static public Comparator<PracticeRollup> get(String fieldName, boolean ascending) {
        Comparator<PracticeRollup> comp = comprator.getOrDefault(fieldName, byId);
        if (ascending) {
            return comp;
        }
        return comp.reversed();
    }
}
