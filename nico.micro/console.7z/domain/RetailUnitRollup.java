package com.advantagegroup.blue.console.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class RetailUnitRollup {

    @Id
    private String id;

    @Column(name = "retailunit_id")
    private Long retailUnitId;

    @Column(name = "retailrollup_id")
    private Long retailRollupId;

    @Column(name = "code_path")
    private String codePath;

    @Column(name = "name_path")
    private String namePath;

    @Column(name = "root_retailunit_id")
    private Long rootRetailUnitId;

    @Column(name = "root_retailrollup_id")
    private Long rootRetailRollupId;

    @Column(name = "root_code_path")
    private String rootCodePath;

    @Column(name = "root_name_path")
    private String rootNamePath;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Long getRetailUnitId() {
        return retailUnitId;
    }

    public void setRetailUnitId(Long retailUnitId) {
        this.retailUnitId = retailUnitId;
    }

    public Long getRetailRollupId() {
        return retailRollupId;
    }

    public void setRetailRollupId(Long retailRollupId) {
        this.retailRollupId = retailRollupId;
    }

    public String getCodePath() {
        return codePath;
    }

    public void setCodePath(String codePath) {
        this.codePath = codePath;
    }

    public String getNamePath() {
        return namePath;
    }

    public void setNamePath(String namePath) {
        this.namePath = namePath;
    }

    public Long getRootRetailUnitId() {
        return rootRetailUnitId;
    }

    public void setRootRetailUnitId(Long rootRetailUnitId) {
        this.rootRetailUnitId = rootRetailUnitId;
    }

    public Long getRootRetailRollupId() {
        return rootRetailRollupId;
    }

    public void setRootRetailRollupId(Long rootRetailRollupId) {
        this.rootRetailRollupId = rootRetailRollupId;
    }

    public String getRootCodePath() {
        return rootCodePath;
    }

    public void setRootCodePath(String rootCodePath) {
        this.rootCodePath = rootCodePath;
    }

    public String getRootNamePath() {
        return rootNamePath;
    }

    public void setRootNamePath(String rootNamePath) {
        this.rootNamePath = rootNamePath;
    }

    @Override
    public String toString() {
        return "RetailUnitRollup{" +
            "id='" + id + '\'' +
            ", retailUnitId=" + retailUnitId +
            ", retailRollupId=" + retailRollupId +
            ", codePath='" + codePath + '\'' +
            ", namePath='" + namePath + '\'' +
            ", rootRetailUnitId=" + rootRetailUnitId +
            ", rootRetailRollupId=" + rootRetailRollupId +
            ", rootCodePath='" + rootCodePath + '\'' +
            ", rootNamePath='" + rootNamePath + '\'' +
            '}';
    }
}
