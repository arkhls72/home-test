package com.advantagegroup.blue.console.domain;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.HashSet;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;


import com.advantagegroup.blue.console.domain.enumeration.RanksetType;
import com.advantagegroup.blue.console.domain.enumeration.RanksetTypeConverter;
import com.advantagegroup.blue.console.domain.type.ApprovalStatus;
import com.advantagegroup.blue.console.domain.type.ApprovalStatusType;
import com.fasterxml.jackson.annotation.JsonIgnore;

/**
 * A Rankset.
 */
@Entity
@Table(name = "rankset", schema = "blue")
public class Rankset implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "rankset_id")
    @GeneratedValue(generator = "rankset_id_seq")
    @SequenceGenerator(name = "rankset_id_seq", sequenceName = "rankset_id_seq", schema = "blue", allocationSize = 1)
    private Long id;

    @NotNull
    @Column(name = "rankset_code", nullable = false)
    private String code;

    @NotNull
    @Column(name = "rankset_name", nullable = false)
    private String name;

    @Column(name = "rankset_description")
    private String description;

    @NotNull
    @Column(name = "rankset_type", nullable = false)
    @Convert(converter = RanksetTypeConverter.class)
    private RanksetType type;

    @NotNull
    @Column(name = "approval_status", nullable = false)
    @Convert(converter = ApprovalStatusType.class)
    private ApprovalStatus approvalStatus;

    @Column(name = "updated_timestamp")
    private Timestamp updatedDate;

    @NotNull
    @ManyToOne(optional = false)
    @JoinColumn(name="dataset_id", referencedColumnName="dataset_id", updatable=false)
	private Dataset dataset;

    @JsonIgnore
    @ManyToMany
    @JoinTable(
        name = "rankset_retailrollup", schema = "blue",
        joinColumns = {@JoinColumn(name = "rankset_id", referencedColumnName = "rankset_id")},
        inverseJoinColumns = {@JoinColumn(name = "retailrollup_id", referencedColumnName = "retailrollup_id")})
    private Set<RetailRollup> retailRollups = new HashSet<>();

    @NotNull
    @ManyToOne
    @JoinColumn(name = "countryrollup_id")
    private CountryRollup countryRollup;

    @JsonIgnore
    @ManyToMany
    @Fetch(FetchMode.SUBSELECT)
    @JoinTable(
        name = "rankset_manufacturerrollup", schema = "blue",
        joinColumns = {@JoinColumn(name = "rankset_id", referencedColumnName = "rankset_id")},
        inverseJoinColumns = {@JoinColumn(name = "manufacturerrollup_id", referencedColumnName = "manufacturerrollup_id")})
    private Set<ManufacturerRollup> manufacturerRollups = new HashSet<>();

    /**
     * This is a calculated field, indicating whether or not a special RetailRollup should
     * be included in the retailRollups association.
     */
    @JsonIgnore
    @Column(name = "include_all_retailrollup")
    private boolean includeAllRetailRollups;

    @JsonIgnore
    @ManyToMany
    @Fetch(FetchMode.SUBSELECT)
    @JoinTable(
        name = "rankset_practicerollup", schema = "blue",
        joinColumns = {@JoinColumn(name = "rankset_id", referencedColumnName = "rankset_id")},
        inverseJoinColumns = {@JoinColumn(name = "practicerollup_id", referencedColumnName = "practicerollup_id")})
    private Set<PracticeRollup> practiceRollups = new HashSet<>();

    @JsonIgnore
    @ManyToMany
    @JoinTable(
        name = "rankset_survey", schema = "blue",
        joinColumns = {@JoinColumn(name = "rankset_id", referencedColumnName = "rankset_id")},
        inverseJoinColumns = {@JoinColumn(name = "survey_id", referencedColumnName = "survey_id")})
    private Set<SurveyFlat> surveys = new HashSet<>();

    @Column(name = "datasetweighttype_id")
    private Long datasetWeightTypeId;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getCode() {
        return code;
    }

    public Rankset code(String code) {
        this.code = code;
        return this;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public Rankset name(String name) {
        this.name = name;
        return this;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public Rankset description(String description) {
        this.description = description;
        return this;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public RanksetType getType() {
        return type;
    }

    public Rankset type(RanksetType type) {
        this.type = type;
        return this;
    }

    public void setType(RanksetType type) {
        this.type = type;
    }

    public ApprovalStatus getApprovalStatus() {
        return approvalStatus;
    }

    public Rankset approvalStatus(ApprovalStatus approvalStatus) {
        this.approvalStatus = approvalStatus;
        return this;
    }

    public void setApprovalStatus(ApprovalStatus approvalStatus) {
        this.approvalStatus = approvalStatus;
    }

    public Dataset getDataset() {
		return dataset;
	}

	public void setDataset(Dataset dataset) {
		this.dataset = dataset;
	}

    public CountryRollup getCountryRollup() {
        return countryRollup;
    }

    public void setCountryRollup(CountryRollup countryRollup) {
        this.countryRollup = countryRollup;
    }

    public Set<ManufacturerRollup> getManufacturerRollups() {
        return manufacturerRollups;
    }

    public void setManufacturerRollups(Set<ManufacturerRollup> manufacturerRollups) {
        this.manufacturerRollups = manufacturerRollups;
    }

    public Timestamp getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(Timestamp updatedDate) {
        this.updatedDate = updatedDate;
    }

    public Set<RetailRollup> getRetailRollups() {
        return retailRollups;
    }

    public void setRetailRollups(Set<RetailRollup> retailRollups) {
        this.retailRollups = retailRollups;
    }


    public boolean isIncludeAllRetailRollups() {
		return includeAllRetailRollups;
	}

	public void setIncludeAllRetailRollups(boolean includeAllRetailAccounts) {
		this.includeAllRetailRollups = includeAllRetailAccounts;
	}

    public Set<PracticeRollup> getPracticeRollups() {
        return practiceRollups;
    }

    public void setPracticeRollups(Set<PracticeRollup> practiceRollups) {
        this.practiceRollups = practiceRollups;
    }

    public Set<SurveyFlat> getSurveys() {
        return surveys;
    }

    public void setSurveys(Set<SurveyFlat> surveys) {
        this.surveys = surveys;
    }

    public Long getDatasetWeightTypeId() {
        return datasetWeightTypeId;
    }

    public void setDatasetWeightTypeId(Long datasetWeightTypeId) {
        this.datasetWeightTypeId = datasetWeightTypeId;
    }

    @PrePersist
    void onCreate() {
        defaults();
        calculated();
    }

    @PreUpdate
    void onUpdate() {
        calculated();
    }

    private void defaults() {
        // nothing to do
    }

    private void calculated() {
        this.setUpdatedDate(new Timestamp(System.currentTimeMillis()));
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        Rankset rankset = (Rankset) o;
        if (rankset.getId() == null || getId() == null) {
            return false;
        }
        return Objects.equals(getId(), rankset.getId());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getId());
    }

    @Override
    public String toString() {
        return "Rankset{" +
            "id=" + getId() +
            ", code='" + getCode() + "'" +
            ", name='" + getName() + "'" +
            ", description='" + getDescription() + "'" +
            ", type='" + getType() + "'" +
            ", datasetWeightTypeId = " + getDatasetWeightTypeId() +
            ", approvalStatus='" + getApprovalStatus() + "'" +
            ", " + (countryRollup == null ? "CountryRollup=null" : countryRollup.toString()) +
            ", manufacturerRollups[" + manufacturerRollups.stream().map(ManufacturerRollup::toString).collect(Collectors.joining(", ")) + "]" +
            ", dataset[id=" + dataset.getId() + ", code=" + dataset.getCode() + ", name=" + dataset.getName() + "]" +
            ", surveys[" + surveys.stream().map(SurveyFlat::toString).collect(Collectors.joining(", ")) + "]" +
            "}";
    }

}
