package com.advantagegroup.blue.console.domain;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import com.advantagegroup.blue.console.domain.type.WeightUnit;
import com.advantagegroup.blue.console.domain.type.WeightUnitType;

/**
 * A CompanyWeightType.
 */
@Entity
@Table(name = "companyweighttype", schema = "blue")
public class CompanyWeightType implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "companyweighttype_id")
    @GeneratedValue(generator = "companyweighttype_id_seq")
    @SequenceGenerator(name = "companyweighttype_id_seq", sequenceName = "companyweighttype_id_seq", schema = "blue", allocationSize = 1)
    private Long id;

    @NotNull
    @Column(name = "companyweighttype_name", nullable = false)
    private String name;

    @Column(name = "companyweighttype_description")
    private String description;

    @NotNull
    @Column(name = "supports_defaults", nullable = false)
    private Boolean supportsDefaults;

    @Column(name = "weight_unit")
    @Convert(converter = WeightUnitType.class)
    private WeightUnit weightUnit;

    @Column(name = "updated_timestamp")
    private Timestamp updatedDate;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public CompanyWeightType name(String name) {
        this.name = name;
        return this;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public CompanyWeightType description(String description) {
        this.description = description;
        return this;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Boolean isSupportsDefaults() {
        return supportsDefaults;
    }

    public CompanyWeightType supportsDefaults(Boolean supportsDefaults) {
        this.supportsDefaults = supportsDefaults;
        return this;
    }

    public void setSupportsDefaults(Boolean supportsDefaults) {
        this.supportsDefaults = supportsDefaults;
    }

    public WeightUnit getWeightUnit() {
        return weightUnit;
    }

    public CompanyWeightType weightUnit(WeightUnit weightUnit) {
        this.weightUnit = weightUnit;
        return this;
    }

    public void setWeightUnit(WeightUnit weightUnit) {
        this.weightUnit = weightUnit;
    }

    public Timestamp getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(Timestamp updatedDate) {
        this.updatedDate = updatedDate;
    }

    public CompanyWeightType updatedDate( Timestamp updatedDate ) {
        this.updatedDate = updatedDate;
        return this;
    }

    @PrePersist
    void onCreate() {
        defaults();
        calculations();
    }

    @PreUpdate
    void onUpdate() {
        calculations();
    }

    private void defaults() {
    }

    private void calculations() {
        this.setUpdatedDate(new Timestamp(System.currentTimeMillis()));
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        CompanyWeightType companyWeightType = (CompanyWeightType) o;
        if (companyWeightType.getId() == null || getId() == null) {
            return false;
        }
        return Objects.equals(getId(), companyWeightType.getId());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getId());
    }

    @Override
    public String toString() {
        return "CompanyWeightType{" +
            "id=" + getId() +
            ", name='" + getName() + "'" +
            ", description='" + getDescription() + "'" +
            ", supportsDefaults='" + isSupportsDefaults() + "'" +
            ", weightUnit='" + getWeightUnit() + "'" +
            "}";
    }
}
