package com.advantagegroup.blue.console.domain;

import java.io.Serializable;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.util.HashSet;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;
import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;

import com.advantagegroup.blue.console.domain.type.ApprovalStatus;
import com.advantagegroup.blue.console.domain.type.ApprovalStatusType;
import com.fasterxml.jackson.annotation.JsonIgnore;

/**
 * A Dataset.
 */
@Entity
@Table(name = "dataset", schema = "blue")
@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
public class Dataset implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "dataset_id")
    @GeneratedValue(generator = "dataset_id_seq")
    @SequenceGenerator(name = "dataset_id_seq", sequenceName = "dataset_id_seq", schema = "blue", allocationSize = 1)
    private Long id;

    @NotNull
    @Column(name = "dataset_code", nullable = false)
    private String code;

    @NotNull
    @Column(name = "dataset_name", nullable = false)
    private String name;

    @Column(name = "dataset_description")
    private String description;

    @NotNull
    @Column(name = "effective_date", nullable = false)
    private LocalDate effectiveDate;

    @Column(name = "expiry_date")
    private LocalDate expiryDate;

    @Column(name = "approval_status", nullable = false, insertable = false)
    @Convert(converter = ApprovalStatusType.class)
    private ApprovalStatus approvalStatus;

    @Column(name = "updated_timestamp")
    private Timestamp updatedDate;

    @OneToOne
    @JoinColumn(name = "program_id", insertable = false)
    private Program program;

    @OneToMany(mappedBy = "dataset")
    @JsonIgnore
    private Set<Rankset> ranksets = new HashSet<>();

    @JsonIgnore
    @ManyToMany
    @JoinTable(
        name = "dataset_survey", schema = "blue",
        joinColumns = {@JoinColumn(name = "dataset_id", referencedColumnName = "dataset_id")},
        inverseJoinColumns = {@JoinColumn(name = "survey_id", referencedColumnName = "survey_id")})
    private Set<SurveyFlat> surveys = new HashSet<>();

    @NotNull
    @ManyToOne
    @JoinColumn(name = "countryrollup_id")
    private CountryRollup countryRollup;

    @JsonIgnore
    @ManyToMany
    @Fetch(FetchMode.SUBSELECT)
    @JoinTable(
        name = "dataset_manufacturerrollup", schema = "blue",
        joinColumns = {@JoinColumn(name = "dataset_id", referencedColumnName = "dataset_id")},
        inverseJoinColumns = {@JoinColumn(name = "manufacturerrollup_id", referencedColumnName = "manufacturerrollup_id")})
    private Set<ManufacturerRollup> manufacturerRollups = new HashSet<>();

    @JsonIgnore
    @ManyToMany
    @Fetch(FetchMode.SUBSELECT)
    @JoinTable(
        name = "dataset_practicerollup", schema = "blue",
        joinColumns = {@JoinColumn(name = "dataset_id", referencedColumnName = "dataset_id")},
        inverseJoinColumns = {@JoinColumn(name = "practicerollup_id", referencedColumnName = "practicerollup_id")})
    private Set<PracticeRollup> practiceRollups = new HashSet<>();

    @JsonIgnore
    @ManyToMany
    @Fetch(FetchMode.SUBSELECT)
    @JoinTable(
        name = "dataset_retailrollup", schema = "blue",
        joinColumns = {@JoinColumn(name = "dataset_id", referencedColumnName = "dataset_id")},
        inverseJoinColumns = {@JoinColumn(name = "retailrollup_id", referencedColumnName = "retailrollup_id")})
    private Set<RetailRollup> retailRollups = new HashSet<>();

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getCode() {
        return code;
    }

    public Dataset code(String code) {
        this.code = code;
        return this;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public Dataset name(String name) {
        this.name = name;
        return this;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public Dataset description(String description) {
        this.description = description;
        return this;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public LocalDate getEffectiveDate() {
        return effectiveDate;
    }

    public void setEffectiveDate(LocalDate effectiveDate) {
        this.effectiveDate = effectiveDate;
    }

    public Dataset effectiveDate( LocalDate effectiveDate ) {
        this.effectiveDate = effectiveDate;
        return this;
    }

    public LocalDate getExpiryDate() {
        return expiryDate;
    }

    public void setExpiryDate(LocalDate expiryDate) {
        this.expiryDate = expiryDate;
    }

    public Dataset expiryDate( LocalDate expiryDate ) {
        this.expiryDate = expiryDate;
        return this;
    }

    public ApprovalStatus getApprovalStatus() {
        return approvalStatus;
    }

    public Dataset approvalStatus(ApprovalStatus approvalStatus) {
        this.approvalStatus = approvalStatus;
        return this;
    }

    public void setApprovalStatus(ApprovalStatus approvalStatus) {
        this.approvalStatus = approvalStatus;
    }

    public Program getProgram() {
        return program;
    }

    public void setProgram(Program program) {
        this.program = program;
    }

    public CountryRollup getCountryRollup() {
        return countryRollup;
    }

    public void setCountryRollup(CountryRollup countryRollup) {
        this.countryRollup = countryRollup;
    }

    public Set<Rankset> getRanksets() {
        return ranksets;
    }

    public Dataset ranksets(Set<Rankset> ranksets) {
        this.ranksets = ranksets;
        return this;
    }

    public void setRanksets(Set<Rankset> ranksets) {
        this.ranksets = ranksets;
    }

    public Set<SurveyFlat> getSurveys() {
        return surveys;
    }

    public void setSurveys(Set<SurveyFlat> surveys) {
        this.surveys = surveys;
    }

    public Set<ManufacturerRollup> getManufacturerRollups() {
        return manufacturerRollups;
    }

    public void setManufacturerRollups(Set<ManufacturerRollup> manufacturerRollups) {
        this.manufacturerRollups = manufacturerRollups;
    }

    public Set<PracticeRollup> getPracticeRollups() { return practiceRollups; }

    public void setPracticeRollups(Set<PracticeRollup> practiceRollups) { this.practiceRollups = practiceRollups; }

    public Set<RetailRollup> getRetailRollups() {
        return retailRollups;
    }

    public void setRetailRollups(Set<RetailRollup> retailRollups) {
        this.retailRollups = retailRollups;
    }

    public Timestamp getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(Timestamp updatedDate) {
        this.updatedDate = updatedDate;
    }

    @PrePersist
    void onCreate() {
        defaults();
        calculated();
    }

    @PreUpdate
    void onUpdate() {
        calculated();
    }

    private void defaults() {
        // nothing to do
    }

    private void calculated() {
        this.setUpdatedDate(new Timestamp(System.currentTimeMillis()));
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        Dataset dataset = (Dataset) o;
        if (dataset.getId() == null || getId() == null) {
            return false;
        }
        return Objects.equals(getId(), dataset.getId());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getId());
    }

    @Override
    public String toString() {
        return "Dataset{" +
            "id=" + getId() +
            ", code='" + getCode() + "'" +
            ", name='" + getName() + "'" +
            ", description='" + getDescription() + "'" +
            ", effectiveDate='" + getEffectiveDate() + "'" +
            ", expiryDate='" + getExpiryDate() + "'" +
            ", approvalStatus='" + getApprovalStatus() + "'" +
            ", " + (program == null ? "Program=null" : program.toString()) +
            ", " + (countryRollup == null ? "CountryRollup=null" : countryRollup.toString()) +
            ", surveys[" + surveys.stream().map(SurveyFlat::toString).collect(Collectors.joining(", ")) + "]" +
            ", manufacturerRollups[" + manufacturerRollups.stream().map(ManufacturerRollup::toString).collect(Collectors.joining(", ")) + "]" +
            ", practiceRollups[" + practiceRollups.stream().map(PracticeRollup::toString).collect(Collectors.joining(", ")) + "]" +
            ", ranksets[" + ranksets.stream().map(Rankset::toString).collect(Collectors.joining(", ")) + "]" +
            "}";
    }
}
