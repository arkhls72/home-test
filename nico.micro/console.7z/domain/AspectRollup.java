package com.advantagegroup.blue.console.domain;

import javax.persistence.*;
import java.io.Serializable;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.util.Objects;

/**
 * A AspectRollup.
 */
@Entity
@Table(name = "aspectrollup", schema = "blue")
@SecondaryTable(name = "aspectrollup_view",
schema = "blue_console",
pkJoinColumns = @PrimaryKeyJoinColumn(name = "aspectrollup_id"))
public class AspectRollup implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "aspectrollup_id")
    @GeneratedValue(generator = "blue.aspectrollup_id_seq")
    @SequenceGenerator(name = "blue.aspectrollup_id_seq", sequenceName = "blue.aspectrollup_id_seq")
    private Long id;

    @Column(name = "aspect_name",nullable=false)
    private String name;

    @Column(name = "aspect_name_localization" ,nullable=false)
    private String nameLocalization;

    @Column(name = "aspect_description")
    private String description;

    @Column(name = "effective_date" ,nullable=false)
    private LocalDate effectiveDate;

    @Column(name = "expiry_date" ,nullable=false)
    private LocalDate expiryDate;

    @Column(name = "list_order" ,nullable=false)
    private Integer listOrder;

    @Column(name = "locked" ,nullable=false)
    private Boolean locked;
    
    
    @Column(name = "updated_timestamp")
    private Timestamp updatedDate;

    @Column( table = "aspectrollup_view", name = "code_path", insertable = false, updatable = false )
    private String codePath;

    @Column( table = "aspectrollup_view", name = "name_path", insertable = false, updatable = false )
    private String namePath;
    
    @ManyToOne
    @JoinColumn(name = "aspectcode_id", nullable = false)
    private AspectCode aspectCode;
    
    
    public AspectCode getAspectCode() {
        return aspectCode;
    }

    public void setAspectCode(AspectCode aspectCode) {
        this.aspectCode = aspectCode;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public AspectRollup name(String name) {
        this.name = name;
        return this;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getNameLocalization() {
        return nameLocalization;
    }

    public AspectRollup nameLocalization(String nameLocalization) {
        this.nameLocalization = nameLocalization;
        return this;
    }

    public void setNameLocalization(String nameLocalization) {
        this.nameLocalization = nameLocalization;
    }

    public String getDescription() {
        return description;
    }

    public AspectRollup description(String description) {
        this.description = description;
        return this;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public LocalDate getEffectiveDate() {
        return effectiveDate;
    }

    public AspectRollup effectiveDate(LocalDate effectiveDate) {
        this.effectiveDate = effectiveDate;
        return this;
    }

    public void setEffectiveDate(LocalDate effectiveDate) {
        this.effectiveDate = effectiveDate;
    }

    public LocalDate getExpiryDate() {
        return expiryDate;
    }

    public AspectRollup expiryDate(LocalDate expiryDate) {
        this.expiryDate = expiryDate;
        return this;
    }

    public void setExpiryDate(LocalDate expiryDate) {
        this.expiryDate = expiryDate;
    }

    public Integer getListOrder() {
        return listOrder;
    }

    public AspectRollup listOrder(Integer listOrder) {
        this.listOrder = listOrder;
        return this;
    }

    public void setListOrder(Integer listOrder) {
        this.listOrder = listOrder;
    }

    public Boolean isLocked() {
        return locked;
    }

    public AspectRollup locked(Boolean locked) {
        this.locked = locked;
        return this;
    }

    public void setLocked(Boolean locked) {
        this.locked = locked;
    }
    

    public String getCodePath() {
        return codePath;
    }

    public AspectRollup codePath(String codePath) {
        this.codePath = codePath;
        return this;
    }

    public void setCodePath(String codePath) {
        this.codePath = codePath;
    }

    public String getNamePath() {
        return namePath;
    }

    public AspectRollup namePath(String namePath) {
        this.namePath = namePath;
        return this;
    }

    public void setNamePath(String namePath) {
        this.namePath = namePath;
    }

    public Timestamp getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(Timestamp updatedDate) {
        this.updatedDate = updatedDate;
    }

    public Boolean getLocked() {
        return locked;
    }

    @PrePersist
    void onCreate() {
        defaults();
        calculated();
    }

    @PreUpdate
    void onUpdate() {
        calculated();
    }

    private void defaults() {
        // nothing to do
    }

    private void calculated() {
        this.setUpdatedDate(new Timestamp(System.currentTimeMillis()));
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        AspectRollup aspectRollup = (AspectRollup) o;
        if (aspectRollup.getId() == null || getId() == null) {
            return false;
        }
        return Objects.equals(getId(), aspectRollup.getId());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getId());
    }

    @Override
    public String toString() {
        return "AspectRollup [id=" + id + ", name=" + name + ", nameLocalization=" + nameLocalization + ", description="
                + description + ", effectiveDate=" + effectiveDate + ", expiryDate=" + expiryDate + ", listOrder="
                + listOrder + ", locked=" + locked + ", updatedDate=" + updatedDate + ", codePath=" + codePath
                + ", namePath=" + namePath + ", aspectCode=" + aspectCode + "]";
    }

   
}
