package com.advantagegroup.blue.console.domain;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.annotations.TypeDef;
import org.hibernate.annotations.TypeDefs;

import com.advantagegroup.blue.console.domain.type.StringJsonUserType;

@Entity
@Table(name = "aspectcode", schema = "blue")
@TypeDefs({ @TypeDef(name = "StringJsonObject", typeClass = StringJsonUserType.class) })
public class AspectCode implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(generator = "blue.aspectcode_id_seq")
    @SequenceGenerator(name = "blue.aspectcode_id_seq", sequenceName = "blue.aspectcode_id_seq")
    @Column(name = "aspectcode_id", unique = true, nullable = false)
    private Long id;

    @Column(name = "aspect_code", nullable = false)
    private String code;

    @Column(name = "aspect_description")
    private String description;

    @Column(name = "aspect_name", nullable = false)
    private String name;

    @Column(name = "aspect_name_localization", nullable = false)
    private String nameLocalization;

    @Column(name = "is_retired", nullable = false)
    private Boolean isRetired;

    @Column(name = "updated_timestamp", nullable = false)
    private Timestamp updatedDate;

    @OneToMany(mappedBy = "aspectCode", fetch = FetchType.LAZY)
    private List<Aspect> aspects = new ArrayList<>();

    @ManyToOne
    @JoinColumn(name = "aspecttype_id")
    private AspectType aspectType;

    @OneToMany(mappedBy = "aspectCode",fetch = FetchType.LAZY)
    private Set<AspectRollup> aspectRollups = new HashSet<>();

    public AspectCode() {

    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getNameLocalization() {
        return nameLocalization;
    }

    public void setNameLocalization(String nameLocalization) {
        this.nameLocalization = nameLocalization;
    }

    public Boolean getIsRetired() {
        return isRetired;
    }

    public void setIsRetired(Boolean isRetired) {
        this.isRetired = isRetired;
    }

    public Timestamp getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(Timestamp updatedDate) {
        this.updatedDate = updatedDate;
    }

    public List<Aspect> getAspects() {
        return aspects;
    }

    public void setAspects(List<Aspect> aspects) {
        this.aspects = aspects;
    }

    public Aspect addAspect(Aspect aspect) {
        getAspects().add(aspect);
        aspect.setAspectCode(this);

        return aspect;
    }

    public Aspect removeAspect(Aspect aspect) {
        getAspects().remove(aspect);
        aspect.setAspectCode(null);

        return aspect;
    }

    public AspectType getAspectType() {
        return aspectType;
    }

    public void setAspectType(AspectType aspectType) {
        this.aspectType = aspectType;
    }

    public Set<AspectRollup> getAspectRollups() {
        return aspectRollups;
    }

    public void setAspectRollups(Set<AspectRollup> aspectRollups) {
        this.aspectRollups = aspectRollups;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((aspectRollups == null) ? 0 : aspectRollups.hashCode());
        result = prime * result + ((aspectType == null) ? 0 : aspectType.hashCode());
        result = prime * result + ((aspects == null) ? 0 : aspects.hashCode());
        result = prime * result + ((code == null) ? 0 : code.hashCode());
        result = prime * result + ((description == null) ? 0 : description.hashCode());
        result = prime * result + ((id == null) ? 0 : id.hashCode());
        result = prime * result + ((isRetired == null) ? 0 : isRetired.hashCode());
        result = prime * result + ((name == null) ? 0 : name.hashCode());
        result = prime * result + ((nameLocalization == null) ? 0 : nameLocalization.hashCode());
        result = prime * result + ((updatedDate == null) ? 0 : updatedDate.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        AspectCode other = (AspectCode) obj;
        if (aspectRollups == null) {
            if (other.aspectRollups != null)
                return false;
        } else if (!aspectRollups.equals(other.aspectRollups))
            return false;
        if (aspectType == null) {
            if (other.aspectType != null)
                return false;
        } else if (!aspectType.equals(other.aspectType))
            return false;
        if (aspects == null) {
            if (other.aspects != null)
                return false;
        } else if (!aspects.equals(other.aspects))
            return false;
        if (code == null) {
            if (other.code != null)
                return false;
        } else if (!code.equals(other.code))
            return false;
        if (description == null) {
            if (other.description != null)
                return false;
        } else if (!description.equals(other.description))
            return false;
        if (id == null) {
            if (other.id != null)
                return false;
        } else if (!id.equals(other.id))
            return false;
        if (isRetired == null) {
            if (other.isRetired != null)
                return false;
        } else if (!isRetired.equals(other.isRetired))
            return false;
        if (name == null) {
            if (other.name != null)
                return false;
        } else if (!name.equals(other.name))
            return false;
        if (nameLocalization == null) {
            if (other.nameLocalization != null)
                return false;
        } else if (!nameLocalization.equals(other.nameLocalization))
            return false;
        if (updatedDate == null) {
            if (other.updatedDate != null)
                return false;
        } else if (!updatedDate.equals(other.updatedDate))
            return false;
        return true;
    }
}