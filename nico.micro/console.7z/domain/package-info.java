/**
 * JPA domain objects.
 */
package com.advantagegroup.blue.console.domain;
