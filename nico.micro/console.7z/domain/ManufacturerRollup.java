package com.advantagegroup.blue.console.domain;

import java.io.Serializable;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.SecondaryTable;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

/**
 * A ManufacturerRollup.
 */
@Entity
@Table(name = "manufacturerrollup", schema = "blue")
@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
@SecondaryTable(name = "manufacturerrollup_view", schema = "blue_console", pkJoinColumns = @PrimaryKeyJoinColumn(name = "manufacturerrollup_id"))
public class ManufacturerRollup implements Serializable {

	private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "manufacturerrollup_id")
    @GeneratedValue(generator = "companyrollup_id_seq")
    @SequenceGenerator(name = "companyrollup_id_seq", sequenceName = "companyrollup_id_seq", schema = "blue", allocationSize = 1)
    private Long id;

	@NotNull
	@Column(name = "manufacturer_name", nullable = false)
	private String name;

	@NotNull
	@Column(name = "manufacturer_name_localization", nullable = false)
	private String nameLocalization;

	@Column(name = "manufacturer_logo")
	private String logo;

	@Column(name = "manufacturer_description")
	private String description;

	@NotNull
	@Column(name = "effective_date", nullable = false)
	private LocalDate effectiveDate;

	@Column(name = "expiry_date")
	private LocalDate expiryDate;

	@NotNull
	@Column(name = "list_order", nullable = false)
	private Integer listOrder;

	@NotNull
	@Column(name = "locked", nullable = false)
	private Boolean locked;

	@ManyToOne(optional = false)
	@NotNull
	@JoinColumn(name = "manufacturercode_id")
	private ManufacturerCode manufacturerCode;

	@Column(table = "manufacturerrollup_view", name = "code_path", insertable = false, updatable = false)
	private String codePath;

	@Column(table = "manufacturerrollup_view", name = "name_path", insertable = false, updatable = false)
	private String namePath;

	@Column(name = "updated_timestamp")
	private Timestamp updatedDate;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public ManufacturerRollup name(String name) {
		this.name = name;
		return this;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getNameLocalization() {
		return nameLocalization;
	}

	public ManufacturerRollup nameLocalization(String nameLocalization) {
		this.nameLocalization = nameLocalization;
		return this;
	}

	public void setNameLocalization(String nameLocalization) {
		this.nameLocalization = nameLocalization;
	}

	public String getLogo() {
		return logo;
	}

	public ManufacturerRollup logo(String logo) {
		this.logo = logo;
		return this;
	}

	public void setLogo(String logo) {
		this.logo = logo;
	}

	public String getDescription() {
		return description;
	}

	public ManufacturerRollup description(String description) {
		this.description = description;
		return this;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public LocalDate getEffectiveDate() {
		return effectiveDate;
	}

	public ManufacturerRollup effectiveDate(LocalDate effectiveDate) {
		this.effectiveDate = effectiveDate;
		return this;
	}

	public void setEffectiveDate(LocalDate effectiveDate) {
		this.effectiveDate = effectiveDate;
	}

	public LocalDate getExpiryDate() {
		return expiryDate;
	}

	public ManufacturerRollup expiryDate(LocalDate expiryDate) {
		this.expiryDate = expiryDate;
		return this;
	}

	public void setExpiryDate(LocalDate expiryDate) {
		this.expiryDate = expiryDate;
	}

	public Integer getListOrder() {
		return listOrder;
	}

	public ManufacturerRollup listOrder(Integer listOrder) {
		this.listOrder = listOrder;
		return this;
	}

	public void setListOrder(Integer listOrder) {
		this.listOrder = listOrder;
	}

	public Boolean isLocked() {
		return locked;
	}

	public ManufacturerRollup locked(Boolean locked) {
		this.locked = locked;
		return this;
	}

	public void setLocked(Boolean locked) {
		this.locked = locked;
	}

	public String getNamePath() {
		return namePath;
	}

	public ManufacturerRollup namePath(String namePath) {
		this.namePath = namePath;
		return this;
	}

	public void setNamePath(String namePath) {
		this.namePath = namePath;
	}

	public String getCodePath() {
		return codePath;
	}

	public ManufacturerRollup codePath(String codePath) {
		this.codePath = codePath;
		return this;
	}

	public void setCodePath(String codePath) {
		this.codePath = codePath;
	}

	public ManufacturerCode getManufacturerCode() {
		return manufacturerCode;
	}

	public ManufacturerRollup manufacturerCode(ManufacturerCode manufacturerCode) {
		this.manufacturerCode = manufacturerCode;
		return this;
	}

	public void setManufacturerCode(ManufacturerCode manufacturerCode) {
		this.manufacturerCode = manufacturerCode;
	}

	public Timestamp getUpdatedDate() {
		return updatedDate;
	}

	public void setUpdatedDate(Timestamp updatedDate) {
		this.updatedDate = updatedDate;
	}

    public  Map<String, String> getManufacturerLocaleNamesMap() {
        Map<String, String> resultMap = new HashMap<>();
        if ( this.nameLocalization != null) {
            String trimmed = this.nameLocalization.replaceAll("\\{", "").replaceAll("\\}", "").replaceAll("\"", "").trim();
            String locales[] = trimmed.split(",");

            for (String str : locales) {
                String pair[] = str.split(":");
                if (pair.length == 2) {
                    resultMap.put(pair[0], pair[1]);
                }
            }
        }
        return resultMap;
    }

	@PrePersist
	void onCreate() {
		defaults();
		calculated();
	}

	@PreUpdate
	void onUpdate() {
		calculated();
	}

	private void defaults() {
		// nothing to do
	}

	private void calculated() {
		this.setUpdatedDate(new Timestamp(System.currentTimeMillis()));
	}

	@Override
	public boolean equals(Object o) {
		if (this == o) {
			return true;
		}
		if (o == null || getClass() != o.getClass()) {
			return false;
		}
		ManufacturerRollup manufacturerRollup = (ManufacturerRollup) o;
		if (manufacturerRollup.getId() == null || getId() == null) {
			return false;
		}
		return Objects.equals(getId(), manufacturerRollup.getId());
	}

	@Override
	public int hashCode() {
		return Objects.hashCode(getId());
	}

	@Override
	public String toString() {
		return "ManufacturerRollup{" + "id=" + getId() + ", name='" + getName() + "'" + ", nameLocalization='"
				+ getNameLocalization() + "'" + ", logo='" + getLogo() + "'" + ", description='" + getDescription()
				+ "'" + ", effectiveDate='" + getEffectiveDate() + "'" + ", expiryDate='" + getExpiryDate() + "'"
				+ ", listOrder='" + getListOrder() + "'" + ", locked='" + isLocked() + "'" + ", codePath='"
				+ getCodePath() + "'" + ", namePath='" + getNamePath() + "'" + "}";
	}
}
