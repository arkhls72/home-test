package com.advantagegroup.blue.console.domain;

import org.hibernate.annotations.Formula;
import org.springframework.cloud.cloudfoundry.com.fasterxml.jackson.annotation.JsonManagedReference;

import javax.persistence.*;
import javax.validation.constraints.*;
import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Objects;

@Entity
@Table(name = "surveypractice", schema = "blue")
public class SurveyPractice implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "surveypractice_id")
    @GeneratedValue(generator = "surveypractice_id_seq")
    @SequenceGenerator(name = "surveypractice_id_seq", sequenceName = "surveypractice_id_seq", schema = "blue", allocationSize = 1)
    private Long id;

    @NotNull
    @Column(name = "surveypractice_name", nullable = false)
    private String name;

    @NotNull
    @Column(name = "surveypractice_name_localization", nullable = false)
    private String nameLocalization;

    @NotNull
    @Column(name = "surveypractice_text", nullable = false)
    private String text;

    @NotNull
    @Column(name = "surveypractice_text_localization", nullable = false)
    private String textLocalization;

    @Column(name = "surveypractice_subtext")
    private String subText;

    @Column(name = "surveypractice_subtext_localization")
    private String subTextLocalization;

    @Column(name = "surveypractice_description")
    private String description;

    @NotNull
    @Column(name = "updated_timestamp", nullable = false)
    private Timestamp updatedDate;

    @ManyToOne
    @JsonManagedReference
    @JoinColumn(name = "survey_id", nullable = false)
    private Survey survey;

    @ManyToOne
    @JoinColumn(name = "practicerollup_id", nullable = false)
    private PracticeRollup practiceRollup;

    @Formula("(select sprv.NumberOfRatingResponses from blue_console.survey_practice_ratings_view sprv where sprv.surveypractice_id = surveypractice_id)")
    private Integer ratingCount;

    @Formula("(select spiv.numberofimportanceresponses from blue_console.survey_practice_importance_view spiv where spiv.surveypractice_id = surveypractice_id)")
    private Integer importanceCount;

    @Transient
    private boolean isDeletable;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public SurveyPractice name(String name) {
        this.name = name;
        return this;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getNameLocalization() {
        return nameLocalization;
    }

    public SurveyPractice nameLocalization(String nameLocalization) {
        this.nameLocalization = nameLocalization;
        return this;
    }

    public void setNameLocalization(String nameLocalization) {
        this.nameLocalization = nameLocalization;
    }

    public String getText() {
        return text;
    }

    public SurveyPractice text(String text) {
        this.text = text;
        return this;
    }

    public void setText(String text) {
        this.text = text;
    }

    public String getTextLocalization() {
        return textLocalization;
    }

    public SurveyPractice textLocalization(String textLocalization) {
        this.textLocalization = textLocalization;
        return this;
    }

    public void setTextLocalization(String textLocalization) {
        this.textLocalization = textLocalization;
    }

    public String getSubText() {
        return subText;
    }

    public SurveyPractice subText(String subText) {
        this.subText = subText;
        return this;
    }

    public void setSubText(String subText) {
        this.subText = subText;
    }

    public String getSubTextLocalization() {
        return subTextLocalization;
    }

    public SurveyPractice subTextLocalization(String subTextLocalization) {
        this.subTextLocalization = subTextLocalization;
        return this;
    }

    public void setSubTextLocalization(String subTextLocalization) {
        this.subTextLocalization = subTextLocalization;
    }

    public String getDescription() {
        return description;
    }

    public SurveyPractice description(String description) {
        this.description = description;
        return this;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Timestamp getUpdatedDate() {
        return updatedDate;
    }

    public SurveyPractice updatedDate(Timestamp updatedDate) {
        this.updatedDate = updatedDate;
        return this;
    }

    public void setUpdatedDate(Timestamp updatedDate) { this.updatedDate = updatedDate; }

    public Survey getSurvey() {
        return survey;
    }

    public void setSurvey(Survey survey) {
        this.survey = survey;
    }

    public PracticeRollup getPracticeRollup() {
        return practiceRollup;
    }

    public void setPracticeRollup(PracticeRollup practiceRollup) {
        this.practiceRollup = practiceRollup;
    }

    public Integer getRatingCount() { return ratingCount; }

    public void setRatingCount(Integer ratingCount) { this.ratingCount = ratingCount; }

    public Integer getImportanceCount() { return importanceCount; }

    public void setImportanceCount(Integer importanceCount) { this.importanceCount = importanceCount; }

    public boolean isDeletable() { return isDeletable; }

    public void setDeletable(boolean deletable) { isDeletable = deletable; }

    @PrePersist
    void onCreate() {
        defaults();
        calculated();
    }

    @PreUpdate
    void onUpdate() {
        calculated();
    }

    private void defaults() {
        // nothing to do
    }

    private void calculated() {
        this.setUpdatedDate(new Timestamp(System.currentTimeMillis()));
    }

    @PostLoad
    void onPostLoad() {
        if (this.getRatingCount() == 0 && this.getImportanceCount() == 0) {
            this.setDeletable(true);
        } else {
            this.setDeletable(false);
        }
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        SurveyPractice surveyPractice = (SurveyPractice) o;
        if (surveyPractice.getId() == null || getId() == null) {
            return false;
        }
        return Objects.equals(getId(), surveyPractice.getId());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getId());
    }

    @Override
    public String toString() {
        return "SurveyPractice{" +
            "id=" + getId() +
            ", name='" + getName() + "'" +
            ", nameLocalization='" + getNameLocalization() + "'" +
            ", text='" + getText() + "'" +
            ", textLocalization='" + getTextLocalization() + "'" +
            ", subText='" + getSubText() + "'" +
            ", subTextLocalization='" + getSubTextLocalization() + "'" +
            ", description='" + getDescription() + "'" +
            ", updatedDate='" + getUpdatedDate() + "'" +
            ", ratingCount='" + getRatingCount() + "'" +
            ", importanceCount='" + getImportanceCount() + "'" +
            "}";
    }
}
