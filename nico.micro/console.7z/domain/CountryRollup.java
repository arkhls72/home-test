package com.advantagegroup.blue.console.domain;

import java.io.Serializable;
import java.sql.Date;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.SecondaryTable;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.annotations.TypeDef;
import org.hibernate.annotations.TypeDefs;

import com.advantagegroup.blue.console.domain.type.StringJsonUserType;

@Entity
@Table(name = "countryrollup", schema = "blue")
@TypeDefs({ @TypeDef(name = "StringJson", typeClass = StringJsonUserType.class) })
@SecondaryTable(name = "countryrollup_view", schema = "blue_console", 
               pkJoinColumns = @PrimaryKeyJoinColumn(name = "countryrollup_id"))
public class CountryRollup implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "countryrollup_id")
    @GeneratedValue(generator = "countryrollup_id_seq")
    @SequenceGenerator(name = "countryrollup_id_seq", sequenceName = "countryrollup_id_seq", schema = "blue", allocationSize = 1)
    private Long id;

    @Column(name = "country_description")
    private String description;

    @Column(name = "country_name", nullable = false)
    private String name;

    @Column(name = "country_name_localization", nullable = false)
    private String nameLocalization;

    @Column(name = "effective_date", nullable = false)
    private Date effectiveDate;

    @Column(name = "expiry_date")
    private Date expiryDate;

    @Column(name = "updated_timestamp", nullable = false)
    private Timestamp updatedDate;

    @Column(nullable = false)
    private Boolean locked;

    @ManyToOne
    @JoinColumn(name = "country_id")
    private Country country;
    
    @ManyToOne
    @JoinColumn(name = "countrycode_id", nullable = false)
    private CountryCode countryCode;

    @Column( table = "countryrollup_view", name = "code_path", insertable = false, updatable = false )
    private String codePath;

    @Column( table = "countryrollup_view", name = "name_path", insertable = false, updatable = false )
    private String namePath;
    
    @Column(name = "rollup_root_id")
    private long rollupRootId;
    
    @Column(name = "rollup_parent_id", nullable=true)
    private Long rollupParentId;
    
    @Column(name = "rollup_left")
    private Long rollupLeft;

    @Column(name = "rollup_right")
    private Long rollupRight;
    
    
    public Long getId() {
        return this.id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getDescription() {
        return this.description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setNameLocalization(String nameLocalization) {
        this.nameLocalization = nameLocalization;
    }

    public Date getEffectiveDate() {
        return this.effectiveDate;
    }

    public void setEffectiveDate(Date effectiveDate) {
        this.effectiveDate = effectiveDate;
    }

    public Date getExpiryDate() {
        return this.expiryDate;
    }

    public void setExpiryDate(Date expiryDate) {
        this.expiryDate = expiryDate;
    }

    public Boolean getLocked() {
        return this.locked;
    }

    public void setLocked(Boolean locked) {
        this.locked = locked;
    }

    public CountryCode getCountryCode() {
        return this.countryCode;
    }

    public void setCountryCode(CountryCode countryCode) {
        this.countryCode = countryCode;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Timestamp getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(Timestamp updatedDate) {
        this.updatedDate = updatedDate;
    }

    public String getNameLocalization() {
        return nameLocalization;
    }

    public String getCodePath() {
        return codePath;
    }

    public void setCodePath(String codePath) {
        this.codePath = codePath;
    }

    public String getNamePath() {
        return namePath;
    }

    public void setNamePath(String namePath) {
        this.namePath = namePath;
    }

    public long getRollupRootId() {
        return rollupRootId;
    }

    public void setRollupRootId(Long rollupRootId) {
        this.rollupRootId = rollupRootId;
    }


    public Long getRollupParentId() {
        return rollupParentId;
    }

    public void setRollupParentId(Long rollupParentId) {
        this.rollupParentId = rollupParentId;
    }

    public Long getRollupLeft() {
        return rollupLeft;
    }

    public void setRollupLeft(Long rollupLeft) {
        this.rollupLeft = rollupLeft;
    }

    public long getRollupRight() {
        return rollupRight;
    }

    public void setRollupRight(Long rollupRight) {
        this.rollupRight = rollupRight;
    }

    public Country getCountry() {
        return country;
    }

    public void setCountry(Country country) {
        this.country = country;
    }

    public void setRollupRootId(long rollupRootId) {
        this.rollupRootId = rollupRootId;
    }

    @PrePersist
    void onCreate() {
        defaults();
        calculated();
    }

    @PreUpdate
    void onUpdate() {
        calculated();
    }

    private void defaults() {
        // nothing to do
    }

    private void calculated() {
        this.setUpdatedDate(new Timestamp(System.currentTimeMillis()));
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((codePath == null) ? 0 : codePath.hashCode());
        result = prime * result + ((countryCode == null) ? 0 : countryCode.hashCode());
        result = prime * result + ((description == null) ? 0 : description.hashCode());
        result = prime * result + ((effectiveDate == null) ? 0 : effectiveDate.hashCode());
        result = prime * result + ((expiryDate == null) ? 0 : expiryDate.hashCode());
        result = prime * result + ((id == null) ? 0 : id.hashCode());
        result = prime * result + ((locked == null) ? 0 : locked.hashCode());
        result = prime * result + ((name == null) ? 0 : name.hashCode());
        result = prime * result + ((nameLocalization == null) ? 0 : nameLocalization.hashCode());
        result = prime * result + ((namePath == null) ? 0 : namePath.hashCode());
        result = prime * result + ((updatedDate == null) ? 0 : updatedDate.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        CountryRollup other = (CountryRollup) obj;
        if (codePath == null) {
            if (other.codePath != null)
                return false;
        } else if (!codePath.equals(other.codePath))
            return false;
        if (countryCode == null) {
            if (other.countryCode != null)
                return false;
        } else if (!countryCode.equals(other.countryCode))
            return false;
        if (description == null) {
            if (other.description != null)
                return false;
        } else if (!description.equals(other.description))
            return false;
        if (effectiveDate == null) {
            if (other.effectiveDate != null)
                return false;
        } else if (!effectiveDate.equals(other.effectiveDate))
            return false;
        if (expiryDate == null) {
            if (other.expiryDate != null)
                return false;
        } else if (!expiryDate.equals(other.expiryDate))
            return false;
        if (id == null) {
            if (other.id != null)
                return false;
        } else if (!id.equals(other.id))
            return false;
        if (locked == null) {
            if (other.locked != null)
                return false;
        } else if (!locked.equals(other.locked))
            return false;
        if (name == null) {
            if (other.name != null)
                return false;
        } else if (!name.equals(other.name))
            return false;
        if (nameLocalization == null) {
            if (other.nameLocalization != null)
                return false;
        } else if (!nameLocalization.equals(other.nameLocalization))
            return false;
        if (namePath == null) {
            if (other.namePath != null)
                return false;
        } else if (!namePath.equals(other.namePath))
            return false;
        if (updatedDate == null) {
            if (other.updatedDate != null)
                return false;
        } else if (!updatedDate.equals(other.updatedDate))
            return false;
        return true;
    }

}
