package com.advantagegroup.blue.console.domain;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "aspecttype", schema = "blue")
public class AspectType implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "aspecttype_id")
    @GeneratedValue(generator = "blue.aspecttype_id_seq")
    @SequenceGenerator(name = "blue.aspecttype_id_seq", sequenceName = "blue.aspecttype_id_seq")
    private Long id;

    @Column(name = "aspecttype_description")
    private String description;

    @Column(name = "aspecttype_name", nullable = false)
    private String name;

    @Column(name = "is_retired", nullable = false)
    private Boolean isRetired;

    @Column(name = "updated_timestamp", nullable = false)
    private Timestamp updatedDate;

    @OneToMany(mappedBy = "aspectType",fetch = FetchType.LAZY)
    private Set<Aspect> aspects = new HashSet<>();

    @OneToMany(mappedBy = "aspectType",fetch = FetchType.LAZY)
    private Set<AspectCode> aspectCodes = new HashSet<>();

    public AspectType() {

    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Boolean getIsRetired() {
        return isRetired;
    }

    public void setIsRetired(Boolean isRetired) {
        this.isRetired = isRetired;
    }

    public Timestamp getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(Timestamp updatedDate) {
        this.updatedDate = updatedDate;
    }

    public Set<Aspect> getAspects() {
        return aspects;
    }

    public void setAspects(Set<Aspect> aspects) {
        this.aspects = aspects;
    }

    public Set<AspectCode> getAspectCodes() {
        return aspectCodes;
    }

    public void setAspectCodes(Set<AspectCode> aspectCodes) {
        this.aspectCodes = aspectCodes;
    }

    public Aspect removeAspect(Aspect aspect) {
        getAspects().remove(aspect);
        aspect.setAspectType(null);

        return aspect;
    }

    public AspectCode addAspectcode(AspectCode aspectcode) {
        getAspectCodes().add(aspectcode);
        aspectcode.setAspectType(this);

        return aspectcode;
    }

    public Aspect addAspect(Aspect aspect) {
        getAspects().add(aspect);
        aspect.setAspectType(this);

        return aspect;
    }

    public AspectCode removeAspectcode(AspectCode aspectcode) {
        getAspectCodes().remove(aspectcode);
        aspectcode.setAspectType(null);

        return aspectcode;
    }

    @PrePersist
    void onCreate() {
        this.setUpdatedDate(new Timestamp(System.currentTimeMillis()));
    }

    @PreUpdate
    void onUpdate() {
        this.setUpdatedDate(new Timestamp(System.currentTimeMillis()));
    }
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((aspectCodes == null) ? 0 : aspectCodes.hashCode());
        result = prime * result + ((aspects == null) ? 0 : aspects.hashCode());
        result = prime * result + ((description == null) ? 0 : description.hashCode());
        result = prime * result + ((id == null) ? 0 : id.hashCode());
        result = prime * result + ((isRetired == null) ? 0 : isRetired.hashCode());
        result = prime * result + ((name == null) ? 0 : name.hashCode());
        result = prime * result + ((updatedDate == null) ? 0 : updatedDate.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        AspectType other = (AspectType) obj;
        if (aspectCodes == null) {
            if (other.aspectCodes != null)
                return false;
        } else if (!aspectCodes.equals(other.aspectCodes))
            return false;
        if (aspects == null) {
            if (other.aspects != null)
                return false;
        } else if (!aspects.equals(other.aspects))
            return false;
        if (description == null) {
            if (other.description != null)
                return false;
        } else if (!description.equals(other.description))
            return false;
        if (id == null) {
            if (other.id != null)
                return false;
        } else if (!id.equals(other.id))
            return false;
        if (isRetired == null) {
            if (other.isRetired != null)
                return false;
        } else if (!isRetired.equals(other.isRetired))
            return false;
        if (name == null) {
            if (other.name != null)
                return false;
        } else if (!name.equals(other.name))
            return false;
        if (updatedDate == null) {
            if (other.updatedDate != null)
                return false;
        } else if (!updatedDate.equals(other.updatedDate))
            return false;
        return true;
    }
}