package com.advantagegroup.blue.console.domain;

import java.time.LocalDate;

import com.advantagegroup.blue.console.domain.type.ApprovalStatus;

/**
 * Used to specify a projection of the {@link Dataset} class. 
 * 
 * @author powellc
 *
 */
public interface DatasetSummary {

	Long getId();

	String getCode();

	String getName();

	String getDescription();

	LocalDate getEffectiveDate();

	LocalDate getExpiryDate();

	ApprovalStatus getApprovalStatus();

	Program getProgram();

}