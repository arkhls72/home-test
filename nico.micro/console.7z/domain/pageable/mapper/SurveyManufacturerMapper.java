package com.advantagegroup.blue.console.domain.pageable.mapper;

import java.util.HashMap;

public class SurveyManufacturerMapper {

    static private String codePath = "mv.code_path";
    static private String namePath = "mv.name_path";

    static private HashMap<String, String> mapper = new HashMap<String, String>() {{
        put("codePath", codePath);
        put("namePath", namePath);
    }};

    static public String get(String key) {
        return mapper.getOrDefault(key, codePath);
    }


}
