package com.advantagegroup.blue.console.domain.pageable.mapper;

import java.util.HashMap;

public class SurveyPracticeMapper {
    static private String codePath = "pv.code_path";
    static private String namePath = "pv.name_path";
    static private String text = "practice_text";
    static private String subText = "practice_subtext";

    static private HashMap<String, String> mapper = new HashMap<String, String>() {{
       put("codePath", codePath);
       put("namePath", namePath);
       put("text", text);
       put("subText", subText);
    }};

    static public String get(String key) {
        return mapper.getOrDefault(key, codePath);
    }
}
