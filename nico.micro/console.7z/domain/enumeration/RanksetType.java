package com.advantagegroup.blue.console.domain.enumeration;

import java.util.HashMap;
import java.util.Map;

/**
 * The RanksetType enumeration.
 */
public enum RanksetType {

	Core("Core"),  
    BusinessUnit("Business Unit"),  
    Category("Category");

	private static final Map<String, RanksetType> reverseLookup = new HashMap<String, RanksetType>();
	static {
		reverseLookup.put(Core.databaseValue, Core);
		reverseLookup.put(BusinessUnit.databaseValue, BusinessUnit);
		reverseLookup.put(Category.databaseValue, Category);
	};
	
	private final String databaseValue;
	
	private RanksetType(String databaseValue) {
		this.databaseValue = databaseValue;
	}

	public static RanksetType parse(String entity) {
		return reverseLookup.get(entity);
	}

	/**
	 * 
	 * @return The equivalent value for the datbase
	 */
	public String getDatabaseValue() {
		return databaseValue;
	}
}
