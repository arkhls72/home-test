package com.advantagegroup.blue.console.domain.enumeration;

public enum Trademark {
    Reg("Reg"),
    TM("TM");

    private String code;

    private Trademark(String code) {
        this.code = code;
    }

    public String getCode() {
        return this.code;
    }

    public static Trademark parse(String code) {

        for (Trademark item : Trademark.values()) {
            if (item.getCode().equals(code)) {
                return item;
            }
        }

        return null;
    }
}
