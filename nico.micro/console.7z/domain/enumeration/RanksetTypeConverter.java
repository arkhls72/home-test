package com.advantagegroup.blue.console.domain.enumeration;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

@Converter
public class RanksetTypeConverter implements AttributeConverter<RanksetType, String> {
	
    @Override
    public String convertToDatabaseColumn(RanksetType approvalStatus) {
        if (approvalStatus == null) {
            return null;
        }
        return approvalStatus.getDatabaseValue();
    }

    @Override
    public RanksetType convertToEntityAttribute(String entity) {
        if( entity == null ) {
            return null;
        }
        return RanksetType.parse(entity);
    }
}
