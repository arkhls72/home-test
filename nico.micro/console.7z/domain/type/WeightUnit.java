package com.advantagegroup.blue.console.domain.type;

/**
 * CREATE TYPE weight_unit_enum AS ENUM ( 'EUR', 'JPY', 'AUD', 'CNY', 'USD', 'Percentage', 'Custom' );
 */
public enum WeightUnit {
    EUR("EUR"),
    JPY("JPY"),
    AUD("AUD"),
    CNY("CNY"),
    USD("USD"),
    Percentage("Percentage"),
    Custom("Custom");

    private String weightUnit;

    private WeightUnit(String weightUnit) {
        this.weightUnit = weightUnit;
    }

    public String getWeightUnitAsString() {
        return this.weightUnit;
    }

    public static WeightUnit parse(String weightUnit) {
        if( EUR.weightUnit.equals( weightUnit ) ) {
            return EUR;
        } else if( JPY.weightUnit.equals( weightUnit ) ) {
            return JPY;
        } else if( AUD.weightUnit.equals( weightUnit ) ) {
            return AUD;
        } else if( CNY.weightUnit.equals( weightUnit ) ) {
            return CNY;
        } else if( USD.weightUnit.equals( weightUnit ) ) {
            return USD;
        } else if( Percentage.weightUnit.equals( weightUnit ) ) {
            return Percentage;
        } else if( Custom.weightUnit.equals( weightUnit ) ) {
            return Custom;
        }
        throw new IllegalArgumentException( "Unknown weight unit '" + weightUnit + "'." );
    }
}
