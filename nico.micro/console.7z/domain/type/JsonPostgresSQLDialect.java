package com.advantagegroup.blue.console.domain.type;

/**
 * @author Ara Khalesi 
 * April, 2017
 */
import java.sql.Types;

import org.hibernate.dialect.PostgreSQL9Dialect;

public class JsonPostgresSQLDialect extends PostgreSQL9Dialect {

    public JsonPostgresSQLDialect() {
        super();
        this.registerColumnType(Types.JAVA_OBJECT, "json");
    }
}