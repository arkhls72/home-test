package com.advantagegroup.blue.console.domain.type;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

import com.advantagegroup.blue.console.domain.enumeration.Trademark;


@Converter
public class TrademarkType implements AttributeConverter<Trademark, String> {

    @Override
    public String convertToDatabaseColumn(Trademark trademark) {

        if (trademark == null) {
            return null;
        }

        switch (trademark) {
            case Reg:
                return Trademark.Reg.getCode();

            case TM:
                return Trademark.TM.getCode();

            default:
                throw new IllegalArgumentException("Unknown:" + trademark);
        }
    }

    @Override
    public Trademark convertToEntityAttribute(String entity) {
        Trademark entityCode = Trademark.parse(entity);

        if (entityCode == null) {
            return null;
        }

        return entityCode;
    }

}
