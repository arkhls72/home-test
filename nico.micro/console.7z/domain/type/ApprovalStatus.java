package com.advantagegroup.blue.console.domain.type;

public enum ApprovalStatus {
    Under_Construction("Under Construction"),
    Ready_for_Approval("Ready for Approval"),
    Approved("Approved");

    private String approvalStatus;

    private ApprovalStatus(String approvalStatus) {
        this.approvalStatus = approvalStatus;
    }

    public String getApprovalStatusAsString() {
        return this.approvalStatus;
    }

    public static ApprovalStatus parse(String approvalStatus) {
        if( Under_Construction.approvalStatus.equals( approvalStatus ) ) {
            return Under_Construction;
        } else if( Ready_for_Approval.approvalStatus.equals( approvalStatus ) ) {
            return Ready_for_Approval;
        } else if( Approved.approvalStatus.equals( approvalStatus ) ) {
            return Approved;
        }
        throw new IllegalArgumentException( "Unknown approval status '" + approvalStatus + "'." );
    }
}
