package com.advantagegroup.blue.console.domain.type;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

@Converter
public class WeightUnitType implements AttributeConverter<WeightUnit, String> {
    @Override
    public String convertToDatabaseColumn(WeightUnit weightUnit) {
        if (weightUnit == null) {
            return null;
        }
        return weightUnit.getWeightUnitAsString();
    }

    @Override
    public WeightUnit convertToEntityAttribute(String entity) {
        if( entity == null ) {
            return null;
        }
        return WeightUnit.parse(entity);
    }
}
