package com.advantagegroup.blue.console.domain.type;

import java.io.Serializable;

public class JsonLocale implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String en;

	public String getEn() {
		return en;
	}

	public void setEn(String en) {
		this.en = en;
	}
	public JsonLocale(String en) {
		this.en=en;
	}
}
