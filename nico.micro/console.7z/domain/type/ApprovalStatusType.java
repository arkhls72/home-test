package com.advantagegroup.blue.console.domain.type;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

@Converter
public class ApprovalStatusType implements AttributeConverter<ApprovalStatus, String> {
    @Override
    public String convertToDatabaseColumn(ApprovalStatus approvalStatus) {
        if (approvalStatus == null) {
            return null;
        }
        return approvalStatus.getApprovalStatusAsString();
    }

    @Override
    public ApprovalStatus convertToEntityAttribute(String entity) {
        if( entity == null ) {
            return null;
        }
        return ApprovalStatus.parse(entity);
    }
}
