package com.advantagegroup.blue.console.domain;



import javax.persistence.*;
import javax.validation.constraints.*;
import java.io.Serializable;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.util.Objects;

/**
 * A RetailUnit.
 */
@Entity
@Table(name = "retailunit", schema="blue")
public class RetailUnit implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @Column(name="retailunit_id")
    @GeneratedValue(generator = "companyunit_id_seq")
    @SequenceGenerator(name = "companyunit_id_seq", sequenceName = "companyunit_id_seq", schema = "blue", allocationSize = 1)
    private Long id;

    @NotNull
    @Column(name = "retailcode_id", nullable = false)
    private Long retailCodeId;

    @NotNull
    @Column(name = "country_id", nullable = false)
    private Long countryId;

    @Column(name = "retail_description")
    private String description;

    @NotNull
    @Column(name = "revenue_unit", nullable = false)
    private Boolean revenueUnit;

    @NotNull
    @Column(name = "effective_date", nullable = false)
    private LocalDate effectiveDate;

    @Column(name = "expiry_date")
    private LocalDate expiryDate;

    @Column(name = "updated_timestamp")
    private Timestamp updatedDate;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getRetailCodeId() {
        return retailCodeId;
    }

    public RetailUnit retailCodeId(Long retailCodeId) {
        this.retailCodeId = retailCodeId;
        return this;
    }

    public void setRetailCodeId(Long retailCodeId) {
        this.retailCodeId = retailCodeId;
    }

    public Long getCountryId() {
        return countryId;
    }

    public RetailUnit countryId(Long countryId) {
        this.countryId = countryId;
        return this;
    }

    public void setCountryId(Long countryId) {
        this.countryId = countryId;
    }

    public String getDescription() {
        return description;
    }

    public RetailUnit description(String description) {
        this.description = description;
        return this;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Boolean isRevenueUnit() {
        return revenueUnit;
    }

    public RetailUnit revenueUnit(Boolean revenueUnit) {
        this.revenueUnit = revenueUnit;
        return this;
    }

    public void setRevenueUnit(Boolean revenueUnit) {
        this.revenueUnit = revenueUnit;
    }

    public LocalDate getEffectiveDate() {
        return effectiveDate;
    }

    public RetailUnit effectiveDate(LocalDate effectiveDate) {
        this.effectiveDate = effectiveDate;
        return this;
    }

    public void setEffectiveDate(LocalDate effectiveDate) {
        this.effectiveDate = effectiveDate;
    }

    public LocalDate getExpiryDate() {
        return expiryDate;
    }

    public RetailUnit expiryDate(LocalDate expiryDate) {
        this.expiryDate = expiryDate;
        return this;
    }

    public void setExpiryDate(LocalDate expiryDate) {
        this.expiryDate = expiryDate;
    }

    public Timestamp getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(Timestamp updatedDate) {
        this.updatedDate = updatedDate;
    }

    @PrePersist
    void onCreate() {
        this.setUpdatedDate(new Timestamp(System.currentTimeMillis()));
    }

    @PreUpdate
    void onUpdate() {
        this.setUpdatedDate(new Timestamp(System.currentTimeMillis()));
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        RetailUnit retailUnit = (RetailUnit) o;
        if (retailUnit.getId() == null || getId() == null) {
            return false;
        }
        return Objects.equals(getId(), retailUnit.getId());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getId());
    }

    @Override
    public String toString() {
        return "RetailUnit{" +
            "id=" + getId() +
            ", retailCodeId='" + getRetailCodeId() + "'" +
            ", countryId='" + getCountryId() + "'" +
            ", description='" + getDescription() + "'" +
            ", revenueUnit='" + isRevenueUnit() + "'" +
            ", effectiveDate='" + getEffectiveDate() + "'" +
            ", expiryDate='" + getExpiryDate() + "'" +
            "}";
    }
}
