package com.advantagegroup.blue.console.domain;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

/**
 * A ManufacturerCode.
 */
@Entity
@Table(name = "manufacturercode", schema = "blue")
public class ManufacturerCode implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "manufacturercode_id")
    @GeneratedValue(generator = "companycode_id_seq")
    @SequenceGenerator(name = "companycode_id_seq", sequenceName = "companycode_id_seq", schema = "blue", allocationSize = 1)
    private Long id;

    @NotNull
    @Column(name = "manufacturer_code", nullable = false)
    private String code;

    @NotNull
    @Column(name = "manufacturer_name", nullable = false)
    private String name;

    @NotNull
    @Column(name = "manufacturer_name_localization", nullable = false)
    private String nameLocalization;

    @Column(name = "manufacturer_logo")
    private String logo;

    @Column(name = "manufacturer_description")
    private String description;

    @NotNull
    @Column(name = "unitidentifier", nullable = false)
    private Boolean unitIdentifier;

    @NotNull
    @Column(name = "is_retired", nullable = false)
    private Boolean retired;

    @Column(name = "updated_timestamp")
    private Timestamp updatedDate;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getCode() {
        return code;
    }

    public ManufacturerCode code(String code) {
        this.code = code;
        return this;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public ManufacturerCode name(String name) {
        this.name = name;
        return this;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getNameLocalization() {
        return nameLocalization;
    }

    public ManufacturerCode nameLocalization(String nameLocalization) {
        this.nameLocalization = nameLocalization;
        return this;
    }

    public void setNameLocalization(String nameLocalization) {
        this.nameLocalization = nameLocalization;
    }

    public String getLogo() {
        return logo;
    }

    public ManufacturerCode logo(String logo) {
        this.logo = logo;
        return this;
    }

    public void setLogo(String logo) {
        this.logo = logo;
    }

    public String getDescription() {
        return description;
    }

    public ManufacturerCode description(String description) {
        this.description = description;
        return this;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Boolean isUnitIdentifier() {
        return unitIdentifier;
    }

    public ManufacturerCode unitIdentifier(Boolean unitIdentifier) {
        this.unitIdentifier = unitIdentifier;
        return this;
    }

    public void setUnitIdentifier(Boolean unitIdentifier) {
        this.unitIdentifier = unitIdentifier;
    }

    public Boolean isRetired() {
        return retired;
    }

    public ManufacturerCode retired(Boolean retired) {
        this.retired = retired;
        return this;
    }

    public void setRetired(Boolean retired) {
        this.retired = retired;
    }

    public Timestamp getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(Timestamp updatedDate) {
        this.updatedDate = updatedDate;
    }

    @PrePersist
    void onCreate() {
        defaults();
        calculated();
    }

    @PreUpdate
    void onUpdate() {
        calculated();
    }

    private void defaults() {
        // nothing to do
    }

    private void calculated() {
        this.setUpdatedDate(new Timestamp(System.currentTimeMillis()));
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        ManufacturerCode manufacturerCode = (ManufacturerCode) o;
        if (manufacturerCode.getId() == null || getId() == null) {
            return false;
        }
        return Objects.equals(getId(), manufacturerCode.getId());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getId());
    }

    @Override
    public String toString() {
        return "ManufacturerCode{" +
            "id=" + getId() +
            ", code='" + getCode() + "'" +
            ", name='" + getName() + "'" +
            ", nameLocalization='" + getNameLocalization() + "'" +
            ", logo='" + getLogo() + "'" +
            ", description='" + getDescription() + "'" +
            ", unitIdentifier='" + isUnitIdentifier() + "'" +
            ", retired='" + isRetired() + "'" +
            "}";
    }
}
