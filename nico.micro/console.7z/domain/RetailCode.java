package com.advantagegroup.blue.console.domain;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.annotations.TypeDef;
import org.hibernate.annotations.TypeDefs;


import com.advantagegroup.blue.console.domain.type.StringJsonUserType;

/**
 * A RetailCode.
 */
@Entity
@Table(name = "retailcode",schema="blue")
@TypeDefs({ @TypeDef(name = "StringJson", typeClass = StringJsonUserType.class) })
public class RetailCode implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @Column(name="retailcode_id")
    @GeneratedValue(generator = "companycode_id_seq")
    @SequenceGenerator(name = "companycode_id_seq", sequenceName = "companycode_id_seq", schema = "blue", allocationSize = 1)
    private Long id;

    @Column(name = "retailgroup_id")
    private Long groupId;

    @Column(name = "retail_code", nullable=false)
    private String code;

    @Column(name = "retail_name", nullable=false)
    private String name;

    @Column(name = "retail_description")
    private String description;

    @Column(name = "unitidentifier" ,nullable = false)
    private Boolean unitIdentifier;

    @Column(name = "retail_name_localization", nullable = false)
    private String nameLocalization;

    @Column(name = "is_retired",nullable = false)
    private Boolean isRetired;

    @Column(name = "updated_timestamp")
    private Timestamp updatedDate;

    @PrePersist
    void onCreate() {
       this.setUpdatedDate(new Timestamp(System.currentTimeMillis()));
    }

    @PreUpdate
    void onUpdate() {
        this.setUpdatedDate(new Timestamp(System.currentTimeMillis()));
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getGroupId() {
        return groupId;
    }

    public RetailCode groupId(Long groupId) {
        this.groupId = groupId;
        return this;
    }

    public void setGroupId(Long groupId) {
        this.groupId = groupId;
    }

    public String getCode() {
        return code;
    }

    public RetailCode code(String code) {
        this.code = code;
        return this;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public RetailCode name(String name) {
        this.name = name;
        return this;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public RetailCode description(String description) {
        this.description = description;
        return this;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Boolean isUnitIdentifier() {
        return unitIdentifier;
    }

    public RetailCode unitIdentifier(Boolean unitIdentifier) {
        this.unitIdentifier = unitIdentifier;
        return this;
    }

    public void setUnitIdentifier(Boolean unitIdentifier) {
        this.unitIdentifier = unitIdentifier;
    }

    public Boolean isIsRetired() {
        return isRetired;
    }

    public RetailCode isRetired(Boolean isRetired) {
        this.isRetired = isRetired;
        return this;
    }

    public void setIsRetired(Boolean isRetired) {
        this.isRetired = isRetired;
    }

    public String getNameLocalization() {
        return nameLocalization;
    }

    public RetailCode nameLocalization(String nameLocalization) {
        this.nameLocalization = nameLocalization;
        return this;
    }

    public void setNameLocalization(String nameLocalization) {
        this.nameLocalization = nameLocalization;
    }

    public Boolean getUnitIdentifier() {
        return unitIdentifier;
    }

    public Boolean getIsRetired() {
        return isRetired;
    }

    public Timestamp getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(Timestamp updatedDate) {
        this.updatedDate = updatedDate;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        RetailCode retailCode = (RetailCode) o;
        if (retailCode.getId() == null || getId() == null) {
            return false;
        }
        return Objects.equals(getId(), retailCode.getId());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getId());
    }

    @Override
    public String toString() {
        return "RetailCode{" +
            "id=" + getId() +
            ", groupId='" + getGroupId() + "'" +
            ", code='" + getCode() + "'" +
            ", name='" + getName() + "'" +
            ", description='" + getDescription() + "'" +
            ", unitIdentifier='" + isUnitIdentifier() + "'" +
            ", isRetired='" + isIsRetired() + "'" +
            "}";
    }
}
