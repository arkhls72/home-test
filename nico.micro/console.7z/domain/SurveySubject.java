package com.advantagegroup.blue.console.domain;

import org.hibernate.annotations.Formula;
import org.springframework.cloud.cloudfoundry.com.fasterxml.jackson.annotation.JsonManagedReference;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

import javax.persistence.*;
import javax.validation.constraints.NotNull;

@Entity
@Table(name = "surveysubject", schema = "blue")
public class SurveySubject implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "surveysubject_id")
    @GeneratedValue(generator = "surveysubject_id_seq")
    @SequenceGenerator(name = "surveysubject_id_seq", sequenceName = "surveysubject_id_seq", schema = "blue", allocationSize = 1)
    private Long id;

    @Column(name = "updated_timestamp", nullable = false)
    private Timestamp updatedDate;

    @ManyToOne
    @JsonManagedReference
    @JoinColumn(name = "survey_id", nullable = false)
    private Survey survey;

    @ManyToOne
    @JoinColumn(name = "manufacturerrollup_id", nullable = false)
    private ManufacturerRollup manufacturerRollup;

    @Column(name = "sponsor_priority")
    private String sponsorPriority;

    @NotNull
    @Column(name = "surveysubject_name", nullable = false)
    private String name;

    @NotNull
    @Column(name = "surveysubject_name_localization", nullable = false)
    private String nameLocalization;

    @Column(name = "surveysubject_description")
    private String description;

    @Formula("(select srw.count from blue_console.surveyresponse_view srw where srw.surveysubject_id = surveysubject_id)")
    private Integer referenceCount;

    @Transient
    private boolean isDeletable;

    public SurveySubject() {
    }

    public Long getId() {
        return this.id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Survey getSurvey() {
        return this.survey;
    }

    public void setSurvey(Survey survey) {
        this.survey = survey;
    }

    public Timestamp getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(Timestamp updatedDate) {
        this.updatedDate = updatedDate;
    }

    public ManufacturerRollup getManufacturerRollup() {
        return manufacturerRollup;
    }

    public void setManufacturerRollup(ManufacturerRollup manufacturerRollup) {
        this.manufacturerRollup = manufacturerRollup;
    }

    public String getSponsorPriority() {
        return sponsorPriority;
    }

    public void setSponsorPriority(String sponsorPriority) {
        this.sponsorPriority = sponsorPriority;
    }

    public String getName() {
        return name;
    }

    public SurveySubject name(String name) {
        this.name = name;
        return this;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getNameLocalization() {
        return nameLocalization;
    }

    public SurveySubject nameLocalization(String nameLocalization) {
        this.nameLocalization = nameLocalization;
        return this;
    }

    public void setNameLocalization(String nameLocalization) {
        this.nameLocalization = nameLocalization;
    }

    public String getDescription() {
        return description;
    }

    public SurveySubject description(String description) {
        this.description = description;
        return this;
    }

    public Integer getReferenceCount() {
        return referenceCount;
    }

    public void setReferenceCount(Integer referenceCount) {
        this.referenceCount = referenceCount;
    }

    public boolean isDeletable() {
        return isDeletable;
    }

    public void setDeletable(boolean deletable) {
        isDeletable = deletable;
    }

    public Map<String, String> getSurveySubjectNamesMap() {
        Map<String, String> resultMap = new HashMap<>();
        if (this.nameLocalization != null) {
            String trimmed = this.nameLocalization.replaceAll("\\{", "").replaceAll("\\}", "").replaceAll("\"", "").trim();
            String locales[] = trimmed.split(",");

            for (String str : locales) {
                String pair[] = str.split(":");
                if (pair.length == 2) {
                    resultMap.put(pair[0], pair[1]);
                }
            }
        }
        return resultMap;
    }

    @PrePersist
    void onCreate() {
        defaults();
        calculated();
    }

    @PreUpdate
    void onUpdate() {
        calculated();
    }

    private void defaults() {
        // nothing to do
    }

    private void calculated() {
        this.setUpdatedDate(new Timestamp(System.currentTimeMillis()));
    }

    @PostLoad
    void onPostLoad() {
        if (this.getReferenceCount() == 0) {
            this.isDeletable = true;
        }
        else {
            this.isDeletable = false;
        }
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        SurveySubject surveySubject = (SurveySubject) o;
        if (surveySubject.getId() == null || getId() == null) {
            return false;
        }
        return Objects.equals(getId(), surveySubject.getId());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getId());
    }


    @Override
    public String toString() {
        return "SurveySubject{" +
            "id=" + id +
            ", updatedDate=" + updatedDate +
            ", survey=" + survey +
            ", sponsorPriority='" + sponsorPriority + '\'' +
            ", name='" + name + '\'' +
            ", nameLocalization='" + nameLocalization + '\'' +
            ", description='" + description + '\'' +
            '}';
    }
}
