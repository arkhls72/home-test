package com.advantagegroup.blue.console.domain;

/**
 * @author Ara khalesi
 * May , 2017 
 * 
 */
import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "aspect", schema = "blue")
public class Aspect implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "aspect_id")
    @GeneratedValue(generator = "blue.aspect_id_seq")
    @SequenceGenerator(name = "blue.aspect_id_seq", sequenceName = "blue.aspect_id_seq")
    private Long id;

    @Column(name = "aspect_description")
    private String description;

    @Column(name = "is_retired", nullable = false)
    private Boolean isRetired;

    @Column(name = "updated_timestamp", nullable = false)
    private Timestamp updatedDate;

    @ManyToOne
    @JoinColumn(name = "aspectcode_id", nullable = false)
    private AspectCode aspectCode;

    @ManyToOne
    @JoinColumn(name = "aspecttype_id", nullable = false)
    private AspectType aspectType;


    public Aspect() {

    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Boolean getIsRetired() {
        return isRetired;
    }

    public void setIsRetired(Boolean isRetired) {
        this.isRetired = isRetired;
    }

    public Timestamp getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(Timestamp updatedDate) {
        this.updatedDate = updatedDate;
    }

    public AspectCode getAspectCode() {
        return aspectCode;
    }

    public void setAspectCode(AspectCode aspectCode) {
        this.aspectCode = aspectCode;
    }

    public AspectType getAspectType() {
        return aspectType;
    }

    public void setAspectType(AspectType aspectType) {
        this.aspectType = aspectType;
    }

    @PrePersist
    void onCreate() {
        this.setUpdatedDate(new Timestamp(System.currentTimeMillis()));
    }

    @PreUpdate
    void onUpdate() {
        this.setUpdatedDate(new Timestamp(System.currentTimeMillis()));
    }

    

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((aspectCode == null) ? 0 : aspectCode.hashCode());
        result = prime * result + ((aspectType == null) ? 0 : aspectType.hashCode());
        result = prime * result + ((description == null) ? 0 : description.hashCode());
        result = prime * result + ((id == null) ? 0 : id.hashCode());
        result = prime * result + ((isRetired == null) ? 0 : isRetired.hashCode());
        result = prime * result + ((updatedDate == null) ? 0 : updatedDate.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        Aspect other = (Aspect) obj;
        if (aspectCode == null) {
            if (other.aspectCode != null)
                return false;
        } else if (!aspectCode.equals(other.aspectCode))
            return false;
        
        if (aspectType == null) {
            if (other.aspectType != null)
                return false;
        } else if (!aspectType.equals(other.aspectType))
            return false;
        if (description == null) {
            if (other.description != null)
                return false;
        } else if (!description.equals(other.description))
            return false;
        if (id == null) {
            if (other.id != null)
                return false;
        } else if (!id.equals(other.id))
            return false;
        if (isRetired == null) {
            if (other.isRetired != null)
                return false;
        } else if (!isRetired.equals(other.isRetired))
            return false;
        if (updatedDate == null) {
            if (other.updatedDate != null)
                return false;
        } else if (!updatedDate.equals(other.updatedDate))
            return false;
        return true;
    }
}