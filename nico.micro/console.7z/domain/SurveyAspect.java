package com.advantagegroup.blue.console.domain;

/**
 * @author Ara khalesi
 * May , 2017 
 * 
 */
import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.annotations.TypeDef;
import org.hibernate.annotations.TypeDefs;

import com.advantagegroup.blue.console.domain.type.StringJsonUserType;

@Entity
@Table(name = "surveyaspect", schema = "blue")
@TypeDefs({ @TypeDef(name = "StringJsonObject", typeClass = StringJsonUserType.class) })
public class SurveyAspect implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "surveyaspect_id")
    @GeneratedValue(generator = "blue.surveyaspect_id_seq")
    @SequenceGenerator(name = "blue.surveyaspect_id_seq", sequenceName = "surveyaspect_id_seq",schema = "blue",allocationSize = 1)
    private Long id;

    @Column(name = "aspect_description")
    private String description;

    @Column(name = "aspect_name", nullable = false)
    private String name;

    @Column(name = "aspect_name_localization", nullable = false)
    private String nameLocalization;

    @Column(name = "confirmit_code", nullable = false)
    private Double confirmitCode;

    @Column(name = "updated_timestamp", nullable = false)
    private Timestamp updatedDate;

    @ManyToOne
    @JoinColumn(name = "aspectrollup_id", nullable = false)
    private AspectRollup aspectRollup;

    @ManyToOne
    @JoinColumn(name = "survey_id", nullable = false)
    private Survey survey;

    public SurveyAspect() {

    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getNameLocalization() {
        return nameLocalization;
    }

    public void setNameLocalization(String nameLocalization) {
        this.nameLocalization = nameLocalization;
    }

    public Double getConfirmitCode() {
        return confirmitCode;
    }

    public void setConfirmitCode(Double confirmitCode) {
        this.confirmitCode = confirmitCode;
    }

    public Timestamp getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(Timestamp updatedDate) {
        this.updatedDate = updatedDate;
    }

    public AspectRollup getAspectRollup() {
        return aspectRollup;
    }

    public void setAspectRollup(AspectRollup aspectRollup) {
        this.aspectRollup = aspectRollup;
    }

    public Survey getSurvey() {
        return survey;
    }

    public void setSurvey(Survey survey) {
        this.survey = survey;
    }

    @PrePersist
    void onCreate() {
        this.setUpdatedDate(new Timestamp(System.currentTimeMillis()));
    }

    @PreUpdate
    void onUpdate() {
        this.setUpdatedDate(new Timestamp(System.currentTimeMillis()));
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getId());
    }

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		SurveyAspect other = (SurveyAspect) obj;
		if (aspectRollup == null) {
			if (other.aspectRollup != null)
				return false;
		} else if (!aspectRollup.equals(other.aspectRollup))
			return false;
		if (confirmitCode == null) {
			if (other.confirmitCode != null)
				return false;
		} else if (!confirmitCode.equals(other.confirmitCode))
			return false;
		if (description == null) {
			if (other.description != null)
				return false;
		} else if (!description.equals(other.description))
			return false;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		if (nameLocalization == null) {
			if (other.nameLocalization != null)
				return false;
		} else if (!nameLocalization.equals(other.nameLocalization))
			return false;
		if (survey == null) {
			if (other.survey != null)
				return false;
		} else if (!survey.equals(other.survey))
			return false;
		if (updatedDate == null) {
			if (other.updatedDate != null)
				return false;
		} else if (!updatedDate.equals(other.updatedDate))
			return false;
		return true;
	}

   

    
}