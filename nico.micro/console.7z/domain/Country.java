package com.advantagegroup.blue.console.domain;

/**
 * @author Ara Khalesi
 */
import java.io.Serializable;
import java.sql.Timestamp;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.*;

import org.hibernate.annotations.TypeDef;
import org.hibernate.annotations.TypeDefs;

import com.advantagegroup.blue.console.domain.type.StringJsonUserType;

@Entity
@Table(name = "country", schema = "blue")
@TypeDefs({ @TypeDef(name = "StringJsonObject", typeClass = StringJsonUserType.class) })
public class Country implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "country_id")
    @GeneratedValue(generator = "country_id_seq")
    @SequenceGenerator(name = "country_id_seq", sequenceName = "country_id_seq", schema = "blue", allocationSize = 1)
    private Long id;

	@Column(name = "country_description")
	private String description;

	@Column(name = "is_retired", nullable = false)
	private Boolean isRetired;

	@Column(name = "updated_timestamp", nullable = false)
	private Timestamp updatedDate;

	@ManyToOne
	@JoinColumn(name = "countrycode_id", nullable = false)
	private CountryCode countryCode;

	

	public Boolean getIsRetired() {
        return isRetired;
    }

    public void setIsRetired(Boolean isRetired) {
        this.isRetired = isRetired;
    }

    public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public CountryCode getCountryCode() {
		return countryCode;
	}

	public void setCountryCode(CountryCode countryCode) {
		this.countryCode = countryCode;
	}

    public Timestamp getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(Timestamp updatedDate) {
        this.updatedDate = updatedDate;
    }

    @PrePersist
    void onCreate() {
        calculated();
    }

    @PreUpdate
    void onUpdate() {
        calculated();
    }

    private void calculated() {
        this.setUpdatedDate(new Timestamp(System.currentTimeMillis()));
    }
}
