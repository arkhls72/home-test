package com.advantagegroup.blue.console.domain;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.HashSet;
import java.util.Objects;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

/**
 * A DatasetWeightType.
 */
@Entity
@Table(name = "datasetweighttype", schema = "blue")
public class DatasetWeightType implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "datasetweighttype_id")
    @GeneratedValue(generator = "datasetweighttype_id_seq")
    @SequenceGenerator(name = "datasetweighttype_id_seq", sequenceName = "datasetweighttype_id_seq", schema = "blue", allocationSize = 1)
    private Long id;

    @NotNull
    @Column(name = "datasetweighttype_name", nullable = false)
    private String name;

    @Column(name = "datasetweighttype_description")
    private String description;
    
    @NotNull
    @Column(name = "dataset_id", nullable=false)
    private Long datasetId;

    @NotNull
    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name="companyweighttype_id")
    private CompanyWeightType companyWeightType;
    
    @OneToOne
    @JoinColumn(unique = true, name="rankset_id", referencedColumnName="rankset_id") //, updatable=false)?
    private Rankset restrictedToRankset;

    @OneToMany(mappedBy = "datasetWeightType", orphanRemoval = true, cascade = CascadeType.ALL)
    private Set<RetailRevenueWeight> retailRevenueWeights = new HashSet<>();

    @Column(name = "updated_timestamp")
    private Timestamp updatedDate;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public DatasetWeightType name(String name) {
        this.name = name;
        return this;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public DatasetWeightType description(String description) {
        this.description = description;
        return this;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public CompanyWeightType getCompanyWeightType() {
        return companyWeightType;
    }

    public DatasetWeightType companyWeightType(CompanyWeightType companyWeightType) {
        this.companyWeightType = companyWeightType;
        return this;
    }

    public void setCompanyWeightType(CompanyWeightType companyWeightType) {
        this.companyWeightType = companyWeightType;
    }

    public Rankset getRestrictedToRankset() {
        return restrictedToRankset;
    }

    public DatasetWeightType restrictedToRankset(Rankset rankset) {
        this.restrictedToRankset = rankset;
        return this;
    }

    public Set<RetailRevenueWeight> getRetailRevenueWeights() {
        return retailRevenueWeights;
    }

    public DatasetWeightType retailRevenueWeights(Set<RetailRevenueWeight> retailRevenueWeights) {
        this.retailRevenueWeights = retailRevenueWeights;
        return this;
    }

    public DatasetWeightType addRetailRevenueWeight(RetailRevenueWeight retailRevenueWeights) {
        this.retailRevenueWeights.add(retailRevenueWeights);
        retailRevenueWeights.setDatasetWeightType(this);
        return this;
    }

    public DatasetWeightType removeRetailRevenueWeight(RetailRevenueWeight retailRevenueWeights) {
        this.retailRevenueWeights.remove(retailRevenueWeights);
        retailRevenueWeights.setDatasetWeightType(null);
        return this;
    }

    public void setRetailRevenueWeights(Set<RetailRevenueWeight> retailRevenueWeights) {
        this.retailRevenueWeights = retailRevenueWeights;
    }

    public void setRestrictedToRankset(Rankset rankset) {
        this.restrictedToRankset = rankset;
    }

    public Timestamp getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(Timestamp updatedDate) {
        this.updatedDate = updatedDate;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        DatasetWeightType datasetWeightType = (DatasetWeightType) o;
        if (datasetWeightType.getId() == null || getId() == null) {
            return false;
        }
        return Objects.equals(getId(), datasetWeightType.getId());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getId());
    }

    @Override
    public String toString() {
        return "DatasetWeightType{" +
            "id=" + getId() +
            ", name='" + getName() + "'" +
            ", description='" + getDescription() + "'" +
            ", companyWeightType='" + getCompanyWeightType() + "'" +
            "}";
    }

    public Long getDatasetId() {
        return datasetId;
    }

    public void setDatasetId(Long datasetId) {
        this.datasetId = datasetId;
    }

    public DatasetWeightType datasetId(Long datasetId) {
        this.datasetId = datasetId;
        return this;
    }
    @PrePersist
    void onCreate() {
        this.setUpdatedDate(new Timestamp(System.currentTimeMillis()));
    }

    @PreUpdate
    void onUpdate() {
        this.setUpdatedDate(new Timestamp(System.currentTimeMillis()));
    }
}
