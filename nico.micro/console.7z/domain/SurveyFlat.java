package com.advantagegroup.blue.console.domain;

import java.io.Serializable;
import java.sql.Timestamp;
import java.time.ZonedDateTime;
import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.SecondaryTable;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.hibernate.annotations.TypeDef;
import org.hibernate.annotations.TypeDefs;

import com.advantagegroup.blue.console.domain.type.ApprovalStatus;
import com.advantagegroup.blue.console.domain.type.ApprovalStatusType;
import com.advantagegroup.blue.console.domain.type.JsonLocale;
import com.advantagegroup.blue.console.domain.type.StringJsonUserType;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * A Survey.
 */
@Entity
@Table(name = "survey", schema = "blue")
@SecondaryTable(name = "survey_response_statistics", schema = "blue_console", pkJoinColumns = @PrimaryKeyJoinColumn(name = "survey_id"))
@TypeDefs({ @TypeDef(name = "StringJson", typeClass = StringJsonUserType.class) })
public class SurveyFlat implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "survey_id")
    @GeneratedValue(generator = "survey_id_seq")
    @SequenceGenerator(name = "survey_id_seq", sequenceName = "survey_id_seq", schema = "blue", allocationSize = 1)
    private Long id;

    @NotNull
    @Column(name = "survey_code", nullable = false)
    private String code;

    @NotNull
    @Column(name = "survey_name", nullable = false)
    private String name;

    @Column(name = "survey_description")
    private String description;

    @Column(name = "field_start_datetime")
    private ZonedDateTime actualFieldStart;

    @Column(name = "expected_field_start_datetime")
    private ZonedDateTime expectedFieldStart;

    @Column(table = "survey_response_statistics", name = "field_start", updatable = false, insertable = false)
    private ZonedDateTime fieldStart;

    @Column(table = "survey_response_statistics", name = "field_start_status", updatable = false, insertable = false)
    private String fieldStartStatus;

    @Column(name = "field_close_datetime")
    private ZonedDateTime actualFieldClose;

    @Column(name = "expected_field_close_datetime")
    private ZonedDateTime expectedFieldClose;

    @Column(table = "survey_response_statistics", name = "field_close", updatable = false, insertable = false)
    private ZonedDateTime fieldClose;

    @Column(table = "survey_response_statistics", name = "field_close_status", updatable = false, insertable = false)
    private String fieldCloseStatus;

    @NotNull
    @Column(name = "approval_status", nullable = false)
    @Convert(converter = ApprovalStatusType.class)
    private ApprovalStatus approvalStatus;

    @Column(name = "survey_name_localization", nullable = false)
    private String nameLocalization;

    @Column(name = "locales", nullable = false)
    private String locales;

    @NotNull
    @OneToOne
    @JoinColumn(name = "program_id")
    private Program program;

    @Column(table = "survey_response_statistics", name = "number_of_responses", updatable = false, insertable = false)
    private Long numberOfResponses;

    @Column(name = "updated_timestamp")
    private Timestamp updatedDate;

    @ManyToOne
    @JoinColumn(name = "countryrollup_id", nullable = false)
    private CountryRollup countryRollup;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getCode() {
        return code;
    }

    public SurveyFlat code(String code) {
        this.code = code;
        return this;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public SurveyFlat name(String name) {
        this.name = name;
        return this;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public SurveyFlat description(String description) {
        this.description = description;
        return this;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public ZonedDateTime getFieldStart() {
        return fieldStart;
    }

    public SurveyFlat fieldStart(ZonedDateTime fieldStart) {
        this.fieldStart = fieldStart;
        return this;
    }

    public void setFieldStart(ZonedDateTime fieldStart) {
        this.fieldStart = fieldStart;
    }

    public ZonedDateTime getFieldClose() {
        return fieldClose;
    }

    public SurveyFlat fieldClose(ZonedDateTime fieldClose) {
        this.fieldClose = fieldClose;
        return this;
    }

    public void setFieldClose(ZonedDateTime fieldClose) {
        this.fieldClose = fieldClose;
    }

    public ZonedDateTime getExpectedFieldStart() {
        return expectedFieldStart;
    }

    public SurveyFlat expectedFieldStart(ZonedDateTime expectedFieldStart) {
        this.expectedFieldStart = expectedFieldStart;
        return this;
    }

    public void setExpectedFieldStart(ZonedDateTime expectedFieldStart) {
        this.expectedFieldStart = expectedFieldStart;
    }

    public ZonedDateTime getExpectedFieldClose() {
        return expectedFieldClose;
    }

    public SurveyFlat expectedFieldClose(ZonedDateTime expectedFieldClose) {
        this.expectedFieldClose = expectedFieldClose;
        return this;
    }

    public void setExpectedFieldClose(ZonedDateTime expectedFieldClose) {
        this.expectedFieldClose = expectedFieldClose;
    }

    public ZonedDateTime getActualFieldClose() {
        return actualFieldClose;
    }

    public SurveyFlat actualFieldClose(ZonedDateTime actualFieldClose) {
        this.actualFieldClose = actualFieldClose;
        return this;
    }

    public void setActualFieldClose(ZonedDateTime actualFieldClose) {
        this.actualFieldClose = actualFieldClose;
    }

    public String getFieldCloseStatus() {
        return fieldCloseStatus;
    }

    public void setFieldCloseStatus(String fieldCloseStatus) {
        this.fieldCloseStatus = fieldCloseStatus;
    }

    public String getFieldStartStatus() {
        return fieldStartStatus;
    }

    public void setFieldStartStatus(String fieldStartStatus) {
        this.fieldStartStatus = fieldStartStatus;
    }

    public ZonedDateTime getActualFieldStart() {
        return actualFieldStart;
    }

    public SurveyFlat actualFieldStart(ZonedDateTime actualFieldStart) {
        this.actualFieldStart = actualFieldStart;
        return this;
    }

    public void setActualFieldStart(ZonedDateTime actualFieldStart) {
        this.actualFieldStart = actualFieldStart;
    }

    public ApprovalStatus getApprovalStatus() {
        return approvalStatus;
    }

    public SurveyFlat approvalStatus(ApprovalStatus approvalStatus) {
        this.approvalStatus = approvalStatus;
        return this;
    }

    public void setApprovalStatus(ApprovalStatus approvalStatus) {
        this.approvalStatus = approvalStatus;
    }

    public Program getProgram() {
        return program;
    }

    public void setProgram(Program program) {
        this.program = program;
    }

    public Long getNumberOfResponses() {
        return numberOfResponses;
    }

    public void setNumberOfResponses(Long numberOfResponses) {
        this.numberOfResponses = numberOfResponses;
    }

    public String getNameLocalization() {
        return nameLocalization;
    }

    public void setNameLocalization(String nameLocalization) {
        this.nameLocalization = nameLocalization;
    }

    public String getLocales() {
        return locales;
    }

    public void setLocales(String locales) {
        this.locales = locales;
    }

    public Timestamp getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(Timestamp updatedDate) {
        this.updatedDate = updatedDate;
    }

    public CountryRollup getCountryRollup() {
        return countryRollup;
    }

    public void setCountryRollup(CountryRollup countryRollup) {
        this.countryRollup = countryRollup;
    }

    @PrePersist
    void onCreate() throws JsonProcessingException {
        defaults();
        calculations();
    }

    @PreUpdate
    void onUpdate() throws JsonProcessingException {
        calculations();
    }

    private void defaults() {
        this.locales = "[]";
    }

    private void calculations() throws JsonProcessingException {
        this.setUpdatedDate(new Timestamp(System.currentTimeMillis()));

        JsonLocale locale = new JsonLocale(name);
        ObjectMapper mapper = new ObjectMapper();
        String jsonInString = mapper.writeValueAsString(locale);

        this.nameLocalization = jsonInString;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        Survey survey = (Survey) o;
        if (survey.getId() == null || getId() == null) {
            return false;
        }
        return Objects.equals(getId(), survey.getId());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getId());
    }

    @Override
    public String toString() {
        return "SurveyFlat [id=" + id + ", code=" + code + ", name=" + name + ", description=" + description
                + ", actualFieldStart=" + actualFieldStart + ", expectedFieldStart=" + expectedFieldStart
                + ", fieldStart=" + fieldStart + ", fieldStartStatus=" + fieldStartStatus + ", actualFieldClose="
                + actualFieldClose + ", expectedFieldClose=" + expectedFieldClose + ", fieldClose=" + fieldClose
                + ", fieldCloseStatus=" + fieldCloseStatus + ", approvalStatus=" + approvalStatus
                + ", nameLocalization=" + nameLocalization + ", locales=" + locales + ", program=" + program
                + ", numberOfResponses=" + numberOfResponses + ", updatedDate=" + updatedDate + ", countryRollup="
                + countryRollup + "]";
    }
}
