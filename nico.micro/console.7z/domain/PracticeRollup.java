package com.advantagegroup.blue.console.domain;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;


import javax.persistence.*;
import javax.validation.constraints.*;
import java.io.Serializable;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.util.Objects;

/**
 * A PracticeRollup.
 */
@Entity
@Table(name = "practicerollup", schema = "blue")
@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
@SecondaryTable(name = "practicerollup_view",
    schema = "blue_console",
    pkJoinColumns = @PrimaryKeyJoinColumn(name = "practicerollup_id"))
public class PracticeRollup implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "practicerollup_id")
    @GeneratedValue(generator = "practicerollup_id_seq")
    @SequenceGenerator(name = "practicerollup_id_seq", sequenceName = "practicerollup_id_seq", schema = "blue", allocationSize = 1)
    private Long id;

    @NotNull
    @Column(name = "practice_name", nullable = false)
    private String name;

    @NotNull
    @Column(name = "practice_name_localization", nullable = false)
    private String nameLocalization;

    @NotNull
    @Column(name = "practice_text", nullable = false)
    private String text;

    @NotNull
    @Column(name = "practice_text_localization", nullable = false)
    private String textLocalization;

    @Column(name = "practice_subtext")
    private String subText;

    @Column(name = "practice_subtext_localization")
    private String subTextLocalization;

    @Column(name = "practice_description")
    private String description;

    @NotNull
    @Column(name = "effective_date", nullable = false)
    private LocalDate effectiveDate;

    @Column(name = "expiry_date")
    private LocalDate expiryDate;

    @NotNull
    @Column(name = "list_order", nullable = false)
    private Integer listOrder;

    @NotNull
    @Column(name = "locked", nullable = false)
    private Boolean locked;

    @ManyToOne(optional = false)
    @NotNull
    @JoinColumn(name = "practicecode_id")
    private PracticeCode practiceCode;

    @Column( table = "practicerollup_view", name = "code_path", insertable = false, updatable = false )
    private String codePath;

    @Column(table = "practicerollup_view", name = "name_path", insertable = false, updatable = false)
    private String namePath;

    @Column(name = "updated_timestamp")
    private Timestamp updatedDate;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public PracticeRollup name(String name) {
        this.name = name;
        return this;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getNameLocalization() {
        return nameLocalization;
    }

    public PracticeRollup nameLocalization(String nameLocalization) {
        this.nameLocalization = nameLocalization;
        return this;
    }

    public void setNameLocalization(String nameLocalization) {
        this.nameLocalization = nameLocalization;
    }

    public String getText() {
        return text;
    }

    public PracticeRollup text(String text) {
        this.text = text;
        return this;
    }

    public void setText(String text) {
        this.text = text;
    }

    public String getTextLocalization() {
        return textLocalization;
    }

    public PracticeRollup textLocalization(String textLocalization) {
        this.textLocalization = textLocalization;
        return this;
    }

    public void setTextLocalization(String textLocalization) {
        this.textLocalization = textLocalization;
    }

    public String getSubText() {
        return subText;
    }

    public PracticeRollup subText(String subText) {
        this.subText = subText;
        return this;
    }

    public void setSubText(String subText) {
        this.subText = subText;
    }

    public String getSubTextLocalization() {
        return subTextLocalization;
    }

    public PracticeRollup subTextLocalization(String subTextLocalization) {
        this.subTextLocalization = subTextLocalization;
        return this;
    }

    public void setSubTextLocalization(String subTextLocalization) {
        this.subTextLocalization = subTextLocalization;
    }

    public String getDescription() {
        return description;
    }

    public PracticeRollup description(String description) {
        this.description = description;
        return this;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public LocalDate getEffectiveDate() {
        return effectiveDate;
    }

    public PracticeRollup effectiveDate(LocalDate effectiveDate) {
        this.effectiveDate = effectiveDate;
        return this;
    }

    public void setEffectiveDate(LocalDate effectiveDate) {
        this.effectiveDate = effectiveDate;
    }

    public LocalDate getExpiryDate() {
        return expiryDate;
    }

    public PracticeRollup expiryDate(LocalDate expiryDate) {
        this.expiryDate = expiryDate;
        return this;
    }

    public void setExpiryDate(LocalDate expiryDate) {
        this.expiryDate = expiryDate;
    }

    public Integer getListOrder() {
        return listOrder;
    }

    public PracticeRollup listOrder(Integer listOrder) {
        this.listOrder = listOrder;
        return this;
    }

    public void setListOrder(Integer listOrder) {
        this.listOrder = listOrder;
    }

    public Boolean isLocked() {
        return locked;
    }

    public PracticeRollup locked(Boolean locked) {
        this.locked = locked;
        return this;
    }

    public void setLocked(Boolean locked) {
        this.locked = locked;
    }

    public PracticeCode getPracticeCode() { return practiceCode; }

    public PracticeRollup manufacturerCode(PracticeRollup practiceRollup) {
        this.practiceCode = practiceCode;
        return this;
    }

    public void setPracticeCode(PracticeCode practiceCode) { this.practiceCode = practiceCode; }

    public String getNamePath() { return namePath; }

    public PracticeRollup namePath(String namePath) {
        this.namePath = namePath;
        return this;
    }

    public void setNamePath(String namePath) { this.namePath = namePath; }

    public String getCodePath() { return codePath; }

    public PracticeRollup codePath(String codePath) {
        this.codePath = codePath;
        return this;
    }

    public void setCodePath(String codePath) { this.codePath = codePath; }

    public Timestamp getUpdatedDate() {
        return updatedDate;
    }

//    public PracticeRollup updatedDate(Timestamp updatedDate) {
//        this.updatedDate = updatedDate;
//        return this;
//    }

    public void setUpdatedDate(Timestamp updatedDate) {
        this.updatedDate = updatedDate;
    }

    @PrePersist
    void onCreate() {
        defaults();
        calculated();
    }

    @PreUpdate
    void onUpdate() {
        calculated();
    }

    private void defaults() {
        // nothing to do
    }

    private void calculated() {
        this.setUpdatedDate(new Timestamp(System.currentTimeMillis()));
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        PracticeRollup practiceRollup = (PracticeRollup) o;
        if (practiceRollup.getId() == null || getId() == null) {
            return false;
        }
        return Objects.equals(getId(), practiceRollup.getId());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getId());
    }

    @Override
    public String toString() {
        return "PracticeRollup{" +
            "id=" + getId() +
            ", name='" + getName() + "'" +
            ", nameLocalization='" + getNameLocalization() + "'" +
            ", text='" + getText() + "'" +
            ", textLocalization='" + getTextLocalization() + "'" +
            ", subText='" + getSubText() + "'" +
            ", subTextLocalization='" + getSubTextLocalization() + "'" +
            ", description='" + getDescription() + "'" +
            ", effectiveDate='" + getEffectiveDate() + "'" +
            ", expiryDate='" + getExpiryDate() + "'" +
            ", listOrder='" + getListOrder() + "'" +
            ", locked='" + isLocked() + "'" +
            ", namePath='" + getNamePath() + "'" +
            ", namePath='" + getCodePath() + "'" +
            "}";
    }
}
