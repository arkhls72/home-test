package com.advantagegroup.blue.console.domain;



import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

/**
 * A RetailRevenueWeight.
 */
@Entity
@Table(name = "retailrevenueweight", schema = "blue")
public class RetailRevenueWeight implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "retailrevenueweight_id")
    @GeneratedValue(generator = "retailrevenueweight_id_seq")
    @SequenceGenerator(name = "retailrevenueweight_id_seq", sequenceName = "retailrevenueweight_id_seq", schema = "blue", allocationSize = 1)
    private Long id;

    @NotNull
    @Column(name = "retailunit_id", nullable = false)
    private Long retailUnitId;

    @NotNull
    @Column(name = "is_custom_weight", nullable = false)
    private Boolean customWeight;

    @Column(name = "weight_value", precision=15, scale=2)
    private double weight;

    @Column(name = "updated_timestamp")
    private Timestamp updatedDate;

    @ManyToOne(optional = false)
    @NotNull
    @JoinColumn(name="datasetweighttype_id", referencedColumnName="datasetweighttype_id", updatable=false)
    private DatasetWeightType datasetWeightType;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getRetailUnitId() {
        return retailUnitId;
    }

    public RetailRevenueWeight retailUnitId(Long retailUnitId) {
        this.retailUnitId = retailUnitId;
        return this;
    }

    public void setRetailUnitId(Long retailUnitId) {
        this.retailUnitId = retailUnitId;
    }

    public Boolean isCustomWeight() {
        return customWeight;
    }

    public RetailRevenueWeight customWeight(Boolean customWeight) {
        this.customWeight = customWeight;
        return this;
    }

    public void setCustomWeight(Boolean customWeight) {
        this.customWeight = customWeight;
    }

    public double getWeight() {
        return weight;
    }

    public RetailRevenueWeight value(double value) {
        this.weight = value;
        return this;
    }

    public void setWeight(double weight) {
        this.weight = weight;
    }

    public DatasetWeightType getDatasetWeightType() {
        return datasetWeightType;
    }

    public RetailRevenueWeight datasetWeightType(DatasetWeightType datasetWeightType) {
        this.datasetWeightType = datasetWeightType;
        return this;
    }

    public void setDatasetWeightType(DatasetWeightType datasetWeightType) {
        this.datasetWeightType = datasetWeightType;
    }

    public Timestamp getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(Timestamp updatedDate) {
        this.updatedDate = updatedDate;
    }

    @PrePersist
    void onCreate() {
        defaults();
        calculated();
    }

    @PreUpdate
    void onUpdate() {
        calculated();
    }

    private void defaults() {
        // nothing to do
    }

    private void calculated() {
        this.setUpdatedDate(new Timestamp(System.currentTimeMillis()));
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        RetailRevenueWeight retailRevenueWeight = (RetailRevenueWeight) o;
        if (retailRevenueWeight.getId() == null || getId() == null) {
            return false;
        }
        return Objects.equals(getId(), retailRevenueWeight.getId());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getId());
    }

    @Override
    public String toString() {
        return "RetailRevenueWeight{" +
            "id=" + getId() +
            ", retailUnitId='" + getRetailUnitId() + "'" +
            ", customWeight='" + isCustomWeight() + "'" +
            ", weight='" + getWeight() + "'" +
            "}";
    }
}
