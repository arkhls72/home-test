package com.advantagegroup.blue.console.domain;



import javax.persistence.*;
import javax.validation.constraints.*;
import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Objects;

/**
 * A PracticeCode.
 */
@Entity
@Table(name = "practicecode", schema = "blue")
public class PracticeCode implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "practicecode_id")
    @GeneratedValue(generator = "practicecode_id_seq")
    @SequenceGenerator(name = "practicecode_id_seq", sequenceName = "practicecode_id_seq", schema = "blue", allocationSize = 1)
    private Long id;

    @NotNull
    @Column(name = "practice_code", nullable = false)
    private String code;

    @NotNull
    @Column(name = "practice_name", nullable = false)
    private String name;

    @NotNull
    @Column(name = "practice_name_localization", nullable = false)
    private String nameLocalization;

    @NotNull
    @Column(name = "practice_text", nullable = false)
    private String text;

    @NotNull
    @Column(name = "practice_text_localization", nullable = false)
    private String textLocalization;

    @Column(name = "practice_subtext")
    private String subText;

    @Column(name = "practice_subtext_localization")
    private String subTextLocalization;

    @Column(name = "practice_description")
    private String description;

    @NotNull
    @Column(name = "practiceidentifier", nullable = false)
    private Boolean practiceIdentifier;

    @NotNull
    @Column(name = "is_retired", nullable = false)
    private Boolean retired;

    @Column(name = "updated_timestamp")
    private Timestamp updatedDate;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getCode() {
        return code;
    }

    public PracticeCode code(String code) {
        this.code = code;
        return this;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public PracticeCode name(String name) {
        this.name = name;
        return this;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getNameLocalization() {
        return nameLocalization;
    }

    public PracticeCode nameLocalization(String nameLocalization) {
        this.nameLocalization = nameLocalization;
        return this;
    }

    public void setNameLocalization(String nameLocalization) {
        this.nameLocalization = nameLocalization;
    }

    public String getText() {
        return text;
    }

    public PracticeCode text(String text) {
        this.text = text;
        return this;
    }

    public void setText(String text) {
        this.text = text;
    }

    public String getTextLocalization() {
        return textLocalization;
    }

    public PracticeCode textLocalization(String textLocalization) {
        this.textLocalization = textLocalization;
        return this;
    }

    public void setTextLocalization(String textLocalization) {
        this.textLocalization = textLocalization;
    }

    public PracticeCode subText(String subText) {
        this.subText = subText;
        return this;
    }

    public String getSubText() {
        return subText;
    }

    public void setSubText(String subText) {
        this.subText = subText;
    }

    public String getSubTextLocalization() {
        return subTextLocalization;
    }

    public PracticeCode subTextLocalization(String subTextLocalization) {
        this.subTextLocalization = subTextLocalization;
        return this;
    }

    public void setSubTextLocalization(String subTextLocalization) {
        this.subTextLocalization = subTextLocalization;
    }

    public String getDescription() {
        return description;
    }

    public PracticeCode description(String description) {
        this.description = description;
        return this;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Boolean isPracticeIdentifier() {
        return practiceIdentifier;
    }

    public PracticeCode practiceIdentifier(Boolean practiceIdentifier) {
        this.practiceIdentifier = practiceIdentifier;
        return this;
    }

    public void setPracticeIdentifier(Boolean practiceIdentifier) {
        this.practiceIdentifier = practiceIdentifier;
    }

    public Boolean isRetired() {
        return retired;
    }

    public PracticeCode retired(Boolean retired) {
        this.retired = retired;
        return this;
    }

    public void setRetired(Boolean retired) {
        this.retired = retired;
    }

    public Timestamp getUpdatedDate() {
        return updatedDate;
    }

//    public PracticeCode updatedDate(Timestamp updatedDate) {
//        this.updatedDate = updatedDate;
//        return this;
//    }

    public void setUpdatedDate(Timestamp updatedDate) {
        this.updatedDate = updatedDate;
    }

    @PrePersist
    void onCreate() {
        defaults();
        calculated();
    }

    @PreUpdate
    void onUpdate() {
        calculated();
    }

    private void defaults() {
        // nothing to do
    }

    private void calculated() {
        this.setUpdatedDate(new Timestamp(System.currentTimeMillis()));
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        PracticeCode practiceCode = (PracticeCode) o;
        if (practiceCode.getId() == null || getId() == null) {
            return false;
        }
        return Objects.equals(getId(), practiceCode.getId());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getId());
    }

    @Override
    public String toString() {
        return "PracticeCode{" +
            "id=" + getId() +
            ", code='" + getCode() + "'" +
            ", name='" + getName() + "'" +
            ", nameLocalization='" + getNameLocalization() + "'" +
            ", text='" + getText() + "'" +
            ", textLocalization='" + getTextLocalization() + "'" +
            ", subText='" + getSubText() + "'" +
            ", subTextLocalization='" + getSubTextLocalization() + "'" +
            ", description='" + getDescription() + "'" +
            ", practiceIdentifier='" + isPracticeIdentifier() + "'" +
            ", retired='" + isRetired() + "'" +
            "}";
    }
}
