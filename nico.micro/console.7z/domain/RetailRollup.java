package com.advantagegroup.blue.console.domain;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;
import org.hibernate.annotations.TypeDef;
import org.hibernate.annotations.TypeDefs;


import com.advantagegroup.blue.console.domain.type.StringJsonUserType;

import javax.persistence.*;
import javax.validation.constraints.NotNull;

import java.io.Serializable;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.util.Objects;

/**
 * A RetailRollup.
 */
@Entity
@Table(name = "retailrollup",schema="blue")
@SecondaryTable(name = "retailrollup_view",
schema = "blue_console",
pkJoinColumns = @PrimaryKeyJoinColumn(name = "retailrollup_id"))
@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
@TypeDefs({ @TypeDef(name = "StringJson", typeClass = StringJsonUserType.class) })
public class RetailRollup implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @Column(name="retailrollup_id")
    @GeneratedValue(generator = "companyrollup_id_seq")
    @SequenceGenerator(name = "companyrollup_id_seq", sequenceName = "companyrollup_id_seq", schema = "blue", allocationSize = 1)
    private Long id;

    @Column(name = "retail_name")
    private String name;

    @Column(name = "retail_description")
    private String description;

    @OneToOne(optional = true)
    @JoinColumn( name="retailunit_id")
    private RetailUnit retailUnit;

    @Column(name = "retail_logo")
    private String logo;

    @NotNull
    @Column(name = "list_order", nullable = false)
    private Integer listOrder;

    @NotNull
    @Column(name = "locked", nullable = false)
    private Boolean  locked;

    @ManyToOne(optional = false)
    @NotNull
    @JoinColumn(name = "retailcode_id")
    private RetailCode retailCode;

    @Column( table = "retailrollup_view", name = "code_path", insertable = false, updatable = false )
    private String codePath;

    @Column( table = "retailrollup_view", name = "name_path", insertable = false, updatable = false )
    private String namePath;

    @NotNull
    @Column(name = "effective_date", nullable = false)
    private LocalDate effectiveDate;

    @Column(name = "expiry_date")
    private LocalDate expiryDate;

    @Column(name = "updated_timestamp")
    private Timestamp updatedDate;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public RetailRollup name(String name) {
        this.name = name;
        return this;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public RetailRollup description(String description) {
        this.description = description;
        return this;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public RetailUnit getRetailUnit() {
        return retailUnit;
    }

    public RetailRollup retailUnit(RetailUnit retailUnit) {
        this.retailUnit = retailUnit;
        return this;
    }

    public void setRetailUnit(RetailUnit retailUnit) {
        this.retailUnit = retailUnit;
    }

    public RetailCode getRetailCode() {
        return retailCode;
    }

    public void setRetailCode(RetailCode retailCode) {
        this.retailCode = retailCode;
    }

    public String getCodePath() {
        return codePath;
    }

    public void setCodePath(String codePath) {
        this.codePath = codePath;
    }

    public String getNamePath() {
        return namePath;
    }

    public void setNamePath(String namePath) {
        this.namePath = namePath;
    }

    public String getLogo() {
        return logo;
    }

    public void setLogo(String logo) {
        this.logo = logo;
    }

    public Boolean getLocked() {
        return locked;
    }

    public void setLocked(Boolean locked) {
        this.locked = locked;
    }

    public LocalDate getEffectiveDate() {
        return effectiveDate;
    }

    public void setEffectiveDate(LocalDate effectiveDate) {
        this.effectiveDate = effectiveDate;
    }

    public LocalDate getExpiryDate() {
        return expiryDate;
    }

    public void setExpiryDate(LocalDate expiryDate) {
        this.expiryDate = expiryDate;
    }

    public Timestamp getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(Timestamp updatedDate) {
        this.updatedDate = updatedDate;
    }

    @PrePersist
    void onCreate() {
        this.setUpdatedDate(new Timestamp(System.currentTimeMillis()));
    }

    @PreUpdate
    void onUpdate() {
        this.setUpdatedDate(new Timestamp(System.currentTimeMillis()));
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        RetailRollup retailRollup = (RetailRollup) o;
        if (retailRollup.getId() == null || getId() == null) {
            return false;
        }
        return Objects.equals(getId(), retailRollup.getId());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getId());
    }

    @Override
    public String toString() {
        return "RetailRollup{" +
            "id=" + getId() +
            ", name='" + getName() + "'" +
            ", description='" + getDescription() + "'" +
            ", retailUnit='" + getRetailUnit() + "'" +
            "}";
    }
}
