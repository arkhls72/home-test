package com.advantagegroup.blue.console.repository;

import com.advantagegroup.blue.console.domain.SurveySubject;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface SurveySubjectRepository extends JpaRepository<SurveySubject,Long> {
}
