package com.advantagegroup.blue.console.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.advantagegroup.blue.console.domain.Dataset;
import com.advantagegroup.blue.console.domain.DatasetSummary;


/**
 * Spring Data JPA repository for the Dataset entity.
 */
@Repository
public interface DatasetRepository extends JpaRepository<Dataset,Long> {
    
	/**
	 * This query returns a page of shallow Dataset summaries (no associations).
	 * It runs much faster and should preferred over the default findAll() method.
	 * @param pageable
	 * @return A set of {@link DatasetSummary} entities.
	 */
	Page<DatasetSummary> findAllProjectedBy(Pageable pageable);

	@Query("SELECT ds FROM Dataset ds WHERE "
			+ "lower(ds.code) LIKE :query OR "
			+ "lower(ds.name) LIKE :query OR "
			+ "lower(ds.description) LIKE :query OR "
			+ "lower(ds.program.code) LIKE :query OR "
			+ "lower(ds.program.name) LIKE :query OR "
			+ "lower(ds.program.description) LIKE :query OR "
			+ "lower(ds.countryRollup.name) LIKE :query OR "
			+ "lower(ds.countryRollup.description) LIKE :query"
	)
	Page<Dataset> search(@Param("query") String query, Pageable pageable);
	
}
