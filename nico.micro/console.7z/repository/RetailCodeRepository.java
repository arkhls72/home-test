package com.advantagegroup.blue.console.repository;

import com.advantagegroup.blue.console.domain.RetailCode;
import org.springframework.stereotype.Repository;

import org.springframework.data.jpa.repository.*;


/**
 * Spring Data JPA repository for the RetailCode entity.
 */
@SuppressWarnings("unused")
@Repository
public interface RetailCodeRepository extends JpaRepository<RetailCode,Long> {
    
}
