package com.advantagegroup.blue.console.repository;

import com.advantagegroup.blue.console.domain.ManufacturerRollup;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import org.springframework.data.jpa.repository.*;

import java.util.List;


/**
 * Spring Data JPA repository for the ManufacturerRollup entity.
 */
@SuppressWarnings("unused")
@Repository
public interface ManufacturerRollupRepository extends JpaRepository<ManufacturerRollup,Long> {
    @Query(value = "SELECT mr.*, mv.*  " +
        "FROM blue.manufacturerrollup AS mr " +
        "JOIN blue.dataset_manufacturerrollup AS dmr ON mr.manufacturerrollup_id = dmr.manufacturerrollup_id " +
        "join blue_console.manufacturerrollup_view mv on mv.manufacturerrollup_id = mr.manufacturerrollup_id \n" +
        "WHERE dmr.dataset_id = :datasetId",
        nativeQuery = true)
    List<ManufacturerRollup> findByDatasetId(@Param("datasetId") Long datasetId);

    @Query(value = "SELECT mr.*, mv.*  " +
        "FROM blue.manufacturerrollup AS mr " +
        "JOIN blue.rankset_manufacturerrollup AS rmr ON mr.manufacturerrollup_id = rmr.manufacturerrollup_id " +
        "join blue_console.manufacturerrollup_view mv on mv.manufacturerrollup_id = mr.manufacturerrollup_id \n" +
        "WHERE rmr.rankset_id = :ranksetId",
        nativeQuery = true)
    List<ManufacturerRollup> findByRanksetId(@Param("ranksetId") Long ranksetId);

    // NOTE: native query cannot be Pageable
    @Query(value =
        "select distinct on (mr.manufacturerrollup_id) mr.*, mv.* \n" +
        "from blue.dataset_survey dss \n" +
        "join blue.surveysubject ss on ss.survey_id = dss.survey_id \n" +
        "join blue.dataset ds on ds.dataset_id = dss.dataset_id \n" +
        "join blue.cache_manufacturerrollupjoin cmrj on cmrj.head_manufacturerrollup_id = ss.manufacturerrollup_id \n" +
        "join blue.cache_manufacturercountryoverlap cmco on cmco.countryrollup_id = ds.countryrollup_id \n" +
        "                                                and cmco.manufacturerrollup_id = cmrj.tail_manufacturerrollup_id \n" +
        "join blue.manufacturerrollup mr on mr.manufacturerrollup_id = cmco.manufacturerrollup_id \n" +
        "join blue.manufacturercode mc on mc.manufacturercode_id = mr.manufacturercode_id \n" +
        "join blue_console.manufacturerrollup_view mv on mv.manufacturerrollup_id = mr.manufacturerrollup_id \n" +
        "where dss.dataset_id = :datasetId",
        nativeQuery = true)
    List<ManufacturerRollup> findEligible(@Param("datasetId") Long datasetId);

    @Query(value =
        "select mr.*, mv.*, cc.country_code \n" +
            "from blue.manufacturerrollup mr \n" +
            "join blue.cache_manufacturercountryoverlap c_mco on c_mco.manufacturerrollup_id = mr.manufacturerrollup_id \n" +
            "join blue_console.manufacturerrollup_view mv on mv.manufacturerrollup_id = mr.manufacturerrollup_id \n" +
            "join blue.countryrollup cr on cr.countryrollup_id = c_mco.countryrollup_id \n" +
            "join blue.survey s on s.countryrollup_id = cr.countryrollup_id \n" +
            "join blue.countrycode cc on cr.countrycode_id = cc.countrycode_id \n" +
            "where mr.rollup_parent_id is null \n" +
            "and mr.leaf_rollup_node = true \n" +
            "and s.survey_id = :surveyId\n" +
            "and (lower(mv.name_path) like :searchString or lower(mv.code_path) like :searchString)\n" +
            "-- #pageable\n",
        countQuery =
            "select count(mr.manufacturerrollup_id) \n" +
                "from blue.manufacturerrollup mr \n" +
                "join blue.cache_manufacturercountryoverlap c_mco on c_mco.manufacturerrollup_id = mr.manufacturerrollup_id \n" +
                "join blue_console.manufacturerrollup_view mv on mv.manufacturerrollup_id = mr.manufacturerrollup_id \n" +
                "join blue.countryrollup cr on cr.countryrollup_id = c_mco.countryrollup_id \n" +
                "join blue.survey s on s.countryrollup_id = cr.countryrollup_id \n" +
                "join blue.countrycode cc on cr.countrycode_id = cc.countrycode_id \n" +
                "where mr.rollup_parent_id is null \n" +
                "and mr.leaf_rollup_node = true \n" +
                "and (lower(mv.name_path) like :searchString or lower(mv.code_path) like :searchString)\n" +
                "and s.survey_id = :surveyId",
        nativeQuery = true)
    Page<ManufacturerRollup> findEligibleForSurvey(@Param("surveyId") Long surveyId, @Param("searchString") String searchString, Pageable pageable);

    @Query(value =
        "select mr.*, mv.*, cc.country_code \n" +
            "from blue.manufacturerrollup mr \n" +
            "join blue.cache_manufacturercountryoverlap c_mco on c_mco.manufacturerrollup_id = mr.manufacturerrollup_id \n" +
            "join blue_console.manufacturerrollup_view mv on mv.manufacturerrollup_id = mr.manufacturerrollup_id \n" +
            "join blue.countryrollup cr on cr.countryrollup_id = c_mco.countryrollup_id \n" +
            "join blue.survey s on s.countryrollup_id = cr.countryrollup_id \n" +
            "join blue.countrycode cc on cr.countrycode_id = cc.countrycode_id \n" +
            "where mr.rollup_parent_id is null \n" +
            "and mr.leaf_rollup_node = true \n" +
            "and s.survey_id = :surveyId\n",
        nativeQuery = true)
    List<ManufacturerRollup> findAllEligibleForSurvey(@Param("surveyId") Long surveyId);

    static final String nativeQueryDatasetSurveysManufacturerRollups = "select sv.survey_id,string_agg(DISTINCT cast(mr.manufacturerrollup_id AS VARCHAR), ',')\n" +
        "from blue.dataset ds\n" +
        "  -- eligibile surveys\n" +
        "  join blue.cache_countryrollupjoin ccrj on ds.countryrollup_id = ccrj.tail_countryrollup_id\n" +
        "  join blue.survey sv on ccrj.head_countryrollup_id = sv.countryrollup_id\n" +
        "                         -- Add this back in when approval status is working.\n" +
        "                         -- and sv.approval_status = 'Approved'\n" +
        "                         -- survey starts before dataset expires\n" +
        "                         and COALESCE( sv.field_start_datetime, sv.expected_field_start_datetime, to_date( '1900-01-01', 'YYYY-MM-DD' ) ) <= COALESCE( ds.expiry_date, to_date( '2200-12-31', 'YYYY-MM-DD' ) )\n" +
        "                         -- survey closes after dataset starts\n" +
        "                         and COALESCE( sv.field_close_datetime, sv.expected_field_close_datetime, to_date( '2200-12-31', 'YYYY-MM-DD' ) ) >= COALESCE( ds.effective_date, to_date( '1900-01-01', 'YYYY-MM-DD' ) )\n" +
        "  -- manufacturers made eligible by the survey\n" +
        "  join blue.surveysubject ss on ss.survey_id = sv.survey_id\n" +
        "  join blue.cache_manufacturerrollupjoin cmrj on cmrj.head_manufacturerrollup_id = ss.manufacturerrollup_id\n" +
        "  join blue.cache_manufacturercountryoverlap cmco on cmco.countryrollup_id = ds.countryrollup_id\n" +
        "                                                     and cmco.manufacturerrollup_id = cmrj.tail_manufacturerrollup_id\n" +
        "  join blue.manufacturerrollup mr on mr.manufacturerrollup_id = cmco.manufacturerrollup_id\n" +
        "where ds.dataset_id = :datasetId\n" +
        "group by sv.survey_id";

    @Query(value = nativeQueryDatasetSurveysManufacturerRollups, nativeQuery = true)
    List<Object[]> findSurveyManufacturerRollup(@Param("datasetId") Long datasetId);
}
