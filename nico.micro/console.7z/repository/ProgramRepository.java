package com.advantagegroup.blue.console.repository;

import com.advantagegroup.blue.console.domain.Program;
import org.springframework.stereotype.Repository;

import org.springframework.data.jpa.repository.*;


/**
 * Spring Data JPA repository for the Program entity.
 */
@SuppressWarnings("unused")
@Repository
public interface ProgramRepository extends JpaRepository<Program,Long> {
    
}
