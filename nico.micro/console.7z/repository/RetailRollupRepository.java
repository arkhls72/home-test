package com.advantagegroup.blue.console.repository;

import com.advantagegroup.blue.console.domain.RetailRollup;

import org.springframework.stereotype.Repository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.*;
import org.springframework.data.repository.query.Param;

import java.util.Collection;
import java.util.List;

/**
 * Spring Data JPA repository for the RetailRollup entity.
 */
@SuppressWarnings("unused")
@Repository
public interface RetailRollupRepository extends JpaRepository<RetailRollup,Long> {

    // note:  returned columns must match attributes in RetailRollup
    static final String nativeQueryEligibleForDataset = "select distinct rtr.retailrollup_id,\n"
        + "    rtr.retail_name, rtr.retail_description, rtr.effective_date, rtr.expiry_date, rtr.locked, rtr.list_order, CAST( rtr.retail_logo AS text ) as retail_logo, rtr.retailcode_id, rtr.retailunit_id, rtr.updated_timestamp,\n"
        + "    rrv.code_path, rrv.name_path\n"
        + "from blue.dataset ds\n"
        + "join blue.dataset_survey dss on ds.dataset_id = dss.dataset_id\n"
        + "join blue.cache_surveyretailrollup csrr on csrr.survey_id = dss.survey_id\n"
        + "join blue.cache_retailrollupjoin crrj on crrj.head_retailrollup_id = csrr.retailrollup_id\n"
        + "join blue.cache_retailcountryoverlap crco on crco.countryrollup_id = ds.countryrollup_id and crco.retailrollup_id = crrj.tail_retailrollup_id\n"
        + "join blue.retailrollup rtr on rtr.retailrollup_id = crco.retailrollup_id\n"
        + "join blue_console.retailrollup_view rrv ON rrv.retailrollup_id = rtr.retailrollup_id\n"
        + "where ds.dataset_id = :datasetId\n"
        + "and ( lower( rrv.code_path ) like :searchString or lower( rrv.name_path ) like :searchString )\n"
        // NOTE:  this line below is intentional.  It looks commented out, but it is not.
        // There is something strange in SpringData that does not handle #pageable properly in native queries
        // and the text '\n-- #pageable\n' is the only way to make it work.
        + "-- #pageable\n"
        ;
    static final String nativeQueryEligibleForDatasetCount = "select count( distinct rtr.retailrollup_id )\n"
        + "from blue.dataset ds\n"
        + "join blue.dataset_survey dss on ds.dataset_id = dss.dataset_id\n"
        + "join blue.cache_surveyretailrollup csrr on csrr.survey_id = dss.survey_id\n"
        + "join blue.cache_retailrollupjoin crrj on crrj.head_retailrollup_id = csrr.retailrollup_id\n"
        + "join blue.cache_retailcountryoverlap crco on crco.countryrollup_id = ds.countryrollup_id and crco.retailrollup_id = crrj.tail_retailrollup_id\n"
        + "join blue.retailrollup rtr on rtr.retailrollup_id = crco.retailrollup_id\n"
        + "join blue_console.retailrollup_view rrv ON rrv.retailrollup_id = rtr.retailrollup_id\n"
        + "where ds.dataset_id = :datasetId\n"
        + "and ( lower( rrv.code_path ) like :searchString or lower( rrv.name_path ) like :searchString )"
        ;
    @Query( value = nativeQueryEligibleForDataset, countQuery = nativeQueryEligibleForDatasetCount, nativeQuery = true)
    Page<RetailRollup> findEligibleForDataset(@Param("datasetId") Long datasetId,
                                              @Param("searchString") String searchString,
                                              Pageable pageable );

    static final String queryEligibleForRankset = "select rr " +
        "from Rankset r join r.dataset d join d.retailRollups rr " +
        "where r.id = :ranksetId " +
        "and ( lower ( rr.codePath ) like :searchString or lower ( rr.namePath ) like :searchString )";
    @Query( value = queryEligibleForRankset )
    Page<RetailRollup> findEligibleForRankset(@Param("ranksetId") Long ranksetId,
                                              @Param("searchString") String searchString, Pageable pageable );

    static final String queryAllEligibleForRankset = "select rr " +
        "from Rankset r join r.dataset d join d.retailRollups rr " +
        "where r.id = :ranksetId";
    @Query( value = queryAllEligibleForRankset )
    Collection<RetailRollup> findEligibleForRankset(@Param("ranksetId") Long ranksetId  );

    static final String nativeQueryDatasetWeightType = "select parent_rr.retailrollup_id, sum( coalesce( rrw.weight_value, 0 ) ) as weight\n" +
        "from blue.datasetweighttype dwt\n" +
        "join blue.dataset_retailrollup drr on drr.dataset_id = dwt.dataset_id \n" +
        "join blue.retailrollup parent_rr on parent_rr.retailrollup_id = drr.retailrollup_id\n" +
        "join blue.retailrollup rr on rr.rollup_root_id = parent_rr.rollup_root_id\n" +
        "                           and rr.rollup_left between parent_rr.rollup_left and parent_rr.rollup_right\n" +
        "join blue.retailrevenueweight rrw on rrw.retailunit_id = rr.retailunit_id\n" +
        "                                  and rrw.datasetweighttype_id = dwt.datasetweighttype_id\n" +
        "where dwt.datasetweighttype_id = :datasetWeightTypeId\n" +
        "group by parent_rr.retailrollup_id";
    @Query(value = nativeQueryDatasetWeightType, nativeQuery = true)
    List<Object[]> findDataRetailRollups(@Param("datasetWeightTypeId") Long datasetWeightTypeId);
}
