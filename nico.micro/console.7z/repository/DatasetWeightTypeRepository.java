package com.advantagegroup.blue.console.repository;

import com.advantagegroup.blue.console.domain.Dataset;
import com.advantagegroup.blue.console.domain.DatasetWeightType;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Repository;

import org.springframework.data.jpa.repository.*;

import java.util.List;
import java.util.Set;


/**
 * Spring Data JPA repository for the DatasetWeightType entity.
 */
@SuppressWarnings("unused")
@Repository
public interface DatasetWeightTypeRepository extends JpaRepository<DatasetWeightType,Long> {
    Page<DatasetWeightType> findByDatasetId(Long datasetid, Pageable pageable);
    List<DatasetWeightType> findByDatasetId(Long datasetid, Sort sort);
    List<DatasetWeightType> findByDatasetId(Long datasetid);
}
