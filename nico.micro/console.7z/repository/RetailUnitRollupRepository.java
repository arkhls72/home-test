package com.advantagegroup.blue.console.repository;

import com.advantagegroup.blue.console.domain.RetailUnitRollup;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface RetailUnitRollupRepository extends JpaRepository<RetailUnitRollup, String> {

    static final String queryByDatasetWeightType =
        "select"
        + " cast(parent_rr.retailrollup_id as text) || '_' || cast(rr.retailrollup_id as text) as id"
        + ", rr.retailunit_id as retailunit_id"
        + ", rr.retailrollup_id as retailrollup_id"
        + ", rrv.code_path as code_path"
        + ", rrv.name_path as name_path"
        + ", parent_rr.retailunit_id as root_retailunit_id"
        + ", parent_rr.retailrollup_id as root_retailrollup_id"
        + ", parent_rrv.code_path as root_code_path"
        + ", parent_rrv.name_path as root_name_path"
        + " from"
        + " blue.dataset_retailrollup drr"
        + " join blue.datasetweighttype dwt on dwt.dataset_id = drr.dataset_id"
        + " join blue.retailrollup parent_rr on drr.retailrollup_id = parent_rr.retailrollup_id"
        + " join blue.retailrollup rr on rr.rollup_root_id = parent_rr.rollup_root_id"
        + " and rr.rollup_left between parent_rr.rollup_left and parent_rr.rollup_right"
        + " join blue.retailrevenueweight rrw on dwt.datasetweighttype_id = rrw.datasetweighttype_id"
        + " and rr.retailunit_id = rrw.retailunit_id"
        + " join blue_console.retailrollup_view rrv on rrv.retailrollup_id = rr.retailrollup_id"
        + " join blue_console.retailrollup_view parent_rrv on parent_rrv.retailrollup_id = parent_rr.retailrollup_id"
        + " where dwt.datasetweighttype_id = :datasetWeightTypeId";
    @Query(value = queryByDatasetWeightType, nativeQuery = true)
    List<RetailUnitRollup> findByDatasetWeightType(@Param("datasetWeightTypeId") Long datasetWeightTypeId);
}
