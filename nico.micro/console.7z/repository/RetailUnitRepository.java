package com.advantagegroup.blue.console.repository;

import com.advantagegroup.blue.console.domain.RetailUnit;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import org.springframework.data.jpa.repository.*;

import java.util.Set;


/**
 * Spring Data JPA repository for the RetailUnit entity.
 */
@SuppressWarnings("unused")
@Repository
public interface RetailUnitRepository extends JpaRepository<RetailUnit,Long> {
    static final String queryInNeedOfWeightsByDatasetId = "" +
        "select distinct ru.*\n" +
        "from blue.dataset ds\n" +
        "join blue.dataset_retailrollup drr on ds.dataset_id = drr.dataset_id\n" +
        "join blue.retailrollup parent_rr on drr.retailrollup_id = parent_rr.retailrollup_id\n" +
        "join blue.retailrollup rr on rr.rollup_root_id = parent_rr.rollup_root_id\n" +
        "                          and rr.rollup_left between parent_rr.rollup_left and parent_rr.rollup_right\n" +
        "join blue.retailunit ru on rr.retailunit_id = ru.retailunit_id\n" +
        "                        and ru.revenue_unit = true\n" +
        "where ds.dataset_id = :datasetId";
    @Query(value = queryInNeedOfWeightsByDatasetId, nativeQuery = true)
    Set<RetailUnit> findInNeedOfWeights(@Param("datasetId") Long datasetId );
}
