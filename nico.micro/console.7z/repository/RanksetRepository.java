package com.advantagegroup.blue.console.repository;

import com.advantagegroup.blue.console.domain.Rankset;
import org.springframework.stereotype.Repository;

import org.springframework.data.jpa.repository.*;


/**
 * Spring Data JPA repository for the Rankset entity.
 */
@Repository
public interface RanksetRepository extends JpaRepository<Rankset,Long> {
    
}
