package com.advantagegroup.blue.console.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.advantagegroup.blue.console.domain.Country;



public interface CountryRepository extends JpaRepository<Country, Long> {

}
