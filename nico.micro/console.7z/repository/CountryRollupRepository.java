package com.advantagegroup.blue.console.repository;

import java.util.Collection;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.advantagegroup.blue.console.domain.CountryRollup;

@Repository
public interface CountryRollupRepository extends JpaRepository<CountryRollup, Long> {

	@Query("SELECT leaf " +
			"FROM CountryRollup node, CountryRollup leaf " +
			"WHERE leaf.rollupRootId = node.rollupRootId " +
			"	AND node.rollupLeft <= leaf.rollupLeft "+
			"	AND leaf.rollupRight <= node.rollupRight " +
			"	AND node.id = :parentId")
	Collection<CountryRollup> findSubtree(@Param("parentId") Long parentId);

    List<CountryRollup> findAllByRollupParentIdIsNull();
}
