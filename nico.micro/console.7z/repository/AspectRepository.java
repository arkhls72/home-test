package com.advantagegroup.blue.console.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.advantagegroup.blue.console.domain.Aspect;

@Repository
public interface AspectRepository extends JpaRepository<Aspect, Long>{

}
