package com.advantagegroup.blue.console.repository;

import javax.validation.constraints.NotNull;

public class DBQueryStringBuilder {

	private DBQueryStringBuilder(){}

	/**
	 *
	 * @param userQuery
	 * @return a formatted query suitable for a database.
	 */
	public static String formatForDB(String userQuery) {
		if (userQuery == null) {
			throw new IllegalArgumentException("userQuery parameter cannot be null!");
		}
		String dbQuery = userQuery.toLowerCase().trim()
            .replaceAll("[*]", "%")
            .replaceAll("[?]", "_");
		return dbQuery;
	}
}
