package com.advantagegroup.blue.console.repository;

import com.advantagegroup.blue.console.domain.PracticeRollup;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import org.springframework.data.jpa.repository.*;

import java.util.List;


/**
 * Spring Data JPA repository for the PracticeRollup entity.
 */
@SuppressWarnings("unused")
@Repository
public interface PracticeRollupRepository extends JpaRepository<PracticeRollup,Long> {
    @Query(value = "select pr.*, prv.* " +
        "  from blue.practicerollup as pr " +
        "  join blue.dataset_practicerollup as dpr on pr.practicerollup_id = dpr.practicerollup_id " +
        "  join blue_console.practicerollup_view as prv on prv.practicerollup_id = pr.practicerollup_id " +
        "  where dpr.dataset_id = :datasetId",
        nativeQuery = true)
    List<PracticeRollup> findByDatasetId(@Param("datasetId") Long datasetId);

    // NOTE: native query cannot be Pageable
    @Query(value = "select distinct on (pr.practicerollup_id) pr.*, prv.* " +
        "from blue.dataset_survey dss " +
        "  inner join blue.surveypractice sp on sp.survey_id = dss.survey_id " +
        "  inner join blue.cache_practicerollupjoin cprj on cprj.head_practicerollup_id = sp.practicerollup_id " +
        "  inner join blue.practicerollup pr on pr.practicerollup_id = cprj.tail_practicerollup_id " +
        "  join blue_console.practicerollup_view as prv on prv.practicerollup_id = pr.practicerollup_id " +
        "where dss.dataset_id = :datasetId",
        nativeQuery = true)
    List<PracticeRollup> findEligible(@Param("datasetId") Long datasetId);

    static final String queryEligibleForSurvey = "select pr.*, pv.*\n" +
        "from blue.practicerollup pr\n" +
        "join blue.practicerollup tree_pr on tree_pr.practicerollup_id = pr.rollup_root_id\n" +
        "join blue.practicecode tree_pc on tree_pc.practicecode_id = tree_pr.practicecode_id\n" +
        "join blue_console.practicerollup_view pv on pv.practicerollup_id = pr.practicerollup_id\n" +
        "where tree_pc.practice_code != :practiceCode\n" +
        "and (lower(pv.name_path) like :searchString or lower(pv.code_path) like :searchString)\n" +
        "-- #pageable\n";
    static final String queryEligibleForSurveyCount = "select count( pr.practicerollup_id )\n" +
        "from blue.practicerollup pr\n" +
        "join blue.practicerollup tree_pr on tree_pr.practicerollup_id = pr.rollup_root_id\n" +
        "join blue.practicecode tree_pc on tree_pc.practicecode_id = tree_pr.practicecode_id\n" +
        "join blue_console.practicerollup_view pv on pv.practicerollup_id = pr.practicerollup_id\n" +
        "where (lower(pv.name_path) like :searchString or lower(pv.code_path) like :searchString)\n" +
        "and tree_pc.practice_code != :practiceCode\n";

    @Query(value = queryEligibleForSurvey, countQuery = queryEligibleForSurveyCount, nativeQuery = true)
    Page<PracticeRollup> findEligibleForSurvey(@Param("practiceCode") String practiceCode,
                                               @Param("searchString") String searchString,
                                               Pageable mappedPageable);

    static final String queryAllEligibleForSurvey = "select pr.*, pv.*\n" +
        "from blue.practicerollup pr\n" +
        "join blue.practicerollup tree_pr on tree_pr.practicerollup_id = pr.rollup_root_id\n" +
        "join blue.practicecode tree_pc on tree_pc.practicecode_id = tree_pr.practicecode_id\n" +
        "join blue_console.practicerollup_view pv on pv.practicerollup_id = pr.practicerollup_id\n" +
        "where tree_pc.practice_code != \'101\'";
    @Query(value = queryAllEligibleForSurvey, nativeQuery = true)
    List<PracticeRollup> findAllEligibleForSurvey();
}
