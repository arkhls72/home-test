package com.advantagegroup.blue.console.repository;

import com.advantagegroup.blue.console.domain.RetailRevenueWeight;
import org.springframework.stereotype.Repository;

import org.springframework.data.jpa.repository.*;


/**
 * Spring Data JPA repository for the RetailRevenueWeight entity.
 */
@SuppressWarnings("unused")
@Repository
public interface RetailRevenueWeightRepository extends JpaRepository<RetailRevenueWeight,Long> {
    
}
