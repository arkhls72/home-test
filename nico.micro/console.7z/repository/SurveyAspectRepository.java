package com.advantagegroup.blue.console.repository;

import java.util.Set;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.advantagegroup.blue.console.domain.SurveyAspect;

public interface SurveyAspectRepository extends JpaRepository<SurveyAspect, Long> {
    
    
    @Query("select s from SurveyAspect s where s.survey.id=:id")
    Set<SurveyAspect> findBySurveyId(@Param("id") Long id);
}
