package com.advantagegroup.blue.console.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.advantagegroup.blue.console.domain.CountryCode;



public interface CountryCodeRepository extends JpaRepository<CountryCode, Long> {

}
