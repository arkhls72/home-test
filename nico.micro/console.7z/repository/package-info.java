/**
 * Spring Data JPA repositories.
 */
package com.advantagegroup.blue.console.repository;
