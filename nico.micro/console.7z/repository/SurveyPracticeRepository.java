package com.advantagegroup.blue.console.repository;

import com.advantagegroup.blue.console.domain.SurveyPractice;
import org.springframework.stereotype.Repository;

import org.springframework.data.jpa.repository.*;


/**
 * Spring Data JPA repository for the SurveyPractice entity.
 */
@Repository
public interface SurveyPracticeRepository extends JpaRepository<SurveyPractice,Long> {

}
