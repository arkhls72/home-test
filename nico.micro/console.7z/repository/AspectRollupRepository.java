package com.advantagegroup.blue.console.repository;

import com.advantagegroup.blue.console.domain.AspectRollup;
import org.springframework.stereotype.Repository;

import java.util.Set;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.*;
import org.springframework.data.repository.query.Param;


/**
 * Spring Data JPA repository for the AspectRollup entity.
 */
@SuppressWarnings("unused")
@Repository
public interface AspectRollupRepository extends JpaRepository<AspectRollup,Long> {
    
    @Query("select a from AspectRollup a where LOWER(a.codePath) like %:query% or LOWER(a.namePath) like %:query%")
    Page<AspectRollup> findByCodePathNamePath(Pageable pageable,@Param("query") String query );
}
