package com.advantagegroup.blue.console.repository;

import com.advantagegroup.blue.console.domain.SurveyFlat;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.*;

import java.util.List;


/**
 * Spring Data JPA repository for the Survey entity.
 */
@SuppressWarnings("unused")
@Repository
public interface SurveyFlatRepository extends JpaRepository<SurveyFlat,Long> {

    @Query(value =
        "select s.* " +
            "from blue.survey s " +
            "join blue.dataset_survey ds ON s.survey_id = ds.survey_id " +
            "where ds.dataset_id = :datasetId",
        nativeQuery = true)
    List<SurveyFlat> findByDatasetId(@Param("datasetId") Long datasetId);

    // NOTE: native query cannot be Pageable
    @Query(value =
        "select sv.*, srs.field_start, srs.field_close, srs.field_start_status, srs.field_close_status, srs.number_of_responses " +
            "from blue.survey sv " +
            "join blue.cache_countryrollupjoin ccrj on ccrj.head_countryrollup_id = sv.countryrollup_id " +
            "join blue.dataset ds on ds.countryrollup_id = ccrj.tail_countryrollup_id " +
            "join blue_console.survey_response_statistics srs ON sv.survey_id = srs.survey_id " +
            "where ds.dataset_id = :datasetId " +
// TODO:  Add this back in when approval status is working.
//            "and sv.approval_status = 'Approved' " +
            // survey starts before dataset expires
            "and COALESCE( sv.field_start_datetime, sv.expected_field_start_datetime, to_date( '1900-01-01', 'YYYY-MM-DD' ) ) <= COALESCE( ds.expiry_date, to_date( '2200-12-31', 'YYYY-MM-DD' ) ) " +
            // survey closes after dataset starts
            "and COALESCE( sv.field_close_datetime, sv.expected_field_close_datetime, to_date( '2200-12-31', 'YYYY-MM-DD' ) ) >= COALESCE( ds.effective_date, to_date( '1900-01-01', 'YYYY-MM-DD' ) )" +
            // TODO: order by should be parameterized with columns and order direction
            " order by sv.survey_code asc",
        nativeQuery = true)
    List<SurveyFlat> findEligible(@Param("datasetId") Long datasetId);

    @Query("SELECT sv FROM Survey sv "
        + "WHERE "
        + "lower(sv.code) LIKE :query OR "
        + "lower(sv.name) LIKE :query OR "
        + "lower(sv.description) LIKE :query OR "
        + "lower(sv.program.code) LIKE :query OR "
        + "lower(sv.program.name) LIKE :query OR "
        + "lower(sv.program.description) LIKE :query"
    )
    Page<SurveyFlat> search(@Param("query") String query, Pageable pageable);
}
