package com.advantagegroup.blue.console.repository.search;

import com.advantagegroup.blue.console.domain.SurveyPractice;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * Spring Data Elasticsearch repository for the SurveyPractice entity.
 */
public interface SurveyPracticeSearchRepository extends JpaRepository<SurveyPractice, Long> {
}
