package com.home.blue.dataset.manager.impl;

/**
 * @author ara khalesi
 * May, 2017
 */
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import com.home.blue.dataset.config.DatasetParameter;
import com.home.blue.dataset.manager.AbstractManager;
import com.home.blue.dataset.manager.ManufacturerManager;
import com.home.blue.persistent.common.BluePageSize;
import com.home.blue.persistent.common.model.dataset.Dataset;
import com.home.blue.persistent.common.repository.dataset.DatasetManufacturerRollupRepository;

/**
 * @author ara khalesi June,2017
 */
@Component
public class ManufacturerManagerImpl extends AbstractManager implements ManufacturerManager {
    private static final Logger logger = LoggerFactory.getLogger(ManufacturerManagerImpl.class);

    @Autowired
    protected DatasetParameter parameter;

    private DatasetManufacturerRollupRepository datasetManufacturerRollupRepository;

    public ManufacturerManagerImpl(DatasetManufacturerRollupRepository datasetManufacturerRollupRepository) {
        super();
        this.datasetManufacturerRollupRepository = datasetManufacturerRollupRepository;
    }

    @Override
    public List<Dataset> retrieveScopeSearch(List<Integer> ids, String keyword, BluePageSize pageSize) {
        logger.debug("Enter ManufacturerManagerImpl[retrieveScopeSearch keyword:{}]", keyword);

        Page<Dataset> page = null;

        int isLike = StringUtils.isEmpty(keyword) ? -2 : keyword.lastIndexOf("*");
        keyword = isLike == -2 ? null : keyword.replace("*", "").trim();

        switch (isLike) {
            case -2:
                page = datasetManufacturerRollupRepository.findDatasetNotInIds(ids, pageSize);

                break;
            case -1:
                page = datasetManufacturerRollupRepository.findDatasetNotInIdsWithEqual(keyword, ids, pageSize);

                break;
            default:
                page = datasetManufacturerRollupRepository.findDatasetNotIdsWithLike("%" + keyword + "%", ids,
                        pageSize);

                break;
        }

        return page.getContent();
    }
}
