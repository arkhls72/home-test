package com.home.blue.dataset.service;

/**
 * @author ara khalesi
 * May, 2017
 */
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import com.home.blue.dataset.config.DatasetParameter;
import com.home.blue.dataset.dto.dataset.DatasetDTO;
import com.home.blue.dataset.helper.AppendHelper;
import com.home.blue.dataset.helper.CriteriaType;
import com.home.blue.dataset.manager.AspectManager;
import com.home.blue.dataset.manager.CountryManager;
import com.home.blue.dataset.manager.DatasetManager;
import com.home.blue.dataset.manager.ManufacturerManager;
import com.home.blue.dataset.manager.ProgramManager;
import com.home.blue.dataset.manager.TransactionManager;
import com.home.blue.dataset.util.DatasetUtils;
import com.home.blue.dataset.util.ParameterUtils;
import com.home.blue.persistent.common.BluePageSize;
import com.home.blue.persistent.common.model.dataset.Dataset;
import com.home.blue.persistent.common.repository.aspect.AspectRollupRepository;
import com.home.blue.persistent.common.repository.country.CountryRollupRepository;
import com.home.blue.persistent.common.repository.dataset.DatasetAspectRollupRepository;
import com.home.blue.persistent.common.repository.dataset.DatasetCountryRollupRepository;
import com.home.blue.persistent.common.repository.dataset.DatasetFunctionRepository;
import com.home.blue.persistent.common.repository.dataset.DatasetManufacturerRollupRepository;
import com.home.blue.persistent.common.repository.dataset.DatasetPracticeRollupRepository;
import com.home.blue.persistent.common.repository.dataset.DatasetRepository;
import com.home.blue.persistent.common.repository.dataset.DatasetRetailRollupRepository;
import com.home.blue.persistent.common.repository.dataset.DatasetSurveyRepository;
import com.home.blue.persistent.common.repository.dataset.ProgRepository;
import com.home.blue.persistent.common.repository.manufacture.ManufacturerRollupRepository;
import com.home.blue.persistent.common.repository.practice.PracticeRollupRepository;
import com.home.blue.persistent.common.repository.retail.CompanyWeightTypeRepository;
import com.home.blue.persistent.common.repository.retail.RetailRollupRepository;
import com.home.blue.persistent.common.repository.survey.FunctionRepository;
import com.home.blue.persistent.common.repository.survey.SurveyRepository;

public abstract class AbstractDatasetService {

    @Autowired
    protected DatasetParameter parameter;

    @Autowired
    protected ProgramManager programManager;

    @Autowired
    protected DatasetManager datasetManager;

    @Autowired
    protected AspectManager aspectManager;

    @Autowired
    protected ManufacturerManager manufacturerManager;

    @Autowired
    protected CountryManager countryManager;

    @Autowired
    private CallableService callableService;

    @Autowired
    protected TransactionManager transactionManager;

    @Autowired
    protected DatasetRepository datasetRepository;

    @Autowired
    protected DatasetSurveyRepository datasetSurveyRepository;

    @Autowired
    protected SurveyRepository surveyRepository;

    @Autowired
    protected DatasetManufacturerRollupRepository datasetManufacturerRollupRepository;

    @Autowired
    protected ManufacturerRollupRepository manufacturerRollupRepository;

    @Autowired
    protected RetailRollupRepository retailRollupRepository;

    @Autowired
    protected DatasetRetailRollupRepository datasetRetailRollupRepository;

    @Autowired
    protected AspectRollupRepository aspectRollupRepository;

    @Autowired
    protected DatasetAspectRollupRepository datasetAspectRollupRepository;

    @Autowired
    protected PracticeRollupRepository practiceRollupRepository;

    @Autowired
    protected CountryRollupRepository countryRollupRepository;

    @Autowired
    protected DatasetCountryRollupRepository datasetCountryRollupRepository;

    @Autowired
    protected FunctionRepository functionRepository;

    @Autowired
    protected DatasetFunctionRepository datasetFunctionRepository;

    @Autowired
    protected DatasetPracticeRollupRepository datasetPracticeRollupRepository;

    @Autowired
    protected CompanyWeightTypeRepository companyWeightTypeRepository;

    @Autowired
    protected ProgRepository programRepository;

    @Autowired
    @Qualifier(value = "datasetThreadPoolTaskExecutor")
    private ThreadPoolTaskExecutor taskExecutor;

    // protected void initManufacturerRollupTreeView(DatasetResponseDTO
    // response, List<ManufacturerRollupTreeView> source,
    // Map<Integer, Integer> responseMap) throws Exception {
    //
    // if (CollectionUtils.isEmpty(source)) {
    // return;
    // }
    //
    // for (ManufacturerRollupTreeView item : source) {
    //
    // ManufacturerRollupDTO target = new ManufacturerRollupDTO();
    // target.setNumberOfResponse(responseMap.get(item.getRoot()));
    //
    // ManufacturerRollupTreeViewConverter.build(item, target);
    // response.getManufacturerRollups().add(target);
    // }
    // }

    // protected void initCountryRollupTreeView(DatasetResponseDTO response,
    // List<CountryRollupTreeView> source)
    // throws Exception {
    //
    // if (CollectionUtils.isEmpty(source)) {
    // return;
    // }
    //
    // for (CountryRollupTreeView item : source) {
    //
    // CountryRollupDTO target = new CountryRollupDTO();
    //
    // CountryRollupTreeViewConverter.build(item, target);
    // response.getCountryRollups().add(target);
    // }
    // }

    protected void initScopes(String keyword, List<DatasetDTO> source) throws Exception {

        List<DatasetDTO> target = new ArrayList<>();
        List<Integer> ids = new ArrayList<>();

        initIds(source, ids);

        int size = DatasetUtils.initRetrievdRowNumbers(ids.size());
        BluePageSize responseSize = DatasetUtils.getResponseListSize(size);

        switch (size) {
            case 0:
                return;

            case -1:
                target = getFromAspectRollups(keyword, ids, responseSize);

            default:
                target = getScopes(keyword, ids, responseSize);
        }

        source.addAll(target);
    }

    private List<DatasetDTO> getScopes(String keyword, List<Integer> ids, BluePageSize pageSize)
            throws InterruptedException, ExecutionException {
        Map<CriteriaType, String> scopes = ParameterUtils.getMap(parameter.scopeParam().getLeft(),
                parameter.scopeParam().getRight());
        Set<DatasetDTO> target = new HashSet<>();

        if (scopes.get(CriteriaType.SCOPE_ASPECTS) != null) {
            Callable<List<DatasetDTO>> aspectCallable = callableService.aspect(keyword, ids, pageSize);
            Future<List<DatasetDTO>> aspects = taskExecutor.submit(aspectCallable);

            target.addAll(aspects.get());
        }

        if (scopes.get(CriteriaType.SCOPE_FUNCTIONS) != null) {
            Callable<List<DatasetDTO>> functionCallable = callableService.function(keyword, ids, pageSize);
            Future<List<DatasetDTO>> functions = taskExecutor.submit(functionCallable);

            target.addAll(functions.get());
        }

        if (scopes.get(CriteriaType.SCOPE_COUNTRIES) != null) {
            Callable<List<DatasetDTO>> countryCallable = callableService.country(keyword, ids, pageSize);
            Future<List<DatasetDTO>> countries = taskExecutor.submit(countryCallable);

            target.addAll(countries.get());
        }

        if (scopes.get(CriteriaType.SCOPE_MANUFACTURERS) != null) {
            Callable<List<DatasetDTO>> manufacturerCallable = callableService.manufacturer(keyword, ids, pageSize);
            Future<List<DatasetDTO>> manufacturers = taskExecutor.submit(manufacturerCallable);

            target.addAll(manufacturers.get());
        }

        if (scopes.get(CriteriaType.SCOPE_RETAILERS) != null) {
            Callable<List<DatasetDTO>> retailCallable = callableService.manufacturer(keyword, ids, pageSize);
            Future<List<DatasetDTO>> retailers = taskExecutor.submit(retailCallable);

            target.addAll(retailers.get());
        }

        return new ArrayList<>(target);
    }

    private List<DatasetDTO> getFromAspectRollups(String keyword, List<Integer> ids, BluePageSize pageSize)
            throws Exception {
        List<DatasetDTO> target = new ArrayList<>();

        List<Dataset> aspectRollups = aspectManager.retrieveScopeSearch(ids, keyword, pageSize);

        if (CollectionUtils.isNotEmpty(aspectRollups)) {
            AppendHelper.convert(aspectRollups, target);
        }

        return target;
    }

    private void initIds(List<DatasetDTO> source, List<Integer> ids) {
        source.forEach(line -> {
            ids.add(line.getId());
        });
    }
}
