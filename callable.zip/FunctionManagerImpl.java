package com.home.blue.dataset.manager.impl;

/**
 * @author ara khalesi
 * May,2017
 */
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Component;

import com.home.blue.dataset.manager.AbstractManager;
import com.home.blue.dataset.manager.FunctionManager;
import com.home.blue.persistent.common.BluePageSize;
import com.home.blue.persistent.common.model.dataset.Dataset;
import com.home.blue.persistent.common.repository.dataset.DatasetFunctionRepository;

@Component
public class FunctionManagerImpl extends AbstractManager implements FunctionManager {
    private static final Logger logger = LoggerFactory.getLogger(FunctionManagerImpl.class);

    private DatasetFunctionRepository datasetFunctionRepository;

    @Autowired
    public FunctionManagerImpl(DatasetFunctionRepository datasetFunctionRepository) {
        this.datasetFunctionRepository = datasetFunctionRepository;
    }

    @Override
    public List<Dataset> retrieveScopeSearch(List<Integer> ids, String keyword, BluePageSize pageSize) {
        logger.debug("Enter FunctionManagerImpl.[ retrieveScopeSearch keyword:{} ]", keyword);

        Page<Dataset> page = null;

        int isLike = StringUtils.isEmpty(keyword) ? -2 : keyword.lastIndexOf("*");
        keyword = isLike == -2 ? null : keyword.replace("*", "").trim();

        switch (isLike) {
        case -2:
            page = datasetFunctionRepository.findDatasetNotInIds(ids, pageSize);

            break;
        case -1:
            page = datasetFunctionRepository.findDatasetNotInIdsWithEqual(keyword, ids, pageSize);

            break;
        default:
            page = datasetFunctionRepository.findDatasetNotIdsWithLike("%" + keyword + "%", ids, pageSize);

            break;
        }

        return page.getContent();
    }
}
