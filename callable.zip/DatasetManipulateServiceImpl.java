package com.home.blue.dataset.service.impl;

/**
 * @author ara khalesi
 * May 2017
 */
import java.util.Optional;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.home.blue.dataset.converter.aspect.AspectRollupConverter;
import com.home.blue.dataset.converter.country.CountryRollupConverter;
import com.home.blue.dataset.converter.dataset.DatasetAspectRollupConverter;
import com.home.blue.dataset.converter.dataset.DatasetConverter;
import com.home.blue.dataset.converter.dataset.DatasetCountryRollupConverter;
import com.home.blue.dataset.converter.dataset.DatasetFunctionConverter;
import com.home.blue.dataset.converter.dataset.DatasetManufacturerRollupConverter;
import com.home.blue.dataset.converter.dataset.DatasetPracticeRollupConverter;
import com.home.blue.dataset.converter.dataset.DatasetRetailRollupConverter;
import com.home.blue.dataset.converter.dataset.DatasetSurveyConverter;
import com.home.blue.dataset.converter.dataset.dto.DatasetDTOConverter;
import com.home.blue.dataset.converter.manufacturer.ManufacturerRollupConverter;
import com.home.blue.dataset.converter.practice.PracticeRollupConverter;
import com.home.blue.dataset.converter.retail.RetailRollupConverter;
import com.home.blue.dataset.converter.retail.dto.CompanyWeightTypeDTOConverter;
import com.home.blue.dataset.dto.aspect.AspectRollupDTO;
import com.home.blue.dataset.dto.country.CountryRollupDTO;
import com.home.blue.dataset.dto.dataset.DatasetAspectRollupDTO;
import com.home.blue.dataset.dto.dataset.DatasetCountryRollupDTO;
import com.home.blue.dataset.dto.dataset.DatasetDTO;
import com.home.blue.dataset.dto.dataset.DatasetFunctionDTO;
import com.home.blue.dataset.dto.dataset.DatasetManufacturerRollupDTO;
import com.home.blue.dataset.dto.dataset.DatasetPracticeRollupDTO;
import com.home.blue.dataset.dto.dataset.DatasetRetailRollupDTO;
import com.home.blue.dataset.dto.dataset.DatasetSurveyDTO;
import com.home.blue.dataset.dto.manufacture.ManufacturerRollupDTO;
import com.home.blue.dataset.dto.practice.PracticeRollupDTO;
import com.home.blue.dataset.dto.retail.RetailRollupDTO;
import com.home.blue.dataset.dto.survey.FunctionDTO;
import com.home.blue.dataset.dto.survey.SurveyDTO;
import com.home.blue.dataset.exception.DuplicateFoundException;
import com.home.blue.dataset.exception.NotFoundException;
import com.home.blue.dataset.http.DatasetResponseDTO;
import com.home.blue.dataset.service.AbstractDatasetService;
import com.home.blue.dataset.service.ManipulateService;
import com.home.blue.dataset.util.RaiseException;
import com.home.blue.persistent.common.model.aspect.AspectRollup;
import com.home.blue.persistent.common.model.country.CountryRollup;
import com.home.blue.persistent.common.model.dataset.Dataset;
import com.home.blue.persistent.common.model.dataset.DatasetAspectRollup;
import com.home.blue.persistent.common.model.dataset.DatasetCountryRollup;
import com.home.blue.persistent.common.model.dataset.DatasetFunction;
import com.home.blue.persistent.common.model.dataset.DatasetManufacturerRollup;
import com.home.blue.persistent.common.model.dataset.DatasetPracticeRollup;
import com.home.blue.persistent.common.model.dataset.DatasetRetailRollup;
import com.home.blue.persistent.common.model.dataset.DatasetSurvey;
import com.home.blue.persistent.common.model.dataset.Prog;
import com.home.blue.persistent.common.model.manufacture.ManufacturerRollup;
import com.home.blue.persistent.common.model.practice.PracticeRollup;
import com.home.blue.persistent.common.model.retail.CompanyWeightType;
import com.home.blue.persistent.common.model.retail.RetailRollup;
import com.home.blue.persistent.common.model.survey.Function;
import com.home.blue.persistent.common.model.survey.Survey;

@Service
public class DatasetManipulateServiceImpl extends AbstractDatasetService implements ManipulateService {
    private static final Logger logger = LoggerFactory.getLogger(DatasetManipulateServiceImpl.class);

    @Override
    public DatasetResponseDTO add(DatasetDTO source) {
        logger.debug("Enter DatasetTransactionServiceImpl.[ add(dataset.code:{}) ]", source.getCode());

        DatasetResponseDTO target = new DatasetResponseDTO();

        try {

            Dataset dataset = null;
            if (source.getId() != null) {
                dataset = datasetRepository.findOne(source.getId());

                if (dataset != null) {
                    RaiseException.DuplicateFound(source.toString(), this.getClass().getSimpleName(),
                            "add(" + source.getId() + ")");
                }
            }

            dataset = new Dataset();
            DatasetDTOConverter.build(source, dataset);

            dataset.setCompanyWeightType(new CompanyWeightType());
            CompanyWeightTypeDTOConverter.build(dataset.getCompanyWeightType(), source.getCompanyWeightType());

            Optional<Dataset> response = transactionManager.save(dataset);

            if (!response.isPresent()) {
                RaiseException.Dataset(this.getClass().getSimpleName(), "add",
                        "Error adding new dataset(" + source.getId() + ")");
            }

            source = new DatasetDTO();
            DatasetConverter.build(response.get(), source);

            target.getDatasets().add(source);

        } catch (DuplicateFoundException ex) {
            throw ex;

        } catch (Exception ex) {
            logger.error("Error:", ex);
            RaiseException.Dataset(this.getClass().getSimpleName(), "add(datset.code:" + source.getCode() + ")",
                    StringUtils.isEmpty(ex.getMessage()) ? ex.toString() : ex.getMessage());

        } catch (Throwable t) {
            logger.error("Throwable: [{}],", t.toString());
            RaiseException.Dataset(this.getClass().getSimpleName(), "add(datset.code:" + source.getCode() + ")",
                    t.toString());
        }

        return target;
    }

    @Override
    public DatasetResponseDTO addSurvey(Integer id, SurveyDTO source) {
        logger.debug("Enter DatasetTransactionServiceImpl.[ addSurvey(dataset.id:{},survey.id:{}) ]", id,
                source.getId());

        DatasetResponseDTO target = new DatasetResponseDTO();
        try {

            Dataset dataset = datasetRepository.findOne(id);

            if (dataset == null) {
                RaiseException.NotFound("dataset", this.getClass().getSimpleName(),
                        "addSurvey(dataset.id:" + id + ", survey.id:" + source.getId() + ")");
            }

            Survey survey = surveyRepository.findOne(source.getId());

            if (survey == null) {
                RaiseException.NotFound("survey", this.getClass().getSimpleName(),
                        "addSurvey(dataset.id:" + id + ", survey.id:" + source.getId() + ")");
            }

            DatasetSurvey add = new DatasetSurvey();

            add.setDataset(dataset);
            add.setSurvey(survey);

            dataset.addDatasetSurvey(add);

            Optional<DatasetSurvey> response = transactionManager.save(add);

            if (!response.isPresent()) {
                RaiseException.Dataset(this.getClass().getSimpleName(),
                        "addSurvey(dataset.id:" + id + ", survey.id:" + source.getId() + ")",
                        "Error saving datasetSurvey.");
            }

            DatasetDTO datasetDTO = new DatasetDTO();
            DatasetConverter.build(response.get().getDataset(), datasetDTO);

            DatasetSurveyDTO datasetSurveyDTO = new DatasetSurveyDTO();
            DatasetSurveyConverter.build(add, datasetSurveyDTO);

            datasetDTO.getDatasetSurveys().add(datasetSurveyDTO);

            target.getDatasets().add(datasetDTO);

        } catch (NotFoundException ex) {
            throw ex;

        } catch (Exception ex) {
            logger.error("Error:", ex);
            RaiseException.Dataset(this.getClass().getSimpleName(),
                    "addSurvey(dataset.id:" + id + ", survey.id:" + source.getId() + ")",
                    StringUtils.isEmpty(ex.getMessage()) ? ex.toString() : ex.getMessage());

        } catch (Throwable t) {
            logger.error("Throwable: [{}],", t.toString());
            RaiseException.Dataset(this.getClass().getSimpleName(),
                    "addSurvey(dataset.id:" + id + ", survey.id:" + source.getId() + ")", t.toString());
        }
        return target;
    }

    @Override
    public DatasetResponseDTO addManufacturer(Integer id, ManufacturerRollupDTO source) {
        logger.debug("Enter DatasetTransactionServiceImpl.[ addManufacturer(dataset.id:{},manufacturer.id:{})]", id,
                source.getId());

        DatasetResponseDTO target = new DatasetResponseDTO();

        try {

            Dataset dataset = datasetRepository.findOne(id);

            if (dataset == null) {
                RaiseException.NotFound("dataset", this.getClass().getSimpleName(),
                        "addManufacturer(dataset.id:" + id + ", manfacturereRollup.id:" + source.getId() + ")");
            }

            ManufacturerRollup manufacturerRollup = manufacturerRollupRepository.findOne(source.getId());

            if (manufacturerRollup == null) {
                RaiseException.NotFound("manufacturerRollup", this.getClass().getSimpleName(),
                        "addManufacturer(dataset.id:" + id + ", manfacturereRollup.id:" + source.getId() + ")");
            }

            DatasetManufacturerRollup add = new DatasetManufacturerRollup();

            add.setDataset(dataset);
            add.setManufacturerRollup(manufacturerRollup);

            dataset.addDatasetManufacturerRollup(add);
            Optional<DatasetManufacturerRollup> response = transactionManager.save(add);

            if (!response.isPresent()) {
                RaiseException.Dataset(this.getClass().getSimpleName(),
                        "addManufacturer(dataset.id:" + id + ", manfacturereRollup.id:" + source.getId() + ")",
                        "Error saveing manufacturer.");
            }

            DatasetDTO datasetDTO = new DatasetDTO();
            DatasetConverter.build(response.get().getDataset(), datasetDTO);

            DatasetManufacturerRollupDTO datasetManufacturerRollupDTO = new DatasetManufacturerRollupDTO();
            DatasetManufacturerRollupConverter.build(add, datasetManufacturerRollupDTO);

            ManufacturerRollupConverter.build(manufacturerRollup, datasetManufacturerRollupDTO.getManufacturerRollup());
            datasetDTO.getDatasetManufacturerRollups().add(datasetManufacturerRollupDTO);

            target.getDatasets().add(datasetDTO);

        } catch (NotFoundException ex) {
            throw ex;

        } catch (Exception ex) {
            logger.error("Error:", ex);
            RaiseException.Dataset(this.getClass().getSimpleName(),
                    "addManufacturer(dataset.id:" + id + ", manfacturereRollup.id:" + source.getId() + ")",
                    StringUtils.isEmpty(ex.getMessage()) ? ex.toString() : ex.getMessage());

        } catch (Throwable t) {
            logger.error("Throwable: [{}],", t.toString());
            RaiseException.Dataset(this.getClass().getSimpleName(),
                    "addManufacturer(dataset.id:" + id + ", manfacturereRollup.id:" + source.getId() + ")",
                    t.toString());
        }

        return target;
    }

    @Override
    public DatasetResponseDTO addRetailer(Integer id, RetailRollupDTO source) {
        logger.debug("Enter DatasetTransactionServiceImpl.[ addRetailer(dataset.id:{},retailRollup.id:{})]", id,
                source.getId());

        DatasetResponseDTO target = new DatasetResponseDTO();

        try {

            Dataset dataset = datasetRepository.findOne(id);

            if (dataset == null) {
                RaiseException.NotFound("dataset", this.getClass().getSimpleName(),
                        "addRetailer(dataset.id:" + id + ", retailRollup.id:" + source.getId() + ")");
            }

            RetailRollup retailRollup = retailRollupRepository.findOne(source.getId());

            if (retailRollup == null) {
                RaiseException.NotFound("retialRollup", this.getClass().getSimpleName(),
                        "addRetailer(dataset.id:" + id + ", retailRollup.id:" + source.getId() + ")");
            }

            DatasetRetailRollup add = new DatasetRetailRollup();
            add.setRetailRollup(retailRollup);
            add.setDataset(dataset);

            dataset.addDatasetRetailRollup(add);

            Optional<DatasetRetailRollup> response = transactionManager.save(add);

            if (!response.isPresent()) {
                RaiseException.Dataset(this.getClass().getSimpleName(),
                        "addRetailer(dataset.id:" + id + ", retailRollup.id:" + source.getId() + ")",
                        "Error saveing reilailRollup.");
            }

            DatasetDTO datasetDTO = new DatasetDTO();
            DatasetConverter.build(response.get().getDataset(), datasetDTO);

            DatasetRetailRollupDTO datasetRetailRollupDTO = new DatasetRetailRollupDTO();
            DatasetRetailRollupConverter.build(add, datasetRetailRollupDTO);

            RetailRollupConverter.build(retailRollup, datasetRetailRollupDTO.getRetailRollup());
            datasetDTO.getDatasetRetailRollups().add(datasetRetailRollupDTO);

            target.getDatasets().add(datasetDTO);

        } catch (NotFoundException ex) {
            throw ex;

        } catch (Exception ex) {
            logger.error("Error:", ex);
            RaiseException.Dataset(this.getClass().getSimpleName(),
                    "addRetailer(dataset.id:" + id + ", retailRollup.id:" + source.getId() + ")",
                    StringUtils.isEmpty(ex.getMessage()) ? ex.toString() : ex.getMessage());

        } catch (Throwable t) {
            logger.error("Throwable: [{}],", t.toString());
            RaiseException.Dataset(this.getClass().getSimpleName(),
                    "addRetailer(dataset.id:" + id + ", retailRollup.id:" + source.getId() + ")", t.toString());
        }

        return target;
    }

    @Override
    public DatasetResponseDTO addAspect(Integer id, AspectRollupDTO source) {
        logger.debug("Enter DatasetTransactionServiceImpl.[ addAspect(dataset.id:{},aspectRollup.id:{})]", id,
                source.getId());

        DatasetResponseDTO target = new DatasetResponseDTO();

        try {

            Dataset dataset = datasetRepository.findOne(id);

            if (dataset == null) {
                RaiseException.NotFound("dataset", this.getClass().getSimpleName(),
                        "addAspect(dataset.id:" + id + ", aspectRollup.id:" + source.getId() + ")");
            }

            AspectRollup aspectRollup = aspectRollupRepository.findOne(source.getId());

            if (aspectRollup == null) {
                RaiseException.NotFound("aspectRollup", this.getClass().getSimpleName(),
                        "addAspect(dataset.id:" + id + ", aspectRollup.id:" + source.getId() + ")");
            }

            DatasetAspectRollup add = new DatasetAspectRollup();
            add.setAspectRollup(aspectRollup);
            add.setDataset(dataset);

            dataset.addDatasetAspectRollup(add);

            Optional<DatasetAspectRollup> response = transactionManager.save(add);

            if (!response.isPresent()) {
                RaiseException.Dataset(this.getClass().getSimpleName(),
                        "addAspect(dataset.id:" + id + ", aspectRollup.id:" + source.getId() + ")",
                        "Error saveing aspectRollup.");
            }

            DatasetDTO datasetDTO = new DatasetDTO();
            DatasetConverter.build(response.get().getDataset(), datasetDTO);

            DatasetAspectRollupDTO datasetAspectRollupDTO = new DatasetAspectRollupDTO();
            DatasetAspectRollupConverter.build(add, datasetAspectRollupDTO);

            AspectRollupConverter.build(aspectRollup, datasetAspectRollupDTO.getAspectRollup());
            datasetDTO.getDatasetAspectRollups().add(datasetAspectRollupDTO);

            target.getDatasets().add(datasetDTO);

        } catch (NotFoundException ex) {
            throw ex;

        } catch (Exception ex) {
            logger.error("Error:", ex);
            RaiseException.Dataset(this.getClass().getSimpleName(),
                    "addAspect(dataset.id:" + id + ", aspectRollup.id:" + source.getId() + ")",
                    StringUtils.isEmpty(ex.getMessage()) ? ex.toString() : ex.getMessage());

        } catch (Throwable t) {
            logger.error("Throwable: [{}],", t.toString());
            RaiseException.Dataset(this.getClass().getSimpleName(),
                    "addAspect(dataset.id:" + id + ", aspectRollup.id:" + source.getId() + ")", t.toString());
        }
        return target;
    }

    @Override
    public DatasetResponseDTO addPractice(Integer id, PracticeRollupDTO source) {
        logger.debug("Enter DatasetTransactionServiceImpl.[ addPractice(dataset.id:{},practiceRollup.id:{})]", id,
                source.getId());

        DatasetResponseDTO target = new DatasetResponseDTO();

        try {

            Dataset dataset = datasetRepository.findOne(id);

            if (dataset == null) {
                RaiseException.NotFound("dataset", this.getClass().getSimpleName(),
                        "addPractice(dataset.id:" + id + ", addPractice.id:" + source.getId() + ")");
            }

            PracticeRollup practiceRollup = practiceRollupRepository.findOne(source.getId());

            if (practiceRollup == null) {
                RaiseException.NotFound("practiceRollup", this.getClass().getSimpleName(),
                        "addAspect(dataset.id:" + id + ", practiceRollup.id:" + source.getId() + ")");
            }

            DatasetPracticeRollup add = new DatasetPracticeRollup();
            add.setPracticeRollup(practiceRollup);
            add.setDataset(dataset);

            dataset.addDatasetPracticeRollup(add);

            Optional<DatasetPracticeRollup> response = transactionManager.save(add);

            if (!response.isPresent()) {
                RaiseException.Dataset(this.getClass().getSimpleName(),
                        "addPractice(dataset.id:" + id + ", practiceRollup.id:" + source.getId() + ")",
                        "Error saveing practiceRollup.");
            }

            DatasetDTO datasetDTO = new DatasetDTO();
            DatasetConverter.build(response.get().getDataset(), datasetDTO);

            DatasetPracticeRollupDTO datasetPracticeRollupDTO = new DatasetPracticeRollupDTO();
            DatasetPracticeRollupConverter.build(add, datasetPracticeRollupDTO);

            PracticeRollupConverter.build(practiceRollup, datasetPracticeRollupDTO.getPracticeRollup());
            datasetDTO.getDatasetPracticeRollups().add(datasetPracticeRollupDTO);

            target.getDatasets().add(datasetDTO);

        } catch (NotFoundException ex) {
            throw ex;

        } catch (Exception ex) {
            logger.error("Error:", ex);
            RaiseException.Dataset(this.getClass().getSimpleName(),
                    "addPractice(dataset.id:" + id + ", practiceRollup.id:" + source.getId() + ")",
                    StringUtils.isEmpty(ex.getMessage()) ? ex.toString() : ex.getMessage());

        } catch (Throwable t) {
            logger.error("Throwable: [{}],", t.toString());
            RaiseException.Dataset(this.getClass().getSimpleName(),
                    "addPractice(dataset.id:" + id + ", practiceRollup.id:" + source.getId() + ")", t.toString());
        }
        return target;
    }

    @Override
    public DatasetResponseDTO addCountry(Integer id, CountryRollupDTO source) {
        logger.debug("Enter DatasetTransactionServiceImpl.[addCountry(dataset.id:{},countryRollup.id:{})]", id,
                source.getId());

        DatasetResponseDTO target = new DatasetResponseDTO();

        try {

            Dataset dataset = datasetRepository.findOne(id);

            if (dataset == null) {
                RaiseException.NotFound("dataset", this.getClass().getSimpleName(),
                        "addCountry(dataset.id:" + id + ", countryRollup.id:" + source.getId() + ")");
            }

            CountryRollup countryRollup = countryRollupRepository.findOne(source.getId());

            if (countryRollup == null) {
                RaiseException.NotFound("countryRollup", this.getClass().getSimpleName(),
                        "addCountry(dataset.id:" + id + ", countryRollup.id:" + source.getId() + ")");
            }

            DatasetCountryRollup add = new DatasetCountryRollup();
            add.setCountryRollup(countryRollup);
            add.setDataset(dataset);

            dataset.addDatasetCountryRollup(add);

            Optional<DatasetCountryRollup> response = transactionManager.save(add);

            if (!response.isPresent()) {
                RaiseException.Dataset(this.getClass().getSimpleName(),
                        "addCountry(dataset.id:" + id + ", countryRollup.id:" + source.getId() + ")",
                        "Error saveing countryRollup.");
            }

            DatasetDTO datasetDTO = new DatasetDTO();
            DatasetConverter.build(response.get().getDataset(), datasetDTO);

            DatasetCountryRollupDTO datasetCountryRollupDTO = new DatasetCountryRollupDTO();
            DatasetCountryRollupConverter.build(add, datasetCountryRollupDTO);

            CountryRollupConverter.build(countryRollup, datasetCountryRollupDTO.getCountryRollup());
            datasetDTO.getDatasetCountryRollups().add(datasetCountryRollupDTO);

            target.getDatasets().add(datasetDTO);

        } catch (NotFoundException ex) {
            throw ex;

        } catch (Exception ex) {
            logger.error("Error:", ex);
            RaiseException.Dataset(this.getClass().getSimpleName(),
                    "addCountry(dataset.id:" + id + ", countryRollup.id:" + source.getId() + ")",
                    StringUtils.isEmpty(ex.getMessage()) ? ex.toString() : ex.getMessage());

        } catch (Throwable t) {
            logger.error("Throwable: [{}],", t.toString());
            RaiseException.Dataset(this.getClass().getSimpleName(),
                    "addCountry(dataset.id:" + id + ", countryRollup.id:" + source.getId() + ")", t.toString());
        }
        return target;
    }

    @Override
    public DatasetResponseDTO addFunction(Integer id, FunctionDTO source) {
        logger.debug("Enter DatasetTransactionServiceImpl.[addFunction(dataset.id:{},function.id:{})]", id,
                source.getId());

        DatasetResponseDTO target = new DatasetResponseDTO();
        try {

            Dataset dataset = datasetRepository.findOne(id);

            if (dataset == null) {
                RaiseException.NotFound("dataset", this.getClass().getSimpleName(),
                        "addFunction(dataset.id:" + id + ", function.id:" + source.getId() + ")");
            }

            Function function = functionRepository.findOne(source.getId());

            if (function == null) {
                RaiseException.NotFound("function", this.getClass().getSimpleName(),
                        "addFunction(dataset.id:" + id + ", function.id:" + source.getId() + ")");
            }

            DatasetFunction add = new DatasetFunction();

            add.setDataset(dataset);
            add.setFunction(function);

            dataset.addDatasetFunction(add);

            Optional<DatasetFunction> response = transactionManager.save(add);

            if (!response.isPresent()) {
                RaiseException.Dataset(this.getClass().getSimpleName(),
                        "addFunction(dataset.id:" + id + ", function.id:" + source.getId() + ")",
                        "Error saving datasetFunction.");
            }

            DatasetDTO datasetDTO = new DatasetDTO();
            DatasetConverter.build(response.get().getDataset(), datasetDTO);

            DatasetFunctionDTO datasetFunctionDTO = new DatasetFunctionDTO();
            DatasetFunctionConverter.build(add, datasetFunctionDTO);

            datasetDTO.getDatasetFunctions().add(datasetFunctionDTO);

            target.getDatasets().add(datasetDTO);

        } catch (NotFoundException ex) {
            throw ex;

        } catch (Exception ex) {
            logger.error("Error:", ex);
            RaiseException.Dataset(this.getClass().getSimpleName(),
                    "addFunction(dataset.id:" + id + ", function.id:" + source.getId() + ")",
                    StringUtils.isEmpty(ex.getMessage()) ? ex.toString() : ex.getMessage());

        } catch (Throwable t) {
            logger.error("Throwable: [{}],", t.toString());
            RaiseException.Dataset(this.getClass().getSimpleName(),
                    "addFunction(dataset.id:" + id + ", function.id:" + source.getId() + ")", t.toString());
        }
        return target;

    }

    @Override
    public DatasetResponseDTO removeSurvey(Integer id, Integer source) {

        DatasetResponseDTO target = new DatasetResponseDTO();

        try {

            Optional<DatasetSurvey> datasetSurvey = datasetSurveyRepository.findByIdBySurveyId(id, source);

            if (!datasetSurvey.isPresent()) {
                RaiseException.NotFound("datasetSurvey", this.getClass().getSimpleName(),
                        "removeSurvey(dataset.id:" + id + ", survey.id:" + source + ")");
            }

            transactionManager.delete(datasetSurvey.get());

            Dataset dataset = datasetRepository.findOne(id);
            DatasetDTO datasetDTO = new DatasetDTO();

            DatasetConverter.build(dataset, datasetDTO);
            DatasetSurveyConverter.build(dataset.getDatasetSurveys(), datasetDTO.getDatasetSurveys());

            target.getDatasets().add(datasetDTO);

        } catch (NotFoundException ex) {
            throw ex;

        } catch (Exception ex) {
            logger.error("Error:", ex);
            RaiseException.Dataset(this.getClass().getSimpleName(),
                    "removeSurvey(dataset.id:" + id + ", survey.id:" + source + ")",
                    StringUtils.isEmpty(ex.getMessage()) ? ex.toString() : ex.getMessage());

        } catch (Throwable t) {
            logger.error("Throwable: [{}],", t.toString());
            RaiseException.Dataset(this.getClass().getSimpleName(),
                    "removeSurvey(dataset.id:" + id + ", survey.id:" + source + ")", t.toString());
        }
        return target;
    }

    @Override
    public DatasetResponseDTO removeManufacturer(Integer id, Integer source) {

        DatasetResponseDTO target = new DatasetResponseDTO();
        try {

            Optional<DatasetManufacturerRollup> manufacturerRollup = datasetManufacturerRollupRepository
                    .findByIdByManufacturerRollupId(id, source);

            if (!manufacturerRollup.isPresent()) {
                RaiseException.NotFound("datasetManufacturerRollup", this.getClass().getSimpleName(),
                        "removeManufacturer(dataset.id:" + id + ", manufacturer.id:" + source + ")");
            }

            transactionManager.delete(manufacturerRollup.get());

            Dataset dataset = datasetRepository.findOne(id);
            DatasetDTO datasetDTO = new DatasetDTO();

            DatasetConverter.build(dataset, datasetDTO);
            datasetDTO.setDatasetManufacturerRollups(
                    DatasetManufacturerRollupConverter.build(dataset.getDatasetManufacturerRollups()));

            target.getDatasets().add(datasetDTO);

        } catch (NotFoundException ex) {
            throw ex;

        } catch (Exception ex) {
            logger.error("Error:", ex);
            RaiseException.Dataset(this.getClass().getSimpleName(),
                    "removeManufacturer(dataset.id:" + id + ", manufacturerRollup.id:" + source + ")",
                    StringUtils.isEmpty(ex.getMessage()) ? ex.toString() : ex.getMessage());

        } catch (Throwable t) {
            logger.error("Throwable: [{}],", t.toString());
            RaiseException.Dataset(this.getClass().getSimpleName(),
                    "removeManufacturer(dataset.id:" + id + ", manufacturerRollup.id:" + source + ")", t.toString());
        }
        return target;
    }

    @Override
    public DatasetResponseDTO removeRetail(Integer id, Integer source) {

        DatasetResponseDTO target = new DatasetResponseDTO();
        try {

            Optional<DatasetRetailRollup> retailRollup = datasetRetailRollupRepository.findByIdByRetailRollupId(id,
                    source);

            if (!retailRollup.isPresent()) {
                RaiseException.NotFound("datasetRetailRollup", this.getClass().getSimpleName(),
                        "removeRetailer(dataset.id:" + id + ", retailRollup." + "id:" + source + ")");
            }

            transactionManager.delete(retailRollup.get());

            Dataset dataset = datasetRepository.findOne(id);
            DatasetDTO datasetDTO = new DatasetDTO();

            DatasetConverter.build(dataset, datasetDTO);
            datasetDTO.setDatasetRetailRollups(DatasetRetailRollupConverter.build(dataset.getDatasetRetailRollups()));

            target.getDatasets().add(datasetDTO);

        } catch (NotFoundException ex) {
            throw ex;

        } catch (Exception ex) {
            logger.error("Error:", ex);
            RaiseException.Dataset(this.getClass().getSimpleName(),
                    "removeRetailer(dataset.id:" + id + ", retailRollup.id:" + source + ")",
                    StringUtils.isEmpty(ex.getMessage()) ? ex.toString() : ex.getMessage());

        } catch (Throwable t) {
            logger.error("Throwable: [{}],", t.toString());
            RaiseException.Dataset(this.getClass().getSimpleName(),
                    "removeRetailer(dataset.id:" + id + ", retailRollup.id:" + source + ")", t.toString());
        }
        return target;
    }

    @Override
    public DatasetResponseDTO removeAspect(Integer id, Integer source) {

        DatasetResponseDTO target = new DatasetResponseDTO();

        try {

            Optional<DatasetAspectRollup> aspectRollup = datasetAspectRollupRepository
                    .findByDatasetIdByAspectRollupId(id, source);

            if (!aspectRollup.isPresent()) {
                RaiseException.NotFound("datasetAspectRollup", this.getClass().getSimpleName(),
                        "removeAspect(dataset.id:" + id + ", aspectRollup." + "id:" + source + ")");
            }

            transactionManager.delete(aspectRollup.get());

            Dataset dataset = datasetRepository.findOne(id);
            DatasetDTO datasetDTO = new DatasetDTO();

            DatasetConverter.build(dataset, datasetDTO);
            datasetDTO.setDatasetAspectRollups(DatasetAspectRollupConverter.build(dataset.getDatasetAspectRollups()));

            target.getDatasets().add(datasetDTO);

        } catch (NotFoundException ex) {
            throw ex;

        } catch (Exception ex) {
            logger.error("Error:", ex);
            RaiseException.Dataset(this.getClass().getSimpleName(),
                    "removeAspect(dataset.id:" + id + ", aspectRollup.id:" + source + ")",
                    StringUtils.isEmpty(ex.getMessage()) ? ex.toString() : ex.getMessage());

        } catch (Throwable t) {
            logger.error("Throwable: [{}],", t.toString());
            RaiseException.Dataset(this.getClass().getSimpleName(),
                    "removeAspect(dataset.id:" + id + ", aspectRollup.id:" + source + ")", t.toString());
        }
        return target;
    }

    @Override
    public DatasetResponseDTO removePractice(Integer id, Integer source) {
        DatasetResponseDTO target = new DatasetResponseDTO();

        try {

            Optional<DatasetPracticeRollup> practiceRollup = datasetPracticeRollupRepository
                    .findByDatasetByPracticeRollupId(id, source);

            if (!practiceRollup.isPresent()) {
                RaiseException.NotFound("datasetPracticeRollup", this.getClass().getSimpleName(),
                        "removePractice(dataset.id:" + id + ", practiceRollup.id:" + source + ")");
            }

            transactionManager.delete(practiceRollup.get());

            Dataset dataset = datasetRepository.findOne(id);
            DatasetDTO datasetDTO = new DatasetDTO();

            DatasetConverter.build(dataset, datasetDTO);
            datasetDTO.setDatasetPracticeRollups(
                    DatasetPracticeRollupConverter.build(dataset.getDatasetPracticeRollups()));

            target.getDatasets().add(datasetDTO);

        } catch (NotFoundException ex) {
            throw ex;

        } catch (Exception ex) {
            logger.error("Error:", ex);
            RaiseException.Dataset(this.getClass().getSimpleName(),
                    "removePractice(dataset.id:" + id + ", practiceRollup.id:" + source + ")",
                    StringUtils.isEmpty(ex.getMessage()) ? ex.toString() : ex.getMessage());

        } catch (Throwable t) {
            logger.error("Throwable: [{}],", t.toString());
            RaiseException.Dataset(this.getClass().getSimpleName(),
                    "removePractice(dataset.id:" + id + ", practiceRollup.id:" + source + ")", t.toString());
        }
        return target;
    }

    @Override
    public DatasetResponseDTO removeCountry(Integer id, Integer source) {
        DatasetResponseDTO target = new DatasetResponseDTO();

        try {

            Optional<DatasetCountryRollup> countryRollup = datasetCountryRollupRepository
                    .findByDatasetByCountryRollupId(id, source);

            if (!countryRollup.isPresent()) {
                RaiseException.NotFound("datasetCountryRollup", this.getClass().getSimpleName(),
                        "removeCountry(dataset.id:" + id + ", countryRollup.id:" + source + ")");
            }

            transactionManager.delete(countryRollup.get());

            Dataset dataset = datasetRepository.findOne(id);
            DatasetDTO datasetDTO = new DatasetDTO();

            DatasetConverter.build(dataset, datasetDTO);
            datasetDTO
                    .setDatasetCountryRollups(DatasetCountryRollupConverter.build(dataset.getDatasetCountryRollups()));

            target.getDatasets().add(datasetDTO);

        } catch (NotFoundException ex) {
            throw ex;

        } catch (Exception ex) {
            logger.error("Error:", ex);
            RaiseException.Dataset(this.getClass().getSimpleName(),
                    "removeCountry(dataset.id:" + id + ", countryRollup.id:" + source + ")",
                    StringUtils.isEmpty(ex.getMessage()) ? ex.toString() : ex.getMessage());

        } catch (Throwable t) {
            logger.error("Throwable: [{}],", t.toString());
            RaiseException.Dataset(this.getClass().getSimpleName(),
                    "removeCountry(dataset.id:" + id + ", countryRollup.id:" + source + ")", t.toString());
        }
        return target;
    }

    @Override
    public DatasetResponseDTO removeFunction(Integer id, Integer source) {
        DatasetResponseDTO target = new DatasetResponseDTO();

        try {

            Optional<DatasetFunction> function = datasetFunctionRepository.findByDatasetByFunctionId(id, source);

            if (!function.isPresent()) {
                RaiseException.NotFound("function", this.getClass().getSimpleName(),
                        "removeFunction(dataset.id:" + id + ", function.id:" + source + ")");
            }

            transactionManager.delete(function.get());

            Dataset dataset = datasetRepository.findOne(id);
            DatasetDTO datasetDTO = new DatasetDTO();

            DatasetConverter.build(dataset, datasetDTO);
            datasetDTO.setDatasetFunctions(DatasetFunctionConverter.build(dataset.getDatasetFunctions()));

            target.getDatasets().add(datasetDTO);

        } catch (NotFoundException ex) {
            throw ex;

        } catch (Exception ex) {
            logger.error("Error:", ex);
            RaiseException.Dataset(this.getClass().getSimpleName(),
                    "removeFunction(dataset.id:" + id + ", function.id:" + source + ")",
                    StringUtils.isEmpty(ex.getMessage()) ? ex.toString() : ex.getMessage());

        } catch (Throwable t) {
            logger.error("Throwable: [{}],", t.toString());
            RaiseException.Dataset(this.getClass().getSimpleName(),
                    "removeFunction(dataset.id:" + id + ", function.id:" + source + ")", t.toString());
        }
        return target;
    }

    @Override
    public DatasetResponseDTO update(DatasetDTO source) {
        DatasetResponseDTO target = new DatasetResponseDTO();

        try {

            Dataset dataset = datasetRepository.findOne(source.getId());

            if (dataset == null) {
                RaiseException.NotFound("dataset", this.getClass().getSimpleName(),
                        "update(dataset.id:" + source.getId() + ")");
            }

            DatasetDTOConverter.build(source, dataset);

            if (source.getCompanyWeightType() != null) {
                CompanyWeightType companyWeightType = companyWeightTypeRepository
                        .findOne(source.getCompanyWeightType().getId());
                if (companyWeightType == null) {
                    RaiseException.NotFound("compnayWeightType", this.getClass().getSimpleName(), "update(dataset.id:"
                            + source.getId() + ", companyWeightType.id:" + source.getCompanyWeightType().getId() + ")");
                }

                dataset.setCompanyWeightType(companyWeightType);
            }

            if (source.getProgram() != null) {
                Prog program = programRepository.findOne(source.getProgram().getId());

                if (program == null) {
                    RaiseException.NotFound("compnayWeightType", this.getClass().getSimpleName(), "update(dataset.id:"
                            + source.getId() + ", program.id:" + source.getProgram().getId() + ")");
                }

                dataset.setProg(program);
            }

            source = new DatasetDTO();
            transactionManager.save(dataset);

            DatasetConverter.build(dataset, source);

            target.getDatasets().add(source);

        } catch (NotFoundException ex) {
            throw ex;

        } catch (Exception ex) {
            logger.error("Error:", ex);
            RaiseException.Dataset(this.getClass().getSimpleName(), "update(dataset.id:" + source.getId() + ")",
                    StringUtils.isEmpty(ex.getMessage()) ? ex.toString() : ex.getMessage());

        } catch (Throwable t) {
            logger.error("Throwable: [{}],", t.toString());
            RaiseException.Dataset(this.getClass().getSimpleName(), "update(dataset.id:" + source.getId() + ")",
                    t.toString());
        }
        return target;
    }
}