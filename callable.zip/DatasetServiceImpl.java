package com.home.blue.dataset.service.impl;

/**
 * @author khale
 * May,2017
 */
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.tuple.Pair;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import com.home.blue.dataset.dto.dataset.DatasetDTO;
import com.home.blue.dataset.exception.NotFoundException;
import com.home.blue.dataset.helper.AppendHelper;
import com.home.blue.dataset.helper.CriteriaType;
import com.home.blue.dataset.http.DatasetResponseDTO;
import com.home.blue.dataset.service.AbstractDatasetService;
import com.home.blue.dataset.service.DatasetService;
import com.home.blue.dataset.util.DatasetUtils;
import com.home.blue.dataset.util.ParameterUtils;
import com.home.blue.dataset.util.RaiseException;
import com.home.blue.persistent.common.model.dataset.Dataset;
import com.home.blue.persistent.common.repository.dataset.specification.DatasetSpecification;

@Service
public class DatasetServiceImpl extends AbstractDatasetService implements DatasetService {
    private static final Logger logger = LoggerFactory.getLogger(DatasetServiceImpl.class);

    @Override
    public DatasetResponseDTO getByCriteria(Map<CriteriaType, Pair<?, ?>> criteria) {

        List<DatasetDTO> target = new ArrayList<DatasetDTO>();

        try {

            Map<CriteriaType, Specification<Dataset>> criteriaSpecs = DatasetUtils.getSpecification(criteria);

            Map<CriteriaType, String> scopes = ParameterUtils.getMap(parameter.scopeParam().getLeft(),
                    parameter.scopeParam().getRight());

            List<Dataset> source = scopes.get(CriteriaType.SCOPE_PROGRAMS) == null
                    ? datasetManager.retrieveScopeSearch(criteriaSpecs)
                    : programManager.retrieveScopeSearch(criteriaSpecs);

            if (CollectionUtils.isEmpty(source)) {
                RaiseException.NotFound("Dataset list", Dataset.class.getSimpleName(), "SearchCriteria()");
            }

            AppendHelper.convert(source, target);

            DatasetSpecification keyword = (DatasetSpecification) criteriaSpecs.get(CriteriaType.KEYWORD);
            initScopes(keyword != null ? (String) keyword.getCriteria().getValue1() : null, target);

        } catch (NotFoundException ex) {
            throw ex;

        } catch (Exception ex) {
            logger.error("Error:", ex);
            RaiseException.Dataset(this.getClass().getSimpleName(), "getByCriteria()",
                    StringUtils.isEmpty(ex.getMessage()) ? ex.toString() : ex.getMessage());

        } catch (Throwable t) {
            logger.error("Throwable: [{}],", t.toString());
            RaiseException.Dataset(this.getClass().getSimpleName(), "getByCriteria()", t.toString());
        }

        return new DatasetResponseDTO(target);
    }

    @Override
    public DatasetResponseDTO getById(Integer id) {
        logger.debug("Enter DatasetServiceImpl.[ getById({}) ]", id);

        DatasetResponseDTO target = new DatasetResponseDTO();

        try {

            Optional<Dataset> response = datasetManager.retrieveById(id);

            if (!response.isPresent()) {
                RaiseException.NotFound("Dataset", Dataset.class.getSimpleName(), "getById(" + id + ")");
            }

            DatasetDTO datasetDTO = new DatasetDTO();
            AppendHelper.convert(response.get(), datasetDTO);

            target.getDatasets().add(datasetDTO);

            return target;

        } catch (NotFoundException ex) {
            throw ex;

        } catch (Exception ex) {
            logger.error("Error:", ex);
            RaiseException.Dataset(this.getClass().getSimpleName(), "getById()",
                    StringUtils.isEmpty(ex.getMessage()) ? ex.toString() : ex.getMessage());

        } catch (Throwable t) {
            logger.debug("Throwable: [{}],", t.toString());
            RaiseException.Dataset(this.getClass().getSimpleName(), "getById()", t.toString());
        }

        return target;
    }
}
