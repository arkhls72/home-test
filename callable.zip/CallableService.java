package com.home.blue.dataset.service;


import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Callable;

import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.home.blue.dataset.dto.dataset.DatasetDTO;
import com.home.blue.dataset.helper.AppendHelper;
import com.home.blue.dataset.manager.AspectManager;
import com.home.blue.dataset.manager.CountryManager;
import com.home.blue.dataset.manager.FunctionManager;
import com.home.blue.dataset.manager.ManufacturerManager;
import com.home.blue.dataset.manager.RetailManager;
import com.home.blue.persistent.common.BluePageSize;
import com.home.blue.persistent.common.model.dataset.Dataset;

@Service
public class CallableService {
    @Autowired
    private AspectManager aspectManager;

    @Autowired
    private FunctionManager functionManager;

    @Autowired
    private CountryManager countryManager;

    @Autowired
    private ManufacturerManager manufacturerManager;

    @Autowired
    private RetailManager retailManager;

    public FunctionCallable function(String keyword, List<Integer> ids, BluePageSize pageSize) {
        return new FunctionCallable(keyword, ids, pageSize);
    }

    public AspectCallable aspect(String keyword, List<Integer> ids, BluePageSize pageSize) {
        return new AspectCallable(keyword, ids, pageSize);
    }

    public CountryCallable country(String keyword, List<Integer> ids, BluePageSize pageSize) {
        return new CountryCallable(keyword, ids, pageSize);
    }

    public ManufacturerCallable manufacturer(String keyword, List<Integer> ids, BluePageSize pageSize) {
        return new ManufacturerCallable(keyword, ids, pageSize);
    }

    public RetailerCallable retailer(String keyword, List<Integer> ids, BluePageSize pageSize) {
        return new RetailerCallable(keyword, ids, pageSize);
    }

    private class AspectCallable implements Callable<List<DatasetDTO>> {
        private List<Integer> ids;
        private String keyword;
        private BluePageSize pageSize;

        private AspectCallable(String keyword, List<Integer> ids, BluePageSize pageSize) {
            this.keyword = keyword;
            this.ids = ids;
            this.pageSize = pageSize;
        }

        @Override
        public List<DatasetDTO> call() throws Exception {
            List<Dataset> response = aspectManager.retrieveScopeSearch(ids, keyword, pageSize);
            List<DatasetDTO> target = new ArrayList<>();

            if (CollectionUtils.isNotEmpty(response)) {
                AppendHelper.convert(response, target);
            }
            return target;
        }

    }

    private class FunctionCallable implements Callable<List<DatasetDTO>> {
        private List<Integer> ids;
        private String keyword;
        private BluePageSize pageSize;

        private FunctionCallable(String keyword, List<Integer> ids, BluePageSize pageSize) {
            this.keyword = keyword;
            this.ids = ids;
            this.pageSize = pageSize;
        }

        @Override
        public List<DatasetDTO> call() throws Exception {
            List<DatasetDTO> target = new ArrayList<>();

            List<Dataset> response = functionManager.retrieveScopeSearch(ids, keyword, pageSize);

            if (CollectionUtils.isNotEmpty(response)) {
                AppendHelper.convert(response, target);
            }

            return target;
        }
    }

    private class CountryCallable implements Callable<List<DatasetDTO>> {
        private List<Integer> ids;
        private String keyword;
        private BluePageSize pageSize;

        private CountryCallable(String keyword, List<Integer> ids, BluePageSize pageSize) {
            this.keyword = keyword;
            this.ids = ids;
            this.pageSize = pageSize;
        }

        @Override
        public List<DatasetDTO> call() throws Exception {
            List<DatasetDTO> target = new ArrayList<>();

            List<Dataset> response = countryManager.retrieveScopeSearch(ids, keyword, pageSize);

            if (CollectionUtils.isNotEmpty(response)) {
                AppendHelper.convert(response, target);
            }

            return target;
        }
    }

    private class ManufacturerCallable implements Callable<List<DatasetDTO>> {
        private List<Integer> ids;
        private String keyword;
        private BluePageSize pageSize;

        private ManufacturerCallable(String keyword, List<Integer> ids, BluePageSize pageSize) {
            this.keyword = keyword;
            this.ids = ids;
            this.pageSize = pageSize;
        }

        @Override
        public List<DatasetDTO> call() throws Exception {
            List<DatasetDTO> target = new ArrayList<>();

            List<Dataset> response = manufacturerManager.retrieveScopeSearch(ids, keyword, pageSize);

            if (CollectionUtils.isNotEmpty(response)) {
                AppendHelper.convert(response, target);
            }

            return target;
        }
    }

    private class RetailerCallable implements Callable<List<DatasetDTO>> {
        private List<Integer> ids;
        private String keyword;
        private BluePageSize pageSize;

        private RetailerCallable(String keyword, List<Integer> ids, BluePageSize pageSize) {
            this.keyword = keyword;
            this.ids = ids;
            this.pageSize = pageSize;
        }

        @Override
        public List<DatasetDTO> call() throws Exception {
            List<DatasetDTO> target = new ArrayList<>();

            List<Dataset> response = retailManager.retrieveScopeSearch(ids, keyword, pageSize);

            if (CollectionUtils.isNotEmpty(response)) {
                AppendHelper.convert(response, target);
            }

            return target;
        }
    }
}
